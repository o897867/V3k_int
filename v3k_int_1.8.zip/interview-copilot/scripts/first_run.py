#!/usr/bin/env python3
"""One-time setup after the packages are installed (called by install.bat; safe to run again).

Creates config.yaml (written for THIS computer: on Windows the meeting audio is the speakers' loopback and the
hotkeys are Ctrl+Alt), .env from the template, and the knowledge folder; then checks that the app imports.
Never overwrites an existing config.yaml / .env.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def windows_config(text: str) -> str:
    from copilot.oscompat import adapt_hotkey
    text = re.sub(r'(?m)^(\s*device:\s*)"BlackHole"(.*)$',
                  r'\1"loopback"   # Windows: your default speakers / headset. Or part of a device name.', text, 1)
    text = re.sub(r'"(<cmd>[^"]*)"', lambda m: '"' + adapt_hotkey(m.group(1), win=True) + '"', text)
    text = text.replace("# pynput syntax; <cmd> = ⌘", "# pynput syntax; Windows: Ctrl+Alt+key")
    text = re.sub(r"(?m)^(\s*provider:\s*)local\b", r"\1deepgram", text)
    return text


def main() -> int:
    from copilot import oscompat
    made = []
    cfg = ROOT / "config.yaml"
    if not cfg.exists():
        text = (ROOT / "config.example.yaml").read_text(encoding="utf-8")
        cfg.write_text(windows_config(text) if oscompat.IS_WIN else text, encoding="utf-8")
        made.append("config.yaml")
    env = ROOT / ".env"
    new_env = not env.exists()
    if new_env:
        env.write_text((ROOT / ".env.example").read_text(encoding="utf-8"), encoding="utf-8")
        made.append(".env")
    (ROOT / "knowledge").mkdir(exist_ok=True)
    try:
        import copilot.app  # noqa: F401
        import copilot.ui.launcher  # noqa: F401
        if oscompat.IS_WIN:
            import pyaudiowpatch  # noqa: F401
    except Exception as e:
        print(f"  ❌ the app doesn't import: {e.__class__.__name__}: {e}")
        return 1
    print(f"  OK{' — created ' + ', '.join(made) if made else ''}")
    return 3 if new_env else 0   # 3 = tell install.bat to open .env in Notepad


if __name__ == "__main__":
    sys.exit(main())
