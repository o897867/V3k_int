"""Regenerate copilot/ui/assets/icon.ico (Windows shortcut icon) and icon.png from art.app_icon_pixmap.

Each size is drawn natively (see app_icon_pixmap), then packed as PNG entries in one .ico — the format Windows
Vista+ reads. Only needed when the mark changes; the files ship with the app.

    python scripts/make_icon.py
"""
from __future__ import annotations

import os
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

SIZES = (16, 20, 24, 32, 40, 48, 64, 128, 256)


def png_bytes(pixmap) -> bytes:
    from PyQt6.QtCore import QBuffer, QIODevice
    buf = QBuffer()
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    pixmap.save(buf, "PNG")
    return bytes(buf.data())


def pack_ico(images: list[tuple[int, bytes]]) -> bytes:
    head = struct.pack("<HHH", 0, 1, len(images))
    offset = 6 + 16 * len(images)
    entries, blobs = b"", b""
    for size, data in images:
        dim = 0 if size >= 256 else size
        entries += struct.pack("<BBBBHHII", dim, dim, 0, 0, 1, 32, len(data), offset)
        blobs += data
        offset += len(data)
    return head + entries + blobs


def main() -> int:
    from PyQt6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])  # noqa: F841 - fonts need an app
    from copilot.ui import art
    out = ROOT / "copilot" / "ui" / "assets"
    out.mkdir(parents=True, exist_ok=True)
    ico = pack_ico([(s, png_bytes(art.app_icon_pixmap(s, win=True))) for s in SIZES])
    (out / "icon.ico").write_bytes(ico)
    art.app_icon_pixmap(512, win=False).save(str(out / "icon.png"))
    print(f"wrote {out / 'icon.ico'} ({len(ico) // 1024} KB, sizes {', '.join(map(str, SIZES))}) and icon.png")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
