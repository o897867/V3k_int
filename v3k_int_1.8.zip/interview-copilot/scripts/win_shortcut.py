"""Windows: put an "Interview Copilot" shortcut (with the ensō icon) on the Desktop and in the Start menu.

    .venv\\Scripts\\python scripts\\win_shortcut.py            # create / refresh
    .venv\\Scripts\\python scripts\\win_shortcut.py --remove   # take them away again

Uses PowerShell's WScript.Shell (built into Windows); paths travel in environment variables, so folders with
spaces or Chinese names are fine. Does nothing on other systems.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAME = "Interview Copilot.lnk"

PS_CREATE = r"""
$ErrorActionPreference = 'Stop'
$shell = New-Object -ComObject WScript.Shell
$places = @([Environment]::GetFolderPath('Desktop'), (Join-Path ([Environment]::GetFolderPath('Programs')) ''))
foreach ($dir in $places) {
  if (-not $dir) { continue }
  $lnk = $shell.CreateShortcut((Join-Path $dir $env:IC_NAME))
  $lnk.TargetPath = $env:IC_TARGET
  $lnk.WorkingDirectory = $env:IC_ROOT
  $lnk.IconLocation = $env:IC_ICON + ',0'
  $lnk.Description = 'Interview Copilot - live interview answers'
  $lnk.WindowStyle = 1
  $lnk.Save()
  Write-Output $dir
}
"""

PS_REMOVE = r"""
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $p = Join-Path $dir $env:IC_NAME
  if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p; Write-Output $dir }
}
"""


def run(remove: bool = False, root: Path = ROOT) -> int:
    if sys.platform != "win32":
        print("Shortcuts are only made on Windows.")
        return 0
    env = dict(os.environ, IC_NAME=NAME, IC_ROOT=str(root), IC_TARGET=str(root / "Interview Copilot.bat"),
               IC_ICON=str(root / "copilot" / "ui" / "assets" / "icon.ico"))
    r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
                        PS_REMOVE if remove else PS_CREATE],
                       env=env, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        print("  (shortcut skipped: " + (r.stderr.strip().splitlines() or ["unknown error"])[-1] + ")")
        return 0   # never fail an install over a shortcut
    done = [x for x in r.stdout.splitlines() if x.strip()]
    if done and remove:
        print("  removed the shortcut from: " + ", ".join(done))
    elif done:
        print("  shortcut “Interview Copilot” added to the Desktop and the Start menu")
    return 0


if __name__ == "__main__":
    raise SystemExit(run(remove="--remove" in sys.argv[1:]))
