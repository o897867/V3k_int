#!/usr/bin/env python3
"""Measure answer latency with YOUR knowledge base and model — no audio needed.

    python scripts/bench_latency.py                       # model from config.yaml
    python scripts/bench_latency.py --model claude-sonnet-5-5
    python scripts/bench_latency.py --mock                # pipeline overhead only

Adds a simulated ASR endpoint delay (default 0.4 s = Deepgram endpointing) so the numbers
approximate 'interviewer stops talking → text on screen'.

Also checks the instant tier: every prepared answer in your knowledge base is asked with a
paraphrase (its first ALT: line) and must be on screen within engine.prepared_budget_s (1.5 s).
"""
import argparse
import asyncio
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from copilot.config import load_config  # noqa: E402
from copilot.engine.pipeline import Pipeline  # noqa: E402
from copilot.events import RecordingSink, TranscriptEvent  # noqa: E402
from copilot.knowledge import load_knowledge  # noqa: E402
from copilot.knowledge.prompt import build_system_blocks  # noqa: E402
from copilot.llm import build_llm  # noqa: E402
from copilot.session_log import latency_table  # noqa: E402

QUESTIONS = [
    "Could you start by telling me a little about yourself?",
    "Why are you interested in this role?",
    "Tell me about a time you had to explain a complex analysis to a non-technical stakeholder.",
    "How would you find the second highest salary in each department using SQL?",
    "What's the difference between a left join and an inner join, and when would you use each?",
    "How would you design a dashboard to monitor daily trading volumes and flag anomalies?",
    "Tell me about a mistake you made at work and what you learned.",
    "How do you handle missing or inconsistent data?",
    "Where do you see yourself in three years?",
    "Do you have any questions for us?",
]


async def run(cfg, endpoint_delay: float):
    kb = load_knowledge(cfg)
    llm = build_llm(cfg, build_system_blocks(cfg, kb))
    sink = RecordingSink()
    p = Pipeline(cfg, llm, kb, sink)
    if cfg.llm.provider != "mock":
        t = time.monotonic()
        await llm.warmup()
        print(f"warm-up {time.monotonic() - t:.2f}s (connection + prompt cache)")
    # --- instant tier: prepared answers must lock within budget
    prepared_rows = []
    for e in kb.qa.entries:
        phr = e.alts[0] if e.alts else e.question
        speech_end = time.monotonic()
        await asyncio.sleep(endpoint_delay)
        await p.handle(TranscriptEvent("final", phr, audio_end=speech_end))
        await p.handle(TranscriptEvent("endpoint", "", audio_end=speech_end))
        hit = p.prepared_metrics[-1] if p.prepared_metrics and p.prepared_metrics[-1]["id"] == p._last_q.id else None
        prepared_rows.append((phr, hit))
        for job in (p._job, p._deep_job):
            if job:
                job.cancel()
        p._last_q = None
    if prepared_rows:
        ok = sum(1 for _, h in prepared_rows if h and h["within_budget"])
        print(f"\nINSTANT TIER — {ok}/{len(prepared_rows)} prepared answers on screen within "
              f"{cfg.engine.prepared_budget_s}s (ASR delay {endpoint_delay}s simulated):")
        for phr, h in prepared_rows:
            print(f"  {'✓' if h and h['within_budget'] else '✗'} {(h['speech_end_to_prepared'] if h else 0):.2f}s  "
                  f"{phr[:70]}" + ("" if h else "   ← did not lock; add ALT: phrasings"))
        print()
    for q in QUESTIONS:
        speech_end = time.monotonic()
        await asyncio.sleep(endpoint_delay)  # ASR endpointing
        await p.handle(TranscriptEvent("final", q, audio_end=speech_end))
        await p.handle(TranscriptEvent("endpoint", "", audio_end=speech_end))
        await p.wait_idle()
        m = p.metrics[-1] if p.metrics else None
        prep = [e for e in sink.of("prepared") if not e[4]]
        tag = " [prepared]" if prep and prep[-1][2] == p._last_q.id else ""
        if m:
            print(f"KEY {m['speech_end_to_key']:.2f}s  full {m['speech_end_to_done']:.2f}s  "
                  f"ttft {m['trigger_to_first_token']:.2f}s  | {q[:60]}{tag}")
        await asyncio.sleep(4)  # > merge window so questions are independent
    print("\n" + latency_table(p.metrics))
    ok = sum(1 for m in p.metrics if m["speech_end_to_done"] <= 5)
    print(f"\nfull answer ≤ 5 s: {ok}/{len(p.metrics)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml" if Path("config.yaml").exists() else None)
    ap.add_argument("--model")
    ap.add_argument("--mock", action="store_true")
    ap.add_argument("--endpoint-delay", type=float, default=0.4)
    a = ap.parse_args()
    cfg = load_config(a.config)
    if a.mock:
        cfg.llm.provider = "mock"
    if a.model:
        cfg.llm.model = a.model
    asyncio.run(run(cfg, a.endpoint_delay))


if __name__ == "__main__":
    main()
