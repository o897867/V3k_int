#!/usr/bin/env python3
"""Verify the meeting audio: shows a live level meter for 10 s. Play any YouTube video — the bar should move.

    python scripts/check_audio.py              # the device in config.yaml (Mac: BlackHole · Windows: speaker loopback)
    python scripts/check_audio.py mic          # your microphone
    python scripts/check_audio.py "Headphones" # a specific device
"""
import asyncio
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from copilot import oscompat  # noqa: E402
from copilot.capture import describe_device, open_capture  # noqa: E402


async def main(dev: str):
    try:
        print("Using:", describe_device(dev))
    except Exception as e:
        print(f"❌ {e}")
        return
    cap = open_capture(dev)
    print(f"Listening on '{dev}' for 10 s — play some audio…")
    t0 = time.time()
    peak = 0.0
    async for _ in cap.chunks():
        lvl = min(1.0, cap.level * 6)
        peak = max(peak, cap.level)
        sys.stdout.write("\r[" + "#" * int(lvl * 40) + " " * (40 - int(lvl * 40)) + "]")
        sys.stdout.flush()
        if time.time() - t0 > 10:
            break
    if peak > 0.005:
        print("\n\nOK — audio is arriving.")
    elif oscompat.IS_WIN:
        print("\n\nNo signal. Is something playing on your DEFAULT speakers / headset? In Teams: Settings → Devices "
              "→ Speaker — use the same device that Windows uses as default output (or set audio.device to its "
              "name).")
    else:
        print("\n\nNo signal. Check: system output = your Multi-Output Device (incl. BlackHole), "
              "and the meeting app's speaker = that device. See README §2.")


if __name__ == "__main__":
    from copilot.config import load_config
    cfg = load_config("config.yaml" if Path("config.yaml").exists() else None)
    asyncio.run(main(sys.argv[1] if len(sys.argv) > 1 else cfg.audio.device))
