@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Interview Copilot - setup
echo.
echo   Interview Copilot - one-time setup (about 3-5 minutes)
echo   ------------------------------------------------------
echo.

rem ---- find Python 3.10 - 3.14 (3.12 preferred)
set "PY="
for %%V in (3.12 3.13 3.11 3.14 3.10) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
  )
)
if not defined PY (
  python -c "import sys; raise SystemExit(0 if (3,10) <= sys.version_info[:2] <= (3,14) else 1)" >nul 2>&1 && set "PY=python"
)
if not defined PY goto :nopython
echo   Using Python: %PY%

rem ---- private environment for this app (nothing is installed system-wide)
if not exist ".venv\Scripts\python.exe" (
  echo   Creating .venv ...
  %PY% -m venv .venv
  if errorlevel 1 goto :fail
)
echo   Installing packages (first time takes a few minutes) ...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q --upgrade pip
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo   Finishing setup ...
set PYTHONUTF8=1
".venv\Scripts\python.exe" scripts\first_run.py
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" if not "%RC%"=="3" goto :fail
set "NEWENV="
if "%RC%"=="3" set "NEWENV=1"
".venv\Scripts\python.exe" scripts\win_shortcut.py

echo.
echo   Done.
echo   1. Put your API keys into .env  (Notepad opens now - save and close it)
echo   2. Double-click "Interview Copilot" on your Desktop (or "Interview Copilot.bat" here)
echo.
if defined NEWENV start "" notepad ".env"
pause
exit /b 0

:nopython
echo.
echo   Python 3.10 - 3.14 was not found on this PC.
where winget >nul 2>&1
if errorlevel 1 goto :manualpython
choice /c YN /m "  Install Python 3.12 now (winget, about 1 minute)"
if errorlevel 2 goto :manualpython
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
echo.
echo   Python is installed. CLOSE this window and double-click install.bat again.
pause
exit /b 1

:manualpython
echo   Please install Python 3.12 from https://www.python.org/downloads/windows/
echo   (tick "Add python.exe to PATH" in the installer), then run install.bat again.
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1

:fail
echo.
echo   Setup did not finish. Scroll up for the first error message, or send a screenshot of this window.
pause
exit /b 1
