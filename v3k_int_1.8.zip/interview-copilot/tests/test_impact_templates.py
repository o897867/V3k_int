"""v1.8: answers carry the system-level impact, the input templates, and Sonnet 5.5 as the Sonnet default."""
import asyncio
import json
from pathlib import Path

from copilot.config import Config, load_config, upgrade_models
from copilot.knowledge import bank as B
from copilot.knowledge.loader import KnowledgeBase, load_knowledge
from copilot.knowledge.prompt import build_system_blocks
from copilot.knowledge.qa_bank import QABank
from copilot.llm.layered_parser import parse_layers
from tests.test_bank import ANSWERS, QUESTIONS, _cfg, _write
from tests.test_network_paths import _sse
from tests.test_sonnet_and_llm_asr import _collect, _llm_with_transport

ROOT = Path(__file__).resolve().parents[1]


# ------------------------------------------------------------------ impact framing

def test_prompt_asks_for_problem_action_system_impact():
    rules = build_system_blocks(Config(), KnowledgeBase())[0]["text"]
    assert "SAY WHY IT MATTERED" in rules and "WHOLE system" in rules
    assert "never invent a figure" in rules
    assert "问题 → 做法（用了什么）→ 影响" in rules          # FLOW order for work stories
    assert 'starts with "Impact:"' in rules
    c = Config()
    c.llm.impact = False
    off = build_system_blocks(c, KnowledgeBase())[0]["text"]
    assert "SAY WHY IT MATTERED" not in off and "影响（对整个系统" not in off


def test_placeholder_rule_covers_every_document():
    rules = build_system_blocks(Config(), KnowledgeBase())[0]["text"]
    assert "there or in any document" in rules


def test_lacks_impact_heuristic():
    assert B.lacks_impact("SAY: I built a Python pipeline with Airflow and SQL to load the data.")
    assert B.lacks_impact("KEY: x\nSAY: We used Power BI and DAX to build dashboards for the desk.")
    assert not B.lacks_impact("SAY: I automated the reconciliation, which cut it from 3 days to 4 hours.")
    assert not B.lacks_impact("SAY: I rebuilt the load so reports were ready by 8 am instead of noon.")
    assert not B.lacks_impact("SAY: My biggest weakness is over-polishing my work.")   # not about work


def test_enrich_v2_redoes_old_entries_and_notes_missing_impact(tmp_path):
    cfg = _cfg(tmp_path)
    kdir = tmp_path / "knowledge"
    kdir.mkdir()
    B.build(kdir, _write(tmp_path / "q.md", QUESTIONS), _write(tmp_path / "a.md", ANSWERS))
    prompts = []

    async def fake(prompt):
        prompts.append(prompt)
        ids = [ln[4:] for ln in prompt.splitlines() if ln.startswith("ID: ")]
        return json.dumps({i: {"alts": ["a"], "key": f"key {i}", "points": ["p1", "Impact: faster"],
                               "flow": ["问题 | problem", "影响 | impact"],
                               "impact": "没说对下游的影响" if i == "O1" else ""} for i in ids})
    assert "impact" in B.ENRICH_TASK and "问题 → 做法" in B.ENRICH_TASK
    asyncio.run(B.enrich(cfg, kdir, call=fake, batch_size=10, log=lambda *_: None))
    kb = load_knowledge(cfg)
    o1 = next(e for e in kb.qa.entries if e.question.startswith("Tell us a bit"))
    pts = parse_layers(o1.answer)["points"]
    assert "Impact: faster" in pts and "💡 补一句影响" in pts
    # a cache written by 1.7 (no "v") is redone once, then left alone
    cache_p = kdir / "bank" / "enrich.json"
    cache = json.loads(cache_p.read_text())
    for v in cache.values():
        v.pop("v", None)
    cache_p.write_text(json.dumps(cache))
    n_before = len(prompts)
    assert asyncio.run(B.enrich(cfg, kdir, call=fake, batch_size=10, log=lambda *_: None)) == len(cache)
    assert len(prompts) > n_before
    assert asyncio.run(B.enrich(cfg, kdir, call=fake, log=lambda *_: None)) == 0


# ------------------------------------------------------------------ templates

def _template_kb(tmp_path):
    (tmp_path / "config.yaml").write_text((ROOT / "config.example.yaml").read_text(encoding="utf-8"),
                                          encoding="utf-8")
    k = tmp_path / "knowledge"
    k.mkdir()
    (k / "qa.md").write_text((ROOT / "templates" / "qa.template.md").read_text(encoding="utf-8"), encoding="utf-8")
    (k / "analysis.md").write_text((ROOT / "templates" / "analysis.template.md").read_text(encoding="utf-8"),
                                   encoding="utf-8")
    cfg = load_config(str(tmp_path / "config.yaml"))
    return cfg, load_knowledge(cfg)


def test_templates_load_cleanly(tmp_path):
    cfg, kb = _template_kb(tmp_path)
    assert len(kb.qa.entries) == 3                      # the blank skeleton ([question]) is skipped
    for e in kb.qa.entries:
        L = parse_layers(e.answer)
        assert L["key"] and L["say"] and not L["key"].startswith(("ID", "TAGS"))
        assert "追问" not in e.answer and "NOTE" not in e.answer and "<!--" not in e.answer
    work = kb.qa.entries[1]
    assert work.meta["id"] == "[T3]" and len(work.meta["followups"]) == 2 and work.meta["notes"]
    assert "Impact:" in parse_layers(work.answer)["points"]
    assert len(parse_layers(work.answer)["flow"].split("\n")) == 4
    prompt = kb.qa.as_prompt_text()
    assert "FOLLOW-UP (prepared)" in prompt and "NOTE (private, not to say)" in prompt
    analysis = kb.get("my_analysis")
    assert "<!--" not in analysis and "怎么用" not in analysis        # guidance comments stay out of the prompt
    assert "Impact on the system" in analysis and "## 2. Story bank" in analysis


def test_template_questions_lock_onto_themselves(tmp_path):
    cfg, kb = _template_kb(tmp_path)
    r = B.check(kb, cfg.engine.instant_lock_threshold)
    assert not r["wrong"] and not r["weak"]
    assert not [e for e in kb.qa.entries if B.lacks_impact(e.answer)]   # the examples model the 3 beats


def test_meta_lines_in_any_qa_file():
    b = QABank()
    b.load_markdown("## Q: Why us?\nID: C2\nTAGS: closing\nKEY: k\n- p\nSAY: s\nFollow-up: why now? → timing\n"
                    "备注: 别提薪资\n")
    e = b.entries[0]
    assert e.answer == "KEY: k\n- p\nSAY: s"
    assert e.meta == {"id": "C2", "tags": "closing", "followups": ["why now? → timing"], "notes": ["别提薪资"]}


def test_update_and_launcher_ship_templates():
    assert '"templates"' in (ROOT / "update.py").read_text(encoding="utf-8")
    src = (ROOT / "copilot" / "ui" / "launcher.py").read_text(encoding="utf-8")
    assert "_open_templates" in src and '"templates"' in src


# ------------------------------------------------------------------ Sonnet 5.5

def test_sonnet_default_is_5_5():
    from copilot.ui import launcher as L
    assert L.SONNET == "claude-sonnet-5-5"
    assert Config().llm.prepare_model == "claude-sonnet-5-5"
    assert "claude-sonnet-5-5" in (ROOT / "config.example.yaml").read_text(encoding="utf-8")


def test_old_configs_move_to_5_5_unless_kept():
    c = Config()
    c.llm.model, c.llm.deep_model, c.llm.prepare_model = "claude-sonnet-5", "claude-sonnet-5", "claude-sonnet-5"
    assert len(upgrade_models(c)) == 3 and c.llm.model == c.llm.deep_model == "claude-sonnet-5-5"
    k = Config()
    k.llm.keep_models = True
    k.llm.deep_model = "claude-sonnet-5"
    assert upgrade_models(k) == [] and k.llm.deep_model == "claude-sonnet-5"
    h = Config()
    assert upgrade_models(h) == [] and h.llm.model.startswith("claude-haiku")


def _bodies_handler(bodies, reject=None):
    def handler(hx):
        def h(req):
            body = json.loads(req.content)
            bodies.append(body)
            if reject and reject(body):
                return hx.Response(400, json={"type": "error", "error": {
                    "type": "invalid_request_error",
                    "message": '"thinking.type.disabled" is not supported for this model. Use '
                               '"thinking.type.between_tools" for the lowest thinking setting'}})
            return hx.Response(200, headers={"content-type": "text/event-stream"}, content=_sse(["KEY: ok"]))
        return h
    return handler


def test_sonnet_5_5_uses_between_tools_with_effort(monkeypatch):
    bodies = []
    llm = _llm_with_transport(monkeypatch, _bodies_handler(bodies), model="claude-sonnet-5-5")
    assert _collect(llm) == "KEY: ok"
    b = bodies[0]
    assert b["model"] == "claude-sonnet-5-5"
    assert b["thinking"] == {"type": "between_tools"}
    assert b["output_config"] == {"effort": "medium"}
    assert "temperature" not in b and "top_p" not in b and "top_k" not in b
    bodies.clear()
    fast = _llm_with_transport(monkeypatch, _bodies_handler(bodies), model="claude-sonnet-5-5", effort="low")
    _collect(fast)
    assert bodies[0]["output_config"] == {"effort": "low"}


def test_future_model_learns_between_tools_from_the_error(monkeypatch):
    bodies = []
    llm = _llm_with_transport(monkeypatch, _bodies_handler(
        bodies, reject=lambda b: b.get("thinking") == {"type": "disabled"}), model="claude-sonnet-6")
    assert _collect(llm) == "KEY: ok"
    assert bodies[0]["thinking"] == {"type": "disabled"}
    assert bodies[1]["thinking"] == {"type": "between_tools"}   # not the slow model default
    assert llm.thinking == "disabled"
