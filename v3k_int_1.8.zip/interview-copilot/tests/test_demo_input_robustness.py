"""Regression: in demo mode on macOS the question never reached the engine and the overlay stayed on
'Waiting…' with no error. Every hop must now be visible, and typed input must not depend on the IME."""
import asyncio
import os
import time
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PyQt6")
from PyQt6.QtCore import Qt  # noqa: E402
from PyQt6.QtWidgets import QApplication  # noqa: E402

from copilot.app import EngineThread  # noqa: E402
from copilot.config import Config, load_config  # noqa: E402
from copilot.engine.pipeline import Pipeline  # noqa: E402
from copilot.events import RecordingSink  # noqa: E402
from copilot.knowledge import load_knowledge  # noqa: E402
from copilot.knowledge.loader import KnowledgeBase  # noqa: E402
from copilot.llm.mock_llm import MockLLM  # noqa: E402
from copilot.ui import hotkeys  # noqa: E402
from copilot.ui.bridge import QtSink  # noqa: E402
from copilot.ui.overlay import Overlay  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _wait(pred, secs=3.0):
    end = time.time() + secs
    while time.time() < end:
        if pred():
            return True
        time.sleep(0.02)
    return False


def test_engine_exception_is_reported_not_swallowed():
    sink = RecordingSink()
    pipe = Pipeline(Config(), MockLLM(), KnowledgeBase(), sink)

    async def boom(text):
        raise RuntimeError("kaboom")
    pipe.inject_text = boom
    eng = EngineThread(pipe, None, None, pipe.llm, sink, warmup=False)
    eng.start()
    assert _wait(lambda: eng.loop.is_running())
    eng.inject_text("walk me through your background")
    assert _wait(lambda: sink.of("error")), "engine failure must reach the UI"
    assert "kaboom" in sink.of("error")[0][2]
    eng.stop()


def test_misspelled_demo_question_is_answered():
    sink = RecordingSink()
    pipe = Pipeline(Config(), MockLLM(ttft=0.01, tok_per_s=5000), KnowledgeBase(), sink)
    eng = EngineThread(pipe, None, None, pipe.llm, sink, warmup=False)
    eng.start()
    assert _wait(lambda: eng.loop.is_running())
    eng.inject_text("walk me through yourb akcgounr")          # the exact input from the bug report
    assert _wait(lambda: len(sink.of("done")) == 1)
    eng.inject_text("our team mostly does reporting")            # typed statement: still answered in demo
    assert _wait(lambda: len(sink.of("done")) == 2)
    assert sink.of("question")[1][2].from_statement
    assert [e[2].text for e in sink.of("question")] == ["walk me through yourb akcgounr",
                                                        "our team mostly does reporting"]
    eng.stop()


def test_demo_box_bypasses_ime_and_ask_button_submits():
    app = QApplication.instance() or QApplication([])
    cfg = load_config(str(ROOT / "config.example.yaml"))
    cfg.knowledge.dir = str(ROOT / "knowledge.example")
    kb = load_knowledge(cfg)
    sink = QtSink()
    pipe = Pipeline(cfg, MockLLM(ttft=0.02, tok_per_s=3000), kb, sink)
    eng = EngineThread(pipe, None, None, pipe.llm, sink, warmup=False)
    ov = Overlay(cfg, sink, eng, "mock", demo=True)
    ov.show()
    eng.start()
    assert not ov.input.testAttribute(Qt.WidgetAttribute.WA_InputMethodEnabled)
    ov.input.setText("walk me through yourb akcgounr")
    ov.ask_btn.click()                       # works even when Enter is eaten by an input method
    assert "sent" in ov.tr_lb.text()         # immediate UI-side echo
    end = time.time() + 2
    while time.time() < end and not (ov.cards and ov.cards[-1].key):
        app.processEvents()
        time.sleep(0.01)
    c = ov._current()
    assert c is not None and c.question == "walk me through yourb akcgounr" and c.key
    assert "Waiting" not in ov.q_lb.text()
    eng.stop()
    ov.close()


def test_hotkeys_not_started_when_untrusted(monkeypatch):
    monkeypatch.setattr(hotkeys, "mac_accessibility_trusted", lambda: False)
    assert hotkeys.start_global_hotkeys(Config().hotkeys, lambda a: None) is None
