"""Launcher window: file status, drag-and-drop import, key status, start rules, remembered choices, jobs."""
import json
import os
import time
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PyQt6")
from PyQt6.QtCore import QMimeData, QPointF, Qt, QUrl  # noqa: E402
from PyQt6.QtGui import QDropEvent  # noqa: E402
from PyQt6.QtWidgets import QApplication  # noqa: E402

from copilot.config import load_config  # noqa: E402
from copilot.ui import launcher as L  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
GOOD_ANTHROPIC = "sk-ant-api03-" + "B" * 95


_APP = []


def _app():
    if not _APP:  # keep a reference, or Qt destroys the application object immediately
        _APP.append(QApplication.instance() or QApplication([]))
    return _APP[0]


def _project(tmp_path, env: str = "") -> tuple:
    (tmp_path / "config.yaml").write_text((ROOT / "config.example.yaml").read_text())
    (tmp_path / ".env").write_text(env)
    cfg = load_config(str(tmp_path / "config.yaml"))
    return cfg, str(tmp_path / "config.yaml")


def _pump(secs=0.2):
    end = time.time() + secs
    while time.time() < end:
        _app().processEvents()
        time.sleep(0.01)


@pytest.fixture(autouse=True)
def _no_shell_keys(monkeypatch):
    for k in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "DEEPGRAM_API_KEY"):
        monkeypatch.delenv(k, raising=False)


def test_empty_project_blocks_live_but_allows_ui_test(tmp_path):
    _app()
    cfg, path = _project(tmp_path)
    w = L.Launcher(cfg, path, tmp_path / ".state" / "launcher.json")
    w.set_choice(mode="live", asr="deepgram")
    reasons = " ".join(w.blocking_reasons())
    assert "missing resume" in reasons.lower() and "anthropic key not set" in reasons.lower()
    assert not w.start_btn.isEnabled() and "MISSING" in w.file_rows["resume"].text()
    w.set_choice(mode="ui_test")
    assert w.blocking_reasons() == [] and w.start_btn.isEnabled()
    w.close()


def test_drop_files_then_ready(tmp_path, monkeypatch):
    _app()
    monkeypatch.setattr(L, "_asr_available", lambda asr: None)   # pretend mlx-whisper is installed
    cfg, path = _project(tmp_path, f"ANTHROPIC_API_KEY={GOOD_ANTHROPIC}\n")
    w = L.Launcher(cfg, path, tmp_path / ".state" / "launcher.json")
    w.set_choice(mode="live", asr="local", answers="haiku")
    assert w.key_rows["anthropic"].text().count("format OK") == 1
    src = tmp_path / "downloads"
    src.mkdir()
    (src / "Jane Resume.md").write_text("Jane. Experience: SQL. Education: Sample University.")
    (src / "JD - Data Analyst.txt").write_text("Responsibilities: SQL. Requirements: Power BI.")
    (src / "qa.generated.md").write_text("## Q: Tell me about yourself\nKEY: analyst\nSAY: hi")
    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(p)) for p in src.iterdir()])
    ev = QDropEvent(QPointF(10, 10), Qt.DropAction.CopyAction, mime, Qt.MouseButton.LeftButton,
                    Qt.KeyboardModifier.NoModifier)
    w.dropEvent(ev)                                               # real drop event, same path as Finder
    assert w.file_rows["resume"].property("ok") and w.file_rows["job_description"].property("ok")
    assert "1 prepared answers" in w.file_rows["qa_generated"].text()
    assert "import" in w.log.toPlainText()
    assert w.blocking_reasons() == [] and w.start_btn.isEnabled()
    w.close()


def test_key_problems_block_and_show_reason(tmp_path):
    _app()
    cfg, path = _project(tmp_path, "ANTHROPIC_API_KEY=ssk-ant-api03-" + "B" * 95 + "\n"
                                   "OPENAI_API_KEY=sk-ant-api03-" + "C" * 95 + "\n")
    w = L.Launcher(cfg, path, None)
    assert "BEFORE the key" in w.key_rows["anthropic"].text()
    assert "Anthropic key" in w.key_rows["openai"].text()          # anthropic key in the openai line
    w.set_choice(mode="practice")
    assert any("Anthropic key has a problem" in r for r in w.blocking_reasons())
    w.close()


def test_start_returns_choice_and_remembers_it(tmp_path):
    _app()
    cfg, path = _project(tmp_path)
    state = tmp_path / ".state" / "launcher.json"
    got = []
    w = L.Launcher(cfg, path, state)
    w.started.connect(got.append)
    w.set_choice(mode="ui_test", asr="deepgram", answers="hybrid")
    w.start_btn.click()
    assert got and got[0] == L.LaunchChoice(mode="ui_test", asr="deepgram", answers="hybrid")
    assert json.loads(state.read_text())["answers"] == "hybrid"
    w2 = L.Launcher(cfg, path, state)                              # next launch pre-selects last choice
    assert w2.current_choice() == got[0]
    w2.close()


def test_apply_choice_does_not_touch_original_config(tmp_path):
    cfg, _ = _project(tmp_path)
    c2, demo, mock = L.apply_choice(cfg, L.LaunchChoice(mode="practice", asr="openai_realtime", answers="hybrid"))
    assert (c2.asr.provider, c2.llm.model, c2.llm.deep_model) == ("openai_realtime", L.HAIKU, L.SONNET)
    assert demo and not mock and cfg.asr.provider == "deepgram" and cfg.llm.deep_model == ""
    c3, demo, mock = L.apply_choice(cfg, L.LaunchChoice(mode="ui_test", answers="sonnet"))
    assert mock and c3.llm.provider == "mock" and c3.llm.model == L.SONNET


def test_background_job_streams_into_log(tmp_path):
    _app()
    cfg, path = _project(tmp_path)
    w = L.Launcher(cfg, path, None)

    def job():
        print("step one")
        print("step two", end="")
        return 7
    got = []
    w._run("demo job", job, after=got.append)
    assert not w.check_btn.isEnabled()                            # buttons locked while running
    end = time.time() + 5
    while not got and time.time() < end:
        _pump(0.05)
    assert got == [7] and "step one" in w.log.toPlainText() and "step two" in w.log.toPlainText()
    assert w.check_btn.isEnabled()
    w.close()


def test_run_py_goes_through_launcher(tmp_path, monkeypatch):
    """`python run.py` with no flags → launcher → overlay with the chosen settings."""
    import copilot.app as appmod
    import copilot.ui.overlay as ov_mod
    from PyQt6.QtCore import QTimer
    _app()
    _project(tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(L, "run_launcher", lambda cfg, p, s: L.LaunchChoice(mode="ui_test", answers="hybrid"))
    seen = {}
    orig = ov_mod.Overlay.__init__

    def init(self, cfg, sink, ctl, model_name, *a, **k):
        orig(self, cfg, sink, ctl, model_name, *a, **k)
        seen["model"] = model_name
        seen["demo"] = self.input is not None
        QTimer.singleShot(200, QApplication.instance().quit)
    monkeypatch.setattr(ov_mod.Overlay, "__init__", init)
    assert appmod.main(["--no-hotkeys"]) == 0
    assert seen == {"model": "mock + mock-deep", "demo": True}

    monkeypatch.setattr(L, "run_launcher", lambda cfg, p, s: None)   # launcher closed → just exit
    assert appmod.main([]) == 0
