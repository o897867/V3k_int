"""The bundled knowledge.example/ is a FICTIONAL candidate. Bug report: `prepare` ran on it and produced
answers about 'Harbour FX' that the user could have read out in a real interview. It must be impossible to
use example data for anything but a labelled demo."""
from pathlib import Path

from copilot import prepare
from copilot.app import main as app_main
from copilot.config import Config, load_config
from copilot.knowledge import load_knowledge

ROOT = Path(__file__).resolve().parents[1]


def _cfg_for(kdir) -> Config:
    cfg = load_config(str(ROOT / "config.example.yaml"))
    cfg.knowledge.dir = str(kdir)
    return cfg


def test_default_config_points_at_users_own_folder():
    cfg = load_config(str(ROOT / "config.example.yaml"))
    assert Path(cfg.path(cfg.knowledge.dir)).name == "knowledge"


def test_example_folder_is_detected():
    kb = load_knowledge(_cfg_for(ROOT / "knowledge.example"))
    assert kb.is_example and kb.example_marker
    assert "resume.md" in kb.example_files
    assert "FICTIONAL EXAMPLE" in kb.data_warning()


def test_copied_example_files_are_still_detected(tmp_path):
    """User copies example files into their own folder and forgets to replace one of them."""
    (tmp_path / "resume.md").write_text((ROOT / "knowledge.example" / "resume.md").read_text())
    (tmp_path / "jd.md").write_text("Data Analyst at a real company. SQL, Power BI.")
    kb = load_knowledge(_cfg_for(tmp_path))
    assert not kb.example_marker and kb.example_files == ["resume.md"] and kb.is_example


def test_users_own_data_is_not_flagged(tmp_path):
    (tmp_path / "resume.md").write_text("Jane Doe. Data analyst. SQL, Python.")
    (tmp_path / "jd.md").write_text("Data Analyst. SQL.")
    kb = load_knowledge(_cfg_for(tmp_path))
    assert not kb.is_example and kb.data_warning() == ""


def test_missing_resume_is_warned(tmp_path):
    (tmp_path / "jd.md").write_text("Data Analyst. SQL.")
    kb = load_knowledge(_cfg_for(tmp_path))
    assert kb.missing_core() == ["resume"] and "No resume" in kb.data_warning()


def _write_cfg(tmp_path, kdir):
    cfg = tmp_path / "config.yaml"
    cfg.write_text((ROOT / "config.example.yaml").read_text().replace('dir: "./knowledge"', f'dir: "{kdir}"'))
    return str(cfg)


def test_prepare_refuses_example_data(tmp_path, capsys, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "x")  # must refuse before any network call
    code = prepare.main(["--config", _write_cfg(tmp_path, ROOT / "knowledge.example")])
    assert code == 2 and "FICTIONAL" in capsys.readouterr().out
    assert not (ROOT / "knowledge.example" / "qa.generated.md").exists()


def test_prepare_refuses_without_resume(tmp_path, capsys, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "x")
    kdir = tmp_path / "k"
    kdir.mkdir()
    (kdir / "jd.md").write_text("Data Analyst. SQL.")
    assert prepare.main(["--config", _write_cfg(tmp_path, kdir)]) == 2
    assert "no resume" in capsys.readouterr().out


def test_real_session_refuses_example_data(tmp_path):
    # non-demo run must stop before touching audio / Qt
    assert app_main(["--config", _write_cfg(tmp_path, ROOT / "knowledge.example"), "--mock-llm",
                     "--no-hotkeys"]) == 2


def test_demo_example_shows_red_banner(tmp_path):
    import os
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PyQt6.QtWidgets import QApplication
    from copilot.ui.bridge import QtSink
    from copilot.ui.overlay import Overlay
    app = QApplication.instance() or QApplication([])
    cfg = _cfg_for(ROOT / "knowledge.example")
    kb = load_knowledge(cfg)

    class Ctl:
        model_name = "mock"
    ov = Overlay(cfg, QtSink(), Ctl(), "mock", demo=True, data_warning=kb.data_warning())
    ov.show()
    app.processEvents()
    assert ov.warn_lb.isVisibleTo(ov) and "FICTIONAL" in ov.warn_lb.text()
    ov.close()
