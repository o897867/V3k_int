"""The hand-made materials (art.py) and controls (widgets.py): deterministic, cached, readable, and still ordinary
widgets underneath."""
import os
import time
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PyQt6")
from PyQt6.QtCore import QPointF, QRectF  # noqa: E402
from PyQt6.QtGui import QColor, QImage, QPainter  # noqa: E402
from PyQt6.QtWidgets import QApplication, QButtonGroup  # noqa: E402

from copilot.config import load_config  # noqa: E402
from copilot.events import PreparedMatch, Question  # noqa: E402
from copilot.ui import art  # noqa: E402
from copilot.ui import theme as TH  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
_APP = []


def _app():
    if not _APP:
        _APP.append(QApplication.instance() or QApplication([]))
    return _APP[0]


def _pump(s=0.05):
    end = time.time() + s
    while time.time() < end:
        _app().processEvents()
        time.sleep(0.01)


def _canvas(w=200, h=200, fill="#f3efe5"):
    img = QImage(w, h, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(QColor(fill))
    return img


def _ink_pixels(img, bg="#f3efe5"):
    b = QColor(bg)
    n = 0
    for y in range(0, img.height(), 2):
        for x in range(0, img.width(), 2):
            c = img.pixelColor(x, y)
            if abs(c.red() - b.red()) + abs(c.green() - b.green()) + abs(c.blue() - b.blue()) > 60:
                n += 1
    return n


def test_brush_and_enso_are_deterministic_and_draw_progressively():
    _app()
    imgs = []
    for _ in range(2):
        img = _canvas()
        p = QPainter(img)
        art.brush(p, QPointF(20, 20), QPointF(22, 180), 4, QColor("#1b1917"), seed=3)
        p.end()
        imgs.append(img)
    assert imgs[0] == imgs[1] and _ink_pixels(imgs[0]) > 30            # same seed → same stroke, every repaint
    counts = []
    for sw in (0.2, 0.6, 1.0):
        img = _canvas()
        p = QPainter(img)
        art.enso(p, QRectF(20, 20, 160, 160), QColor("#1b1917"), sweep=sw, level=-1)
        p.end()
        counts.append(_ink_pixels(img))
    assert counts[0] < counts[1] < counts[2]                            # the brush travels
    img = _canvas()
    p = QPainter(img)
    art.enso(p, QRectF(20, 20, 160, 160), QColor("#1b1917"), sweep=1.0, level=-1)
    p.end()
    assert img.pixelColor(100, 100) == QColor("#f3efe5")                # the centre stays empty (level < 0)


def test_seal_is_vermilion_with_carved_characters_and_cached():
    _app()
    shu = QColor(art.SHU["washi"])
    px = art.seal_pixmap("備", 40, 40, shu, seed=1, dpr=1.0)
    assert art.seal_pixmap("備", 40, 40, shu, seed=1, dpr=1.0) is px
    img = px.toImage()
    reds = sum(1 for y in range(40) for x in range(40) if img.pixelColor(x, y).alpha() > 200
               and img.pixelColor(x, y).red() > 150 and img.pixelColor(x, y).green() < 100)
    holes = sum(1 for y in range(10, 30) for x in range(10, 30) if img.pixelColor(x, y).alpha() < 60)
    assert reds > 500 and holes > 25                                     # red ink with the character cut out
    tall = art.seal_pixmap("从容", 22, 38, shu, seed=2, dpr=1.0)
    assert tall.width() == 22 and tall.height() == 38


def test_seal_label_colour_is_readable():
    for name in ("sumi", "washi"):
        assert TH.contrast("#fbf5ea", art.SHU[name]) >= 4.5


def test_paper_and_mountains():
    _app()
    a = art.paper(120, 90, False, QColor("#f3efe5"), dpr=1.0)
    assert art.paper(120, 90, False, QColor("#f3efe5"), dpr=1.0) is a and a.width() == 120
    img = a.toImage()
    colours = {img.pixelColor(x, y).name() for x in range(0, 120, 7) for y in range(0, 90, 7)}
    assert len(colours) > 8                                              # textured, not a flat fill
    canvas = _canvas(400, 180)
    p = QPainter(canvas)
    art.mountains(p, QRectF(0, 0, 400, 180), QColor("#1b1917"), False, seed=4)
    p.end()
    left = sum(_ink_pixels(canvas.copy(0, 0, 120, 180)) for _ in [0])
    right = _ink_pixels(canvas.copy(280, 0, 120, 180), )
    assert right > left                                                  # quiet on the left for the title
    icon = art.app_icon_pixmap(128)
    assert icon.width() == 128 and not icon.isNull()


def test_ink_tab_and_seal_button_behave_like_buttons():
    _app()
    from copilot.ui.widgets import InkTab, SealButton
    grp = QButtonGroup()
    tabs = [InkTab(t, lambda: TH.WASHI) for t in ("Interview", "Mic test")]
    for t in tabs:
        grp.addButton(t)
    tabs[0].setChecked(True)
    tabs[1].click()
    assert tabs[1].isChecked() and not tabs[0].isChecked()
    assert not tabs[0].grab().isNull() and tabs[0].sizeHint().width() > 60
    got = []
    b = SealButton("Start", lambda: TH.SUMI)
    b.clicked.connect(lambda: got.append(1))
    b.resize(b.sizeHint())
    on = b.grab().toImage()
    b.setEnabled(False)
    off = b.grab().toImage()
    red = lambda im: sum(1 for x in range(0, im.width(), 3) for y in range(0, im.height(), 3)  # noqa: E731
                         if im.pixelColor(x, y).red() > 150 and im.pixelColor(x, y).green() < 110)
    assert red(on) > 50 and red(off) == 0                                # vermilion only when you can press it
    b.setEnabled(True)
    b.click()
    assert got == [1]


def test_overlay_seal_is_stamped_once_and_zen_breathes(tmp_path):
    _app()
    from copilot.ui.bridge import QtSink
    from copilot.ui.overlay import Overlay, ZenView

    class Ctl:
        model_name = "m"
    cfg = load_config(str(ROOT / "config.example.yaml"))
    sink = QtSink()
    ov = Overlay(cfg, sink, Ctl(), "m", state_path=tmp_path / "ui.json")
    ov.show()
    _pump()
    assert ov.zen.isVisibleTo(ov)                                        # nothing asked yet → the breathing ensō
    b = [ov.zen.breath() for _ in range(2)]
    assert all(0.0 <= x <= 1.0 for x in b)
    sink.on_question(Question(1, "Tell me about yourself", 0, 0))
    sink.on_prepared(1, PreparedMatch("Tell me about yourself", "KEY: k\nSAY: s", 0.9, True), False)
    _pump()
    assert not ov.zen.isVisibleTo(ov) and ov.prep_lb.seal is not None and 1 in ov._stamped
    _pump(0.4)
    assert ov.prep_lb.seal_t == 1.0                                      # the stamp settles in ~260 ms
    ov._render()
    _pump(0.05)
    assert ov.prep_lb.seal_t == 1.0                                      # re-rendering doesn't stamp again
    # new layers soak in, then lose their effect so the text is crisp
    sink.on_layer(1, "key", "k")
    sink.on_layer(1, "flow", "先说结论 | lead with it")
    _pump(0.4)
    assert ov.flow_lb.graphicsEffect() is None and ov.key_lb.graphicsEffect() is None
    # the header ensō draws itself while writing
    ov._set_state("thinking")
    ov.enso._t0 = time.monotonic()
    sweeps = set()
    for _ in range(8):
        ov.enso.tick()
        sweeps.add(round(ov.enso.sweep, 2))
        time.sleep(0.05)
    assert len(sweeps) > 3
    ov.close()
    assert isinstance(ov.zen, ZenView)
