"""Drag-and-drop / CLI import of the user's files into knowledge/."""
import zipfile
from datetime import datetime
from pathlib import Path

from copilot.config import Config
from copilot.importer import classify, import_paths
from copilot.knowledge import load_knowledge

ROOT = Path(__file__).resolve().parents[1]
T = datetime(2026, 9, 28, 10, 0, 0)


def _cfg(tmp_path) -> Config:
    cfg = Config()
    cfg.base_dir = str(tmp_path)
    cfg.knowledge.dir = "knowledge"
    return cfg


def _w(p: Path, text: str) -> Path:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    return p


def test_classify_by_name_and_content(tmp_path):
    d = tmp_path / "in"
    assert classify(_w(d / "Jane_Resume_2026.md", "x")) == "resume"
    assert classify(_w(d / "CV.txt", "x")) == "resume"
    assert classify(_w(d / "Data Analyst - Job Description.md", "x")) == "job_description"
    assert classify(_w(d / "qa.generated.md", "## Q: a\nKEY: b")) == "qa_generated"
    assert classify(_w(d / "qa.md", "## Q: a\nKEY: b")) == "qa"
    assert classify(_w(d / "cheatsheet.md", "TIMELINE")) == "cheatsheet"
    assert classify(_w(d / "Cover Letter - Acme.md", "x")) == "cover_letter"
    assert classify(_w(d / "简历.md", "x")) == "resume"
    # content sniffing when the name says nothing
    assert classify(_w(d / "doc1.md", "## Q: Tell me about yourself\nKEY: x")) == "qa"
    assert classify(_w(d / "doc2.md", "Dear Hiring Manager,\n...\nKind regards, S")) == "cover_letter"
    assert classify(_w(d / "doc3.md", "About the role\nResponsibilities\n- x\nRequirements\n- y")) == "job_description"
    assert classify(_w(d / "doc4.md", "Experience\n...\nEducation\n...\nSkills")) == "resume"
    assert classify(_w(d / "doc5.md", "hello world")) is None


def test_import_places_files_where_the_loader_reads_them(tmp_path):
    cfg = _cfg(tmp_path)
    src = tmp_path / "downloads"
    files = [_w(src / "My Resume.md", "Jane Doe. Experience: SQL. Education: Sample University."),
             _w(src / "jd.txt", "Data Analyst. Responsibilities: SQL. Requirements: Power BI."),
             _w(src / "qa.generated.md", "## Q: Tell me about yourself\nALT: Introduce yourself\nKEY: Analyst\nSAY: Hi"),
             _w(src / "cheatsheet.md", "TIMELINE\nAcme 2023–")]
    res = import_paths(cfg, files, now=T)
    assert all(r.ok for r in res), [r.message for r in res]
    kb = load_knowledge(cfg)
    assert "Jane Doe" in kb.get("resume") and "Power BI" in kb.get("job_description")
    assert kb.get("cheatsheet").startswith("TIMELINE")
    assert kb.qa.entries[0].question == "Tell me about yourself"
    assert not kb.is_example


def test_new_resume_replaces_old_one_with_another_extension(tmp_path):
    """resume.md from last time must not shadow a newly dropped resume.docx/pdf."""
    cfg = _cfg(tmp_path)
    kdir = tmp_path / "knowledge"
    _w(kdir / "resume.md", "OLD resume")
    new = _w(tmp_path / "in" / "resume.txt", "NEW resume. Experience. Education.")
    res = import_paths(cfg, [new], now=T)
    assert res[0].ok and "resume.md" in res[0].message
    assert not (kdir / "resume.md").exists()
    assert (kdir / ".backup" / "20260928-100000" / "resume.md").read_text() == "OLD resume"
    assert load_knowledge(cfg).get("resume").startswith("NEW")


def test_import_folder_and_zip_and_refuse_example(tmp_path):
    cfg = _cfg(tmp_path)
    old = tmp_path / "old-copilot" / "knowledge"
    _w(old / "resume.md", "Jane. Experience. Education.")
    _w(old / "qa.generated.md", "## Q: Why us?\nKEY: fit")
    _w(old / ".backup" / "x" / "resume.md", "ancient")          # hidden folders are ignored
    zp = tmp_path / "bundle.zip"
    with zipfile.ZipFile(zp, "w") as z:
        z.writestr("stuff/cover_letter.md", "Dear team,\nKind regards")
        z.writestr("stuff/unknown.md", "just notes about lunch")
    res = import_paths(cfg, [old, zp, ROOT / "knowledge.example" / "resume.md"], now=T)
    msgs = {r.source.name: r for r in res}
    assert msgs["resume.md"].ok is False or "Jane" in (tmp_path / "knowledge" / "resume.md").read_text()
    assert (tmp_path / "knowledge" / "qa.generated.md").exists()
    assert (tmp_path / "knowledge" / "cover_letter.md").exists()
    assert "not recognised" in msgs["unknown.md"].message
    example = [r for r in res if "FICTIONAL" in r.message]
    assert example and not example[0].ok
    assert "Jane" in (tmp_path / "knowledge" / "resume.md").read_text()


def test_ask_callback_for_unrecognised_file(tmp_path):
    cfg = _cfg(tmp_path)
    f = _w(tmp_path / "in" / "notes-for-acme.txt", "why I fit: SQL")  # 'notes' → analysis by name
    g = _w(tmp_path / "in" / "misc.txt", "random words")
    asked = []
    res = import_paths(cfg, [f, g], ask=lambda p, roles: asked.append(p.name) or "profile", now=T)
    assert asked == ["misc.txt"]
    assert {r.role for r in res} == {"my_analysis", "profile"}


def test_generated_answers_must_be_text(tmp_path):
    cfg = _cfg(tmp_path)
    p = tmp_path / "in" / "qa.generated.pdf"
    p.parent.mkdir(parents=True)
    p.write_bytes(b"%PDF-1.4 fake")
    res = import_paths(cfg, [p], now=T)
    assert not res[0].ok
