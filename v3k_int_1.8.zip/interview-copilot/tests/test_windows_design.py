"""v1.7 on Windows: type stacks, title-bar tint, icon sizes, shortcut plumbing — all testable on any OS."""
from __future__ import annotations

import os
import struct
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PyQt6")
from PyQt6.QtWidgets import QApplication  # noqa: E402

from copilot.ui import theme as TH  # noqa: E402
from copilot.ui import win_window as WW  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
_APP = []


@pytest.fixture
def qapp():
    if not _APP:
        _APP.append(QApplication.instance() or QApplication([]))
    return _APP[0]


def test_windows_stacks_put_latin_serif_first_and_avoid_simsun_for_text():
    st = TH.stacks(win=True)
    assert st["serif"][0].startswith("Sitka")
    assert "SimSun" not in st["serif"] and "SimSun" not in st["kai"]   # bitmap strikes at 14–16 px
    kai = st["kai"]
    assert kai.index("KaiTi") > kai.index("Georgia")                    # Latin never falls to KaiTi's Latin
    assert st["sans"][0].startswith("Segoe UI")
    assert st["mono"][0] == "Cascadia Mono"


def test_mac_stacks_unchanged_in_spirit():
    st = TH.stacks(win=False)
    assert st["serif"][:2] == ["Iowan Old Style", "Songti SC"]
    assert "Kaiti SC" in st["kai"]


@pytest.mark.parametrize("px,cut", [(10, "Sitka Small"), (15, "Sitka Text"), (22, "Sitka Subheading"),
                                    (30, "Sitka Heading")])
def test_windows_optical_sizes(px, cut):
    fams = TH.families("serif", px, win=True)
    assert fams[0] == cut and len(fams) == len(set(fams))


def test_css_family_quotes_every_name():
    css = TH.css_family("sans", 12, win=True)
    assert css.startswith('"Segoe UI Variable Text"') and '"Microsoft YaHei UI"' in css
    assert "'" not in css   # lives inside a single-quoted style attribute


def test_colorref_is_bgr():
    assert WW.colorref("#f3efe5") == 0x00E5EFF3
    assert WW.colorref("#1c1b19") == 0x00191B1C


def test_titlebar_matches_the_page():
    for t in (TH.SUMI, TH.WASHI):
        attrs = dict(WW.titlebar_attrs(t))
        assert attrs[20] == (1 if t.dark else 0)
        assert attrs[35] == WW.colorref(t.bg)
        assert attrs[36] == WW.colorref(t.muted)
        assert attrs[33] == 2


def test_windows_helpers_are_silent_elsewhere(qapp):
    from PyQt6.QtWidgets import QWidget
    WW.set_app_id()
    WW.tint_titlebar(QWidget(), TH.WASHI)


def test_ico_has_every_size_as_png():
    data = (ROOT / "copilot" / "ui" / "assets" / "icon.ico").read_bytes()
    reserved, kind, n = struct.unpack("<HHH", data[:6])
    assert (reserved, kind) == (0, 1) and n >= 8
    sizes = set()
    for i in range(n):
        w, h, _, _, _, _, length, off = struct.unpack("<BBBBHHII", data[6 + 16 * i: 22 + 16 * i])
        assert data[off:off + 8] == b"\x89PNG\r\n\x1a\n" and off + length <= len(data)
        sizes.add(w or 256)
    assert {16, 24, 32, 48, 256} <= sizes


def test_small_icons_are_drawn_not_shrunk(qapp):
    from copilot.ui import art
    for size in (16, 24, 32, 48, 256):
        img = art.app_icon_pixmap(size, win=True).toImage()
        assert img.width() == size
        red = sum(1 for x in range(size) for y in range(size)
                  if (c := img.pixelColor(x, y)).red() > 150 and c.green() < 110 and c.alpha() > 200)
        assert red > size * size * 0.015, size   # the seal survives at every size
    big = art.app_icon_pixmap(256, win=True).toImage()
    mac = art.app_icon_pixmap(256, win=False).toImage()
    assert big.pixelColor(19, 128).alpha() > 0 and mac.pixelColor(19, 128).alpha() == 0   # Windows bleeds wider


def test_shortcut_script_and_installer_hook():
    import subprocess
    import sys
    r = subprocess.run([sys.executable, str(ROOT / "scripts" / "win_shortcut.py")], capture_output=True, text=True)
    assert r.returncode == 0
    bat = (ROOT / "install.bat").read_bytes()
    assert b"scripts\\win_shortcut.py" in bat and b"\r\n" in bat
    bat.decode("ascii")
    src = (ROOT / "scripts" / "win_shortcut.py").read_text(encoding="utf-8")
    assert "IconLocation" in src and "icon.ico" in src and "$env:IC_TARGET" in src
    assert "win_shortcut.py" in (ROOT / "update.py").read_text(encoding="utf-8")


def test_follow_label_names_the_platform():
    assert TH.LABELS["auto"] in ("Follow macOS", "Follow Windows")
