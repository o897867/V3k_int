"""Nervous-user features: provisional prepared card before the endpoint, 1.5 s budget, bridge line,
clarify, stale-not-blank on merged follow-ups, focus/facts modes, Realtime URL fallback."""
import asyncio
import json
import os
import time
from pathlib import Path

import pytest

from copilot.config import Config, load_config
from copilot.engine.pipeline import Pipeline
from copilot.engine.question import question_topic
from copilot.events import RecordingSink, TranscriptEvent
from copilot.knowledge.loader import KnowledgeBase
from copilot.llm.mock_llm import MockLLM
from tests.test_core import QA_MD

ROOT = Path(__file__).resolve().parents[1]


def _kb():
    kb = KnowledgeBase()
    kb.qa.load_markdown(QA_MD)
    kb.qa.build()
    return kb


def test_provisional_prepared_card_before_endpoint():
    """The prepared answer is announced while the interviewer is still speaking (locked live match)."""
    async def go():
        sink = RecordingSink()
        p = Pipeline(Config(), MockLLM(ttft=5), _kb(), sink)
        await p.handle(TranscriptEvent("interim", "so could you"))
        await p.handle(TranscriptEvent("interim", "so could you walk me through"))
        await asyncio.sleep(0.3)  # live-match throttle
        await p.handle(TranscriptEvent("interim", "so could you walk me through your background"))
        live = [e for e in sink.of("prepared") if e[4] is True]
        qid_before = p._next_id
        await p.handle(TranscriptEvent("final", "So could you walk me through your background?"))
        await p.handle(TranscriptEvent("endpoint"))
        for job in (p._job, p._deep_job):
            if job:
                job.cancel()
        return live, qid_before, sink
    live, qid_before, sink = asyncio.run(go())
    assert live, "no live prepared event"
    assert live[-1][3].locked and live[-1][3].question == "Tell me about yourself"
    assert live[-1][2] == qid_before == sink.of("question")[0][2].id  # provisional card id == real question id


def test_prepared_budget_with_simulated_asr_delay():
    async def go():
        sink = RecordingSink()
        p = Pipeline(Config(), MockLLM(ttft=5), _kb(), sink)
        speech_end = time.monotonic()
        await asyncio.sleep(0.4)  # deepgram endpointing
        await p.handle(TranscriptEvent("final", "Why do you want to work here?", audio_end=speech_end))
        await p.handle(TranscriptEvent("endpoint", "", audio_end=speech_end))
        t_layers = [e for e in sink.of("layer") if e[3] in ("key", "say")]
        p._job.cancel()
        return p.prepared_metrics, t_layers, speech_end
    pm, layers, speech_end = asyncio.run(go())
    assert pm and pm[0]["within_budget"] and pm[0]["speech_end_to_prepared"] < 0.5
    assert layers and all(e[0] - speech_end < 0.5 for e in layers)


def test_bridge_line_only_for_unprepared_questions():
    async def go():
        sink = RecordingSink()
        p = Pipeline(Config(), MockLLM(ttft=0.02, tok_per_s=5000), _kb(), sink)
        await p.inject_text("Tell me about a time you had to deal with a difficult stakeholder.")
        await p.wait_idle()
        await asyncio.sleep(0)
        await p.inject_text("Why do you want to work here?")
        await p.wait_idle()
        return sink
    sink = asyncio.run(go())
    bridges = [e for e in sink.of("layer") if e[3] == "bridge"]
    assert len(bridges) == 1 and bridges[0][2] == 1
    assert bridges[0][4] in Config().engine.bridge_phrases["behavioural"]


@pytest.mark.parametrize("q,topic", [
    ("Tell me about a time you disagreed with your manager", "behavioural"),
    ("How would you find duplicate rows in SQL?", "technical"),
    ("Why do you want to work here?", "motivation"),
    ("What do you do on weekends?", "general"),
])
def test_question_topic(q, topic):
    assert question_topic(q) == topic


def test_clarify_discards_half_heard_utterance():
    async def go():
        sink = RecordingSink()
        p = Pipeline(Config(), MockLLM(), _kb(), sink)
        await p.handle(TranscriptEvent("interim", "and the thing about the"))
        text = p.clarify()
        assert p._parts == [] and p._interim == ""
        return text, sink
    text, sink = asyncio.run(go())
    assert text in Config().engine.bridge_phrases["clarify"]
    assert [e for e in sink.of("layer") if e[3] == "clarify"]


def test_realtime_url_fallback(monkeypatch):
    from websockets.asyncio.server import serve
    from copilot.asr.openai_realtime import OpenAIRealtimeASR

    async def handler(ws):
        async for _ in ws:
            pass

    async def go():
        async with serve(handler, "127.0.0.1", 0) as server:
            port = server.sockets[0].getsockname()[1]
            cfg = Config().asr.openai_realtime
            cfg.url = "ws://127.0.0.1:1/"  # nothing listens here
            cfg.fallback_urls = [f"ws://127.0.0.1:{port}/"]
            monkeypatch.setenv("OPENAI_API_KEY", "k")
            asr = OpenAIRealtimeASR(cfg)
            ws = await asyncio.wait_for(asr._connect(), timeout=10)
            await ws.close()
            return cfg.url
    assert asyncio.run(go()).endswith(f"/")
    # the working URL is remembered for reconnects
    

# ------------------------------------------------------------------ overlay behaviour (offscreen)

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
PyQt6 = pytest.importorskip("PyQt6")
from PyQt6.QtWidgets import QApplication  # noqa: E402

from copilot.app import EngineThread  # noqa: E402
from copilot.events import PreparedMatch, Question  # noqa: E402
from copilot.knowledge import load_knowledge  # noqa: E402
from copilot.ui.bridge import QtSink  # noqa: E402
from copilot.ui.overlay import Overlay  # noqa: E402


def _pump(app, secs):
    end = time.time() + secs
    while time.time() < end:
        app.processEvents()
        time.sleep(0.01)


def _overlay(deep=None, facts="NOTICE 4 weeks"):
    app = QApplication.instance() or QApplication([])
    cfg = load_config(str(ROOT / "config.example.yaml"))
    cfg.knowledge.dir = str(ROOT / "knowledge.example")
    kb = load_knowledge(cfg)
    sink = QtSink()
    pipe = Pipeline(cfg, MockLLM(ttft=0.05, tok_per_s=1500), kb, sink, deep_llm=deep)
    eng = EngineThread(pipe, None, None, pipe.llm, sink, warmup=False)
    ov = Overlay(cfg, sink, eng, eng.model_name, demo=True, facts_text=facts)
    ov.show()
    eng.start()
    _pump(app, 0.2)
    return app, ov, eng, pipe, sink


def test_overlay_provisional_then_locked_then_alt(tmp_path):
    app, ov, eng, pipe, sink = _overlay()
    # live locked match → provisional card with the full prepared answer, before any question event
    sink.on_prepared(pipe._next_id, PreparedMatch("Tell me about yourself", pipe.kb.qa.entries[0].answer, 0.9, True), True)
    _pump(app, 0.1)
    c = ov._current()
    assert c.provisional and c.key.startswith("[EXAMPLE] Analyst bridging") and c.say
    assert "listening" in ov.q_lb.text()
    # the real question arrives with the same id → same card, no blanking
    eng.inject_text("Could you walk me through your background?")
    _pump(app, 1.2)
    c2 = ov._current()
    assert c2 is c and not c2.provisional and c2.key.startswith("[EXAMPLE] Analyst bridging")
    assert c2.prepared.locked and ov.prep_lb.isVisibleTo(ov)
    # model went to the ALT block, main SAY is still the prepared text
    assert c2.blocks["alt"]["key"] and c2.blocks["alt"]["done"]
    assert "I'm a data analyst at Example Brokerage" in c2.say
    # the model's version is collapsed by default (prepared answer is the one to read); one click expands it
    assert ov.block_hdr["alt"].isVisibleTo(ov) and ov.block_hdr["alt"].text().startswith("▸")
    assert not ov.block_lb["alt"].isVisibleTo(ov)
    ov.block_hdr["alt"].click()
    assert ov.block_lb["alt"].isVisibleTo(ov) and ov.block_hdr["alt"].text().startswith("▾")
    out = os.environ.get("OVERLAY_SCREENSHOT_LOCKED")
    if out:
        ov.grab().save(out)
    eng.stop()
    ov.close()


def test_overlay_merged_followup_keeps_old_text_dimmed():
    app, ov, eng, pipe, sink = _overlay()
    eng.inject_text("How do you handle missing data in a pipeline?")
    _pump(app, 1.0)
    old_key = ov._current().key
    assert old_key
    q2 = Question(2, "How do you handle missing data in a pipeline? Especially for time series.", 0, 0, merged_from=1)
    sink.on_question(q2)
    _pump(app, 0.05)
    c = ov._current()
    assert c.stale and c.key == old_key and "updating" in ov.q_lb.text()   # not blank
    sink.on_layer(2, "key", "New key for the merged question")
    _pump(app, 0.05)
    assert "key" not in c.stale and c.key == "New key for the merged question"
    assert c.say and "say" in c.stale  # old SAY still readable (dimmed) until the new one arrives
    eng.stop()
    ov.close()


def test_overlay_bridge_focus_facts_clarify():
    app, ov, eng, pipe, sink = _overlay()
    sink.on_question(Question(7, "Tell me about a time you failed.", 0, 0))
    sink.on_layer(7, "bridge", "Sure — let me think of a specific example.")
    _pump(app, 0.05)
    assert ov.bridge_lb.isVisibleTo(ov) and "say now" in ov.bridge_lb.text()
    sink.on_layer(7, "key", "Own the mistake, show the fix")
    _pump(app, 0.05)
    assert not ov.bridge_lb.isVisibleTo(ov)  # bridge disappears once KEY exists
    # focus mode: only KEY + SAY, larger
    base = ov.key_lb.font().pixelSize()
    ov.on_hotkey("focus")
    assert ov.focus and ov.key_lb.font().pixelSize() > base and not ov.tr_lb.isVisibleTo(ov)
    sink.on_layer(7, "points", "a\nb")
    _pump(app, 0.05)
    assert not ov.pts_lb.isVisibleTo(ov)
    ov.on_hotkey("focus")
    assert ov.pts_lb.isVisibleTo(ov)
    # facts panel
    ov.on_hotkey("facts")
    assert ov.facts_lb.isVisibleTo(ov) and "NOTICE 4 weeks" in ov.facts_lb.text() and not ov.key_lb.isVisibleTo(ov)
    ov.on_hotkey("facts")
    assert not ov.facts_lb.isVisibleTo(ov) and ov.key_lb.isVisibleTo(ov)
    # clarify
    ov.on_hotkey("clarify")
    _pump(app, 0.2)
    assert ov.clarify_lb.isVisibleTo(ov) and ov.clarify_text
    eng.stop()
    ov.close()


# ------------------------------------------------------------------ round-2 fixes

def test_provisional_prepared_is_never_overwritten_when_final_match_is_weaker():
    """#6: prepared answer shown while they spoke; final wording no longer locks → it stays in the main
    layers (flagged unconfirmed) and the model goes to the ALT block."""
    async def go():
        sink = RecordingSink()
        p = Pipeline(Config(), MockLLM(ttft=0.02, tok_per_s=5000), _kb(), sink)
        await p.handle(TranscriptEvent("interim", "could you walk me through your background"))
        assert p._live_locked is not None
        # they finish with something that drifts away from the prepared question
        await p.handle(TranscriptEvent("final", "could you walk me through how you would migrate our reporting "
                                                "stack to Snowflake and dbt over the next quarter"))
        await p.handle(TranscriptEvent("endpoint"))
        await p.wait_idle()
        return sink
    sink = asyncio.run(go())
    q = sink.of("question")[0][2]
    main = [e for e in sink.of("layer") if e[2] == q.id and e[3] in ("key", "points", "say")]
    alt = [e for e in sink.of("layer") if e[2] == q.id and e[3].startswith("alt_")]
    assert not main, "model must not write to the main layers over a provisional prepared answer"
    assert alt
    prep = [e for e in sink.of("prepared") if e[2] == q.id and not e[4]]
    assert prep and prep[-1][3].unconfirmed


def test_statement_trigger_flags_question():
    async def go():
        sink = RecordingSink()
        p = Pipeline(Config(), MockLLM(ttft=0.01, tok_per_s=5000), KnowledgeBase(), sink)
        await p.inject_text("So our team is mostly focused on the trading desk and we have been rebuilding the "
                            "whole reporting layer this year with a lot of pressure on data quality and speed")
        await p.wait_idle()
        return sink
    sink = asyncio.run(go())
    q = sink.of("question")[0][2]
    assert q.from_statement


def test_overlay_merge_keeps_each_layer_until_replaced():
    """#5: when a merged follow-up's new KEY arrives, the old SAY must stay (dimmed) until the new SAY arrives."""
    app, ov, eng, pipe, sink = _overlay()
    sink.on_question(Question(1, "How do you handle missing data?", 0, 0))
    for layer, text in (("key", "Old key"), ("points", "old a\nold b"), ("say", "Old say paragraph")):
        sink.on_layer(1, layer, text)
    _pump(app, 0.05)
    sink.on_question(Question(2, "How do you handle missing data? Especially time series.", 0, 0, merged_from=1))
    sink.on_layer(2, "key", "New key")
    _pump(app, 0.05)
    c = ov._current()
    assert c.key == "New key" and c.say == "Old say paragraph" and c.points == "old a\nold b"
    assert c.stale == {"points", "say"} and ov.say_lb.isVisibleTo(ov) and "updating" in ov.q_lb.text()
    sink.on_layer(2, "say", "New say")
    sink.on_layer(2, "points", "new a")
    _pump(app, 0.05)
    assert not c.stale and "updating" not in ov.q_lb.text()
    eng.stop()
    ov.close()


def test_overlay_labels_statement_and_unconfirmed():
    app, ov, eng, pipe, sink = _overlay()
    sink.on_question(Question(3, "Our team rebuilt the reporting layer this year…", 0, 0, from_statement=True))
    _pump(app, 0.05)
    assert "may not be a question" in ov.q_lb.text()
    sink.on_prepared(3, PreparedMatch("Tell me about yourself", "KEY: x\nSAY: y", 0.8, True, unconfirmed=True), False)
    _pump(app, 0.05)
    assert "unconfirmed" in ov.q_lb.text()
    eng.stop()
    ov.close()
