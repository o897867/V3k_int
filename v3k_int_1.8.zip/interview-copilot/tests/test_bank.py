"""Question bank + reference answers documents → prepared answers (qa.bank.md)."""
import asyncio
import json
from pathlib import Path

from copilot.config import load_config
from copilot.importer import import_paths
from copilot.knowledge import bank as B
from copilot.knowledge import load_knowledge
from copilot.knowledge.prompt import build_system_blocks
from copilot.llm.layered_parser import parse_layers

QUESTIONS = r"""# Sample Analyst 面试题库

Sep 26, 2026 · @Someone

## 一、开场与动机（HR 主导）

- **O1 ★★★** Tell us a bit about yourself and how you got into data analytics.
  - 听什么：两分钟内落到 Power BI 报表和数据质量。
- **O3 ★★★** Why this role, and why community health after working in trading platforms?
  - 听什么：一个具体、真实的理由。
- **R3 ★★★** Walk us through the KPI suite from end to end: sources, model, key measures, and who used it.
  - 听什么：源 → 模型 → measure → 发布 → 使用者。
  - 追问：Which KPI was hardest to define, and why? What would you build differently now?

## 四、Power BI 技术题 B：DAX

- **D6 ★★★ \[中级\]** Live: write a measure for unique clients seen in the current financial year.
  - 参考：`CALCULATE(DISTINCTCOUNT(Contacts[ClientID]), DATESYTD('Date'[Date], "30/6"))`。
- **D11 ★★ \[基础\]** Why use DIVIDE instead of the slash operator? Why use variables?
- **P6 ★ \[基础\]** A spreadsheet has one column per month. How do you make it usable?
  - 听什么：Unpivot。
- **Z9 ★** A question nobody has answered yet?
"""

ANSWERS = r"""# 参考答案

每题给一段可以直接开口的英文答案。

## 一、开场与动机

**O1 · Tell us about yourself.**

I'm a data analyst based in Sydney with three years in reporting. Most recently I built Power BI reporting
for Operations and Compliance.

*要点：控制在 90 秒。*

**O3 · Why this role, and why community health?**

Three reasons. First, the work itself: Power BI and data quality. Second, the stakes. Third, \[a true personal reason\].

**R3 · Walk us through the KPI suite end to end.**

Sources: \[the platform database\], loaded daily.

Model: a star schema, at \[one row per X\], with one proper date table.

**D6 · Live: unique clients seen this financial year.**

```dax
Clients FYTD =
CALCULATE (
    DISTINCTCOUNT ( Contacts[ClientID] ),
    DATESYTD ( 'Date'[Date], "30/6" )
)
```

DISTINCTCOUNT because a client seen ten times counts once. I'd add Contacts\[Status\] = "Attended" if needed.

**D11 · Why DIVIDE and variables?**

DIVIDE handles division by zero. Variables store a value once:

- it's calculated once
- the measure is easier to read

**P6 · A spreadsheet with one column per month?**

Unpivot it. Select the columns that identify the row, then choose Unpivot Other Columns.
"""


def _cfg(tmp_path):
    cfg = load_config(None)
    cfg.base_dir = str(tmp_path)
    cfg.knowledge.dir = str(tmp_path / "knowledge")
    return cfg


def test_detect_and_parse():
    assert B.detect(QUESTIONS) == "questions" and B.detect(ANSWERS) == "answers"
    assert B.detect("# Resume\nExperience\nEducation") is None
    qs, ans = B.parse_questions(QUESTIONS), B.parse_answers(ANSWERS)
    assert list(qs) == ["O1", "O3", "R3", "D6", "D11", "P6", "Z9"]
    assert qs["O1"].stars == 3 and qs["D6"].level == "中级" and qs["O1"].listen.startswith("两分钟")
    assert qs["R3"].followups == ["Which KPI was hardest to define, and why?", "What would you build differently now?"]
    assert ans["O1"].notes == ["控制在 90 秒。"] and "Sydney" in ans["O1"].prose[0]
    assert "DISTINCTCOUNT ( Contacts[ClientID] )" in ans["D6"].code[0]
    assert ans["D11"].prose[-2:] == ["• it's calculated once", "• the measure is easier to read"]
    assert "Contacts[Status]" in ans["D6"].prose[0]          # markdown escapes removed


def test_placeholders_ignore_code_brackets():
    assert B.placeholders("Sources: [the platform database], loaded daily.") == ["the platform database"]
    assert B.placeholders("Roughly [X]% was pipelines") == ["X"]
    assert B.placeholders("I'd add Contacts[Status] = \"Attended\"; Site[Name] = \"North Campus\"") == []
    assert B.placeholders("My official title was ___.") == ["___"]


def test_merge_layers_and_markdown_roundtrip():
    es = {e.id: e for e in B.merge(B.parse_questions(QUESTIONS), B.parse_answers(ANSWERS))}
    assert "Z9" not in es                                     # no answer → not an instant answer
    d6 = es["D6"]
    assert d6.question.startswith("Write a measure")          # "Live:" prefix removed
    assert d6.points[0].startswith("⌨ Clients FYTD = CALCULATE (DISTINCTCOUNT (Contacts[ClientID])")
    o3 = es["O3"]
    assert o3.todo == ["a true personal reason"] and o3.points[0].startswith("⚠ 待填")
    assert "why community health after working in trading platforms?" in o3.alts
    assert "[" not in es["R3"].key and es["R3"].key.startswith("Sources: …")
    md = B.to_markdown(list(es.values()), ["questions.md", "answers.md"])
    from copilot.knowledge.qa_bank import QABank
    bank = QABank()
    bank.load_markdown(md, "qa.bank.md")
    assert len(bank.entries) == 6
    L = parse_layers(next(e for e in bank.entries if e.question.startswith("Tell us a bit")).answer)
    assert L["zh"].startswith("两分钟") and "💡 控制在 90 秒" in L["points"]
    assert L["say"].startswith("I'm a data analyst") and "id:" not in L["say"] and "<!--" not in L["say"]


def test_import_by_drop_pairs_documents_across_drops(tmp_path):
    cfg = _cfg(tmp_path)
    src = tmp_path / "downloads"
    src.mkdir()
    (src / "面试题库.md").write_text(QUESTIONS)          # names that the filename rules would call "qa"
    (src / "参考答案.md").write_text(ANSWERS)
    res = import_paths(cfg, [src / "面试题库.md"])
    assert any("question bank" in r.message for r in res)
    assert any("no answers yet" in r.message for r in res)
    kdir = tmp_path / "knowledge"
    assert not (kdir / "qa.md").exists()                     # never copied as a raw qa.md
    res = import_paths(cfg, [src / "参考答案.md"])           # later drop pairs with the stored question bank
    msg = " ".join(r.message for r in res)
    assert "6 prepared answers → qa.bank.md" in msg and "placeholders" in msg and "O3" in msg
    kb = load_knowledge(cfg)
    assert sum(1 for e in kb.qa.entries if e.source == "qa.bank.md") == 6
    m = kb.qa.match("Why are you interested in community health?")
    assert m and m[0].question.startswith("Why this role") and m[1] >= cfg.engine.instant_match_threshold
    # dropping an updated answers file replaces the old one (backed up) and rebuilds
    (src / "参考答案.md").write_text(ANSWERS.replace("\\[a true personal reason\\]", "my mother is a nurse"))
    import_paths(cfg, [src / "参考答案.md"])
    kb = load_knowledge(cfg)
    o3 = next(e for e in kb.qa.entries if e.question.startswith("Why this role"))
    assert "nurse" in o3.answer and "⚠ 待填" not in o3.answer
    assert list((kdir / ".backup").rglob("bank-answers.md"))


def test_own_answers_beat_generated_duplicates(tmp_path):
    cfg = _cfg(tmp_path)
    kdir = tmp_path / "knowledge"
    kdir.mkdir()
    B.build(kdir, _write(tmp_path / "q.md", QUESTIONS), _write(tmp_path / "a.md", ANSWERS))
    (kdir / "qa.generated.md").write_text(
        "## Q: Tell us a bit about yourself and how you got into data analytics\nALT: Walk me through your background\n"
        "KEY: generated\nSAY: generated answer\n\n"
        "## Q: How do you handle stakeholder conflict?\nKEY: gen\nSAY: gen conflict\n")
    kb = load_knowledge(cfg)
    assert kb.qa_dropped == 1
    gen = [e for e in kb.qa.entries if e.source == "qa.generated.md"]
    assert [e.question for e in gen] == ["How do you handle stakeholder conflict?"]
    assert kb.qa.match("tell us about yourself")[0].source == "qa.bank.md"


def test_prompt_contains_bank_and_placeholder_rule(tmp_path):
    cfg = _cfg(tmp_path)
    kdir = tmp_path / "knowledge"
    kdir.mkdir()
    B.build(kdir, _write(tmp_path / "q.md", QUESTIONS), _write(tmp_path / "a.md", ANSWERS))
    blocks = build_system_blocks(cfg, load_knowledge(cfg))
    assert "unfilled placeholder" in blocks[0]["text"]
    assert "Unpivot Other Columns" in blocks[1]["text"] and blocks[1].get("cache_control")


def test_check_reports_self_locks(tmp_path):
    cfg = _cfg(tmp_path)
    kdir = tmp_path / "knowledge"
    kdir.mkdir()
    B.build(kdir, _write(tmp_path / "q.md", QUESTIONS), _write(tmp_path / "a.md", ANSWERS))
    r = B.check(load_knowledge(cfg), cfg.engine.instant_lock_threshold)
    assert r["wrong"] == [] and r["ok"] >= 6


def test_enrich_adds_alts_and_is_incremental(tmp_path):
    cfg = _cfg(tmp_path)
    kdir = tmp_path / "knowledge"
    kdir.mkdir()
    B.build(kdir, _write(tmp_path / "q.md", QUESTIONS), _write(tmp_path / "a.md", ANSWERS))
    prompts = []

    async def fake(prompt):
        prompts.append(prompt)
        ids = [ln[4:] for ln in prompt.splitlines() if ln.startswith("ID: ")]
        return "Sure:\n" + json.dumps({i: {"alts": [f"spoken way {i}", "How'd you get into data?"],
                                           "key": f"key {i}", "points": ["p1", "p2", "p3"],
                                           "flow": ["先说结论 | the headline", "再举例 | an example"]}
                                       for i in ids})
    n = asyncio.run(B.enrich(cfg, kdir, call=fake, batch_size=4, log=lambda *_: None))
    assert n == 6 and len(prompts) == 2
    assert "[a true personal reason]" in "".join(prompts)       # placeholders passed through, never filled
    kb = load_knowledge(cfg)
    o1 = next(e for e in kb.qa.entries if e.question.startswith("Tell us a bit"))
    assert "How'd you get into data?" in o1.alts
    L = parse_layers(o1.answer)
    assert L["key"] == "key O1" and L["points"].startswith("p1")
    assert L["flow"].split("\n") == ["先说结论 | the headline", "再举例 | an example"]
    # second run: nothing changed → no calls; change one answer → only that one is redone
    assert asyncio.run(B.enrich(cfg, kdir, call=fake, log=lambda *_: None)) == 0 and len(prompts) == 2
    a = (kdir / "bank" / "answers.md")
    a.write_text(a.read_text().replace("Unpivot it.", "Unpivot it, always."))
    assert asyncio.run(B.enrich(cfg, kdir, call=fake, log=lambda *_: None)) == 1


def test_cli_build_and_check(tmp_path, capsys):
    (tmp_path / "config.yaml").write_text(f'knowledge:\n  dir: "{tmp_path / "k"}"\n')
    q, a = _write(tmp_path / "bank.md", QUESTIONS), _write(tmp_path / "ans.md", ANSWERS)
    assert B.main(["--config", str(tmp_path / "config.yaml"), "build", str(q), str(a)]) == 0
    assert "6 prepared answers" in capsys.readouterr().out
    assert B.main(["--config", str(tmp_path / "config.yaml"), "check"]) == 0
    assert "lock onto the right answer" in capsys.readouterr().out


def _write(p: Path, text: str) -> Path:
    p.write_text(text, encoding="utf-8")
    return p


def test_launcher_shows_bank_row_and_enrich_button(tmp_path):
    import os
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    import pytest
    pytest.importorskip("PyQt6")
    from PyQt6.QtWidgets import QApplication

    from copilot.ui import launcher as L
    app = QApplication.instance() or QApplication([])  # noqa: F841
    root = Path(__file__).resolve().parents[1]
    (tmp_path / "config.yaml").write_text((root / "config.example.yaml").read_text())
    (tmp_path / ".env").write_text("")
    cfg = load_config(str(tmp_path / "config.yaml"))
    w = L.Launcher(cfg, str(tmp_path / "config.yaml"), tmp_path / ".state" / "launcher.json")
    assert "drop your question bank" in w.file_rows["qa_bank"].text() and w.enrich_btn.isHidden()
    w.import_files([_write(tmp_path / "面试题库.md", QUESTIONS), _write(tmp_path / "参考答案.md", ANSWERS)])
    t = w.file_rows["qa_bank"].text()
    assert "6 prepared answers" in t and "2 still have [placeholders]" in t
    assert not w.enrich_btn.isHidden() and not w.enrich_btn.isEnabled()   # no Anthropic key yet
    assert "6 prepared answers → qa.bank.md" in w.log.toPlainText()
    w.close()
