"""Windows support, exercised on any OS: hotkey mapping, WASAPI loopback capture (fake driver), cloud default,
launch scripts, and UTF-8 everywhere."""
import ast
import asyncio
import os
import sys
import threading
import time
import types
import wave
from pathlib import Path

import numpy as np
import pytest

from copilot import oscompat
from copilot.config import load_config

ROOT = Path(__file__).resolve().parents[1]
_APP = []


def _app():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    pytest.importorskip("PyQt6")
    from PyQt6.QtWidgets import QApplication
    if not _APP:  # keep a reference, or Qt destroys the application object immediately
        _APP.append(QApplication.instance() or QApplication([]))
    return _APP[0]


# ---------------------------------------------------------------- hotkeys
def test_hotkeys_are_translated_for_windows():
    assert oscompat.adapt_hotkey("<cmd>+<shift>+r", win=True) == "<ctrl>+<alt>+r"
    assert oscompat.adapt_hotkey("<cmd>+<shift>+<space>", win=True) == "<ctrl>+<alt>+<space>"
    assert oscompat.adapt_hotkey("<cmd>+k", win=True) == "<ctrl>+k"
    assert oscompat.adapt_hotkey("<cmd>+<shift>+r", win=False) == "<cmd>+<shift>+r"
    assert oscompat.pretty_hotkey("<ctrl>+<alt>+<space>", win=True) == "Ctrl+Alt+Space"
    assert oscompat.pretty_hotkey("<cmd>+<shift>+r", win=False) == "⌘⇧R"
    assert oscompat.pynput_to_qt("<ctrl>+<alt>+r", win=True) == "Ctrl+Alt+R"
    assert oscompat.pynput_to_qt("<cmd>+<shift>+r", win=False) == "Ctrl+Shift+R"   # Qt: Ctrl = ⌘ on macOS


def test_config_adapts_on_windows(monkeypatch, tmp_path):
    monkeypatch.setattr(oscompat, "IS_WIN", True)
    monkeypatch.setattr(oscompat, "local_asr_installed", lambda: False)
    (tmp_path / "config.yaml").write_text((ROOT / "config.example.yaml").read_text(encoding="utf-8")
                                          .replace("provider: deepgram", "provider: local", 1), encoding="utf-8")
    cfg = load_config(str(tmp_path / "config.yaml"))
    assert cfg.hotkeys.force_answer == "<ctrl>+<alt>+<space>" and cfg.hotkeys.clarify == "<ctrl>+<alt>+r"
    assert all("<cmd>" not in v for k, v in vars(cfg.hotkeys).items() if isinstance(v, str))
    assert cfg.audio.device == "loopback"
    assert cfg.asr.provider in ("deepgram",)                     # local isn't installed → cloud
    monkeypatch.setattr(oscompat, "IS_WIN", False)
    cfg = load_config(str(tmp_path / "config.yaml"))
    assert cfg.hotkeys.clarify == "<cmd>+<shift>+r" and cfg.audio.device == "BlackHole"


# ---------------------------------------------------------------- WASAPI loopback (fake PyAudioWPatch)
class FakeStream:
    def __init__(self, cb, rate, ch, frames, play_s):
        self.cb, self.rate, self.ch, self.frames, self.play_s = cb, rate, ch, frames, play_s
        self.running = False

    def start_stream(self):
        self.running = True

        def run():
            t0 = time.time()
            n = 0
            while self.running and time.time() - t0 < self.play_s:   # sound for play_s, then WASAPI goes quiet
                t = (np.arange(self.frames) + n) / self.rate
                x = (np.sin(2 * np.pi * 440 * t) * 8000).astype(np.int16)
                self.cb(np.repeat(x, self.ch).tobytes(), self.frames, None, 0)
                n += self.frames
                time.sleep(self.frames / self.rate)
        threading.Thread(target=run, daemon=True).start()

    def stop_stream(self):
        self.running = False

    def close(self):
        pass


def _fake_pyaudio(play_s=0.3):
    dev = {"index": 7, "name": "Headphones (Realtek) [Loopback]", "maxInputChannels": 2,
           "defaultSampleRate": 48000.0, "isLoopbackDevice": True}
    other = {"index": 9, "name": "Speakers (USB) [Loopback]", "maxInputChannels": 2, "defaultSampleRate": 44100.0,
             "isLoopbackDevice": True}
    mod = types.SimpleNamespace(paInt16=8, paContinue=0, paWASAPI=13)

    class PyAudio:
        def get_default_wasapi_loopback(self):
            return dev

        def get_loopback_device_info_generator(self):
            yield dev
            yield other

        def open(self, format, channels, rate, input, input_device_index, frames_per_buffer, stream_callback):
            assert input and input_device_index in (7, 9) and format == mod.paInt16
            self.stream = FakeStream(stream_callback, rate, channels, frames_per_buffer, play_s)
            return self.stream

        def terminate(self):
            pass
    mod.PyAudio = PyAudio
    return mod


def test_loopback_capture_resamples_and_fills_silence(monkeypatch, tmp_path):
    monkeypatch.setitem(sys.modules, "pyaudiowpatch", _fake_pyaudio(play_s=0.3))
    from copilot.capture.wasapi import LoopbackCapture
    cap = LoopbackCapture("loopback", block_ms=50, record_path=tmp_path / "rec.wav")

    async def go():
        got, t0 = [], time.monotonic()
        agen = cap.chunks()
        async for data in agen:
            got.append(data)
            if time.monotonic() - t0 > 1.0:
                break
        await agen.aclose()
        return got, time.monotonic() - t0
    got, secs = asyncio.run(go())
    pcm = np.frombuffer(b"".join(got), dtype=np.int16)
    assert cap.device_label.startswith("Headphones") and cap.level > 0
    assert np.abs(pcm[:4000]).max() > 1000                         # the tone arrived (48 kHz stereo → 16 kHz mono)
    assert pcm[-800:].max() == 0 and pcm[-800:].min() == 0         # then silence was filled in…
    assert 0.75 * secs * 16000 < len(pcm) < 1.25 * secs * 16000   # …so the audio clock kept pace with real time
    with wave.open(str(tmp_path / "rec.wav")) as w:
        assert w.getframerate() == 16000 and w.getnframes() > 8000


def test_open_capture_routes_by_os_and_name(monkeypatch):
    import copilot.capture as C
    from copilot.capture.audio import AudioCapture
    from copilot.capture.wasapi import LoopbackCapture
    monkeypatch.setattr(C, "list_input_devices", lambda: [{"index": 1, "name": "Microphone Array (Intel)",
                                                            "channels": 2, "rate": 48000}])
    monkeypatch.setattr(oscompat, "IS_WIN", True)
    assert isinstance(C.open_capture("loopback"), LoopbackCapture)
    assert isinstance(C.open_capture("Headphones"), LoopbackCapture)       # an output device → its loopback
    assert isinstance(C.open_capture("mic"), AudioCapture)
    assert isinstance(C.open_capture("Microphone Array"), AudioCapture)
    monkeypatch.setattr(oscompat, "IS_WIN", False)
    assert isinstance(C.open_capture("BlackHole"), AudioCapture)


def test_describe_and_find_loopback(monkeypatch):
    monkeypatch.setitem(sys.modules, "pyaudiowpatch", _fake_pyaudio())
    monkeypatch.setattr(oscompat, "IS_WIN", True)
    import copilot.capture as C
    monkeypatch.setattr(C, "list_input_devices", lambda: [])
    assert "Headphones (Realtek)" in C.describe_device("loopback") and "48000 Hz" in C.describe_device("loopback")
    assert "Speakers (USB)" in C.describe_device("speakers (usb")
    with pytest.raises(RuntimeError, match="No output device containing 'HDMI'"):
        C.describe_device("HDMI")


# ---------------------------------------------------------------- launcher: cloud by default
def test_launcher_on_windows_offers_cloud_only(monkeypatch, tmp_path):
    _app()
    from copilot.ui import launcher as L
    for k in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "DEEPGRAM_API_KEY"):
        monkeypatch.setenv(k, "x")      # registers a restore, so keys loaded from .env below don't leak out
        monkeypatch.delenv(k)
    monkeypatch.setattr(L, "IS_WIN", True)
    monkeypatch.setattr(L, "local_asr_installed", lambda: False)
    (tmp_path / "config.yaml").write_text((ROOT / "config.example.yaml").read_text(encoding="utf-8"),
                                          encoding="utf-8")
    (tmp_path / ".env").write_text("OPENAI_API_KEY=sk-proj-" + "A" * 150 + "\n", encoding="utf-8")
    cfg = load_config(str(tmp_path / "config.yaml"))
    w = L.Launcher(cfg, str(tmp_path / "config.yaml"), tmp_path / ".state" / "launcher.json")
    opts = [b.property("opt") for b in w.groups["asr"].buttons()]
    assert "local" not in opts and w.current_choice().asr == "openai_realtime"    # the key you have
    w.close()
    assert L.default_cloud_asr(None) == "deepgram"


def test_overlay_shows_windows_key_names(monkeypatch, tmp_path):
    _app()
    from copilot.ui.bridge import QtSink
    from copilot.ui.overlay import Overlay
    monkeypatch.setattr(oscompat, "IS_WIN", True)
    cfg = load_config(str(ROOT / "config.example.yaml"))

    class Ctl:
        model_name = "m"
    ov = Overlay(cfg, QtSink(), Ctl(), "m", state_path=tmp_path / "ui.json")
    assert "Ctrl+Alt+Space" in ov.footer.text() and "⌘" not in ov.footer.text()
    assert "Ctrl+Alt+R" in ov.help_lb.text() and "Ctrl =" in ov.help_lb.text()
    ov.close()


# ---------------------------------------------------------------- package
def test_windows_scripts_are_plain_crlf_batch_files():
    for name in ("install.bat", "Interview Copilot.bat", "update.bat"):
        raw = (ROOT / name).read_bytes()
        raw.decode("ascii")                                          # cmd.exe reads batch files in the OEM codepage
        assert b"\r\n" in raw and b"\n" not in raw.replace(b"\r\n", b"")
    inst = (ROOT / "install.bat").read_text(encoding="ascii")
    assert "requirements.txt" in inst and ".venv" in inst and "scripts\\first_run.py" in inst
    assert "PYTHONUTF8=1" in (ROOT / "Interview Copilot.bat").read_text(encoding="ascii")
    upd = (ROOT / "update.bat").read_text(encoding="ascii")
    assert upd.index("(") < upd.index("update.py") < upd.rindex(")")   # parsed as one block → safe to self-replace
    req = (ROOT / "requirements.txt").read_text(encoding="utf-8")
    assert 'PyAudioWPatch>=0.2.12 ; sys_platform == "win32"' in req and 'sys_platform == "darwin"' in req


def test_every_text_file_access_names_its_encoding():
    """Windows defaults to a legacy code page; Chinese answers / 思路 must always be read and written as UTF-8."""
    bad = []
    files = [*ROOT.joinpath("copilot").rglob("*.py"), ROOT / "run.py", ROOT / "update.py",
             *ROOT.joinpath("scripts").glob("*.py")]
    for f in files:
        for n in ast.walk(ast.parse(f.read_text(encoding="utf-8"))):
            if not isinstance(n, ast.Call):
                continue
            kw = {k.arg for k in n.keywords}
            fn = n.func
            name = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", "")
            if name in ("read_text", "write_text") and "encoding" not in kw:
                bad.append(f"{f.relative_to(ROOT)}:{n.lineno}")
            if name == "open" and isinstance(fn, ast.Name) and "encoding" not in kw:
                mode = n.args[1].value if len(n.args) > 1 and isinstance(n.args[1], ast.Constant) else "r"
                if "b" not in str(mode):
                    bad.append(f"{f.relative_to(ROOT)}:{n.lineno}")
    assert not bad, bad


def test_empty_keys_in_env_template_count_as_not_set(tmp_path, monkeypatch):
    from copilot.keycheck import quick_status
    for k in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "DEEPGRAM_API_KEY"):
        monkeypatch.setenv(k, "x")
        monkeypatch.delenv(k)
    (tmp_path / ".env").write_text((ROOT / ".env.example").read_text(encoding="utf-8"), encoding="utf-8")
    st = quick_status(tmp_path / ".env")
    assert all(st[k][0] == "—" for k in ("anthropic", "deepgram", "openai")), st


def test_first_run_writes_a_windows_config():
    sys.path.insert(0, str(ROOT / "scripts"))
    import first_run
    text = first_run.windows_config((ROOT / "config.example.yaml").read_text(encoding="utf-8"))
    import yaml
    d = yaml.safe_load(text)
    assert d["audio"]["device"] == "loopback"
    assert d["hotkeys"]["force_answer"] == "<ctrl>+<alt>+<space>" and "<cmd>" not in text
    assert d["asr"]["provider"] != "local"


def test_first_run_creates_files_once(tmp_path, monkeypatch):
    import shutil
    app = tmp_path / "app"
    def ignore(d, names):
        top = Path(d) == ROOT
        return [n for n in names if n in ("__pycache__", ".pytest_cache") or
                (top and n in (".state", "sessions", "eval", ".env", "config.yaml", "knowledge"))]
    shutil.copytree(ROOT, app, ignore=ignore)
    import subprocess
    r = subprocess.run([sys.executable, str(app / "scripts" / "first_run.py")], capture_output=True, text=True,
                       encoding="utf-8", env={**os.environ, "QT_QPA_PLATFORM": "offscreen"})
    assert r.returncode == 3, r.stdout + r.stderr                      # new .env → install.bat opens Notepad
    assert (app / "config.yaml").exists() and (app / ".env").exists() and (app / "knowledge").is_dir()
    (app / ".env").write_text("ANTHROPIC_API_KEY=mine\n", encoding="utf-8")
    r = subprocess.run([sys.executable, str(app / "scripts" / "first_run.py")], capture_output=True, text=True,
                       encoding="utf-8", env={**os.environ, "QT_QPA_PLATFORM": "offscreen"})
    assert r.returncode == 0 and (app / ".env").read_text(encoding="utf-8") == "ANTHROPIC_API_KEY=mine\n"
