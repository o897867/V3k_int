"""Visual language: readable contrast in both themes, the theme is shared and remembered, quiet controls work."""
import json
import os
import time
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PyQt6")
from PyQt6.QtWidgets import QApplication  # noqa: E402

from copilot.config import load_config  # noqa: E402
from copilot.events import PreparedMatch, Question  # noqa: E402
from copilot.ui import theme as TH  # noqa: E402
from copilot.ui.bridge import QtSink  # noqa: E402
from copilot.ui.overlay import Overlay, _short_model  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
_APP = []


def _app():
    if not _APP:
        _APP.append(QApplication.instance() or QApplication([]))
    return _APP[0]


def _pump(s=0.05):
    end = time.time() + s
    while time.time() < end:
        _app().processEvents()
        time.sleep(0.01)


class Ctl:
    model_name = "claude-haiku-4-5-20251001"

    def force_answer(self):
        pass


@pytest.mark.parametrize("t", [TH.SUMI, TH.WASHI], ids=lambda t: t.name)
def test_every_text_colour_is_readable(t):
    for k in ("text", "strong", "say", "muted", "accent", "prep", "zh", "bridge", "err", "alt", "deep"):
        assert TH.contrast(getattr(t, k), t.bg) >= 4.5, (t.name, k)
        assert TH.contrast(getattr(t, k), t.surface) >= 4.5 or k in ("muted",), (t.name, k)
    assert TH.contrast(t.faint, t.bg) >= 3.0            # footer hints / placeholders only
    assert TH.contrast(t.stale, t.bg) >= 2.3            # dimmed-but-readable while an answer is replaced


def test_resolve_and_materials():
    _app()
    assert TH.resolve("sumi") is TH.SUMI and TH.resolve("washi") is TH.WASHI
    assert TH.resolve("auto") in (TH.SUMI, TH.WASHI)
    px = TH.paper_grain(TH.WASHI)
    assert not px.isNull() and TH.paper_grain(TH.WASHI) is px     # generated once
    f = TH.font(15, serif=True, weight=600)
    assert f.pixelSize() == 15 and "Iowan Old Style" in f.families()


def test_short_model_names():
    assert _short_model("claude-haiku-4-5-20251001") == "haiku 4.5"
    assert _short_model("claude-haiku-4-5 + claude-sonnet-5") == "haiku 4.5 + sonnet 5"
    assert _short_model("mock") == "mock"


def test_overlay_theme_toggle_is_remembered(tmp_path):
    _app()
    cfg = load_config(str(ROOT / "config.example.yaml"))
    cfg.ui.theme = "sumi"
    state = tmp_path / ".state" / "ui.json"
    ov = Overlay(cfg, QtSink(), Ctl(), Ctl.model_name, state_path=state)
    ov.show()
    assert ov.T is TH.SUMI and ov.model_lb.text() == "haiku 4.5"
    ov.theme_btn.click()
    assert ov.T is TH.WASHI and TH.WASHI.strong in ov.key_lb.styleSheet()
    ov.close()
    assert json.loads(state.read_text())["theme"] == "washi"
    ov2 = Overlay(cfg, QtSink(), Ctl(), Ctl.model_name, state_path=state)
    assert ov2.T is TH.WASHI                                          # remembered over config
    ov2.close()


def test_overlay_nav_buttons_and_quiet_controls(tmp_path):
    _app()
    cfg = load_config(str(ROOT / "config.example.yaml"))
    sink = QtSink()
    ov = Overlay(cfg, sink, Ctl(), Ctl.model_name, state_path=tmp_path / "ui.json")
    ov.show()
    sink.on_question(Question(1, "Tell me about yourself", 0, 0))
    _pump()
    assert not ov.prev_btn.isVisibleTo(ov)                            # nothing to page through yet
    sink.on_question(Question(2, "Why this role?", 0, 0))
    sink.on_layer(2, "points", "⌨ SELECT 1\n⚠ 待填 / fill in: [X]\n💡 keep it short\nplain point")
    _pump()
    assert ov.prev_btn.isVisibleTo(ov) and ov.prev_btn.isEnabled() and not ov.next_btn.isEnabled()
    html = ov.pts_lb.text()
    assert "Menlo" in html and TH.resolve(cfg.ui.theme).err in html and "keep it short" in html
    ov.prev_btn.click()
    assert ov._current().qid == 1 and "earlier" in ov.nav_lb.text() and ov.next_btn.isEnabled()
    ov.next_btn.click()
    assert ov.view == -1
    # hover brightens the controls, leaving dims them again
    from PyQt6.QtCore import QEvent, QPointF
    from PyQt6.QtGui import QEnterEvent
    ov.enterEvent(QEnterEvent(QPointF(5, 5), QPointF(5, 5), QPointF(5, 5)))
    assert ov.T.muted in ov.help_btn.styleSheet()
    ov.leaveEvent(QEvent(QEvent.Type.Leave))
    assert ov.T.faint in ov.help_btn.styleSheet().split("}")[0]
    # the hint card (medium-confidence prepared match) keeps its ink mark; the locked line does not
    sink.on_prepared(2, PreparedMatch("Why do you want to work here?", "KEY: k\n- a\nSAY: s", 0.6, False), False)
    _pump()
    assert ov.prep_lb.mark is not None and "possibly your prepared answer" in ov.prep_lb.text()
    sink.on_prepared(2, PreparedMatch("Why do you want to work here?", "KEY: k\nSAY: s", 0.9, True), False)
    _pump()
    assert ov.prep_lb.mark is None and "your prepared answer" in ov.prep_lb.text()
    img = ov.grab()
    assert not img.isNull()
    ov.close()


def test_launcher_appearance_is_shared_with_overlay(tmp_path):
    _app()
    from copilot.ui import launcher as L
    (tmp_path / "config.yaml").write_text((ROOT / "config.example.yaml").read_text())
    (tmp_path / ".env").write_text("")
    cfg = load_config(str(tmp_path / "config.yaml"))
    state_dir = tmp_path / ".state"
    w = L.Launcher(cfg, str(tmp_path / "config.yaml"), state_dir / "launcher.json")
    w.show()
    washi = next(b for b in w.theme_group.buttons() if b.property("opt") == "washi")
    washi.click()
    assert w.T is TH.WASHI and f"color:{TH.WASHI.text}" in w.styleSheet() and not w.logo.pixmap().isNull()
    assert json.loads((state_dir / "ui.json").read_text())["theme"] == "washi"
    # optional files that are absent fold into one line; required ones always keep their row
    assert not w.file_rows["cover_letter"].isVisibleTo(w) and "Cover letter" in w.optional_lb.text()
    assert w.file_rows["resume"].isVisibleTo(w) and "MISSING" in w.file_rows["resume"].text()
    # the details log only appears once there is something in it
    assert not w.log.isVisibleTo(w)
    w._log("hello")
    assert w.log.isVisibleTo(w)
    # segmented controls behave like the old radio buttons
    w.set_choice(mode="practice", answers="sonnet")
    assert w.current_choice().mode == "practice" and "slower" in w.hint_lb["answers"].text()
    w.close()
    ov = Overlay(cfg, QtSink(), Ctl(), "m", state_path=state_dir / "ui.json")
    assert ov.T is TH.WASHI
    ov.close()
