"""End-to-end through the real entry point (copilot.app.main) — the path the user actually runs.

The earlier suite built Pipeline objects directly and never passed a SessionLogger, so a crash that
only happened with logging enabled (i.e. always, in the real app) went unnoticed. This test drives
`python run.py --demo --mock-llm` exactly as a person would: type into the box, press Enter."""
import json
import os
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PyQt6")
from PyQt6.QtCore import QTimer  # noqa: E402
from PyQt6.QtWidgets import QApplication  # noqa: E402

import copilot.app as appmod  # noqa: E402
import copilot.ui.overlay as ov_mod  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def test_run_py_demo_answers_typed_questions(tmp_path, monkeypatch):
    cfg = tmp_path / "config.yaml"
    text = (ROOT / "config.example.yaml").read_text()
    text = text.replace('dir: "./knowledge"', f'dir: "{ROOT / "knowledge.example"}"')
    text = text.replace('dir: "./sessions"', f'dir: "{tmp_path / "sessions"}"')
    cfg.write_text(text)
    seen = {}
    orig_init = ov_mod.Overlay.__init__

    def init(self, *a, **k):
        orig_init(self, *a, **k)

        def ask(q):
            self.input.setText(q)
            self.input.returnPressed.emit()

        def snapshot(tag):
            c = self._current()
            seen[tag] = (len(self.cards), c.question if c else None, c.key if c else "",
                         getattr(c.prepared, "locked", None) if c else None, c.error if c else "")

        QTimer.singleShot(300, lambda: ask("walk me through yourb akcgounr"))   # the exact bug-report input
        QTimer.singleShot(1500, lambda: snapshot("q1"))
        QTimer.singleShot(1700, lambda: ask("How would you find duplicate rows in SQL?"))
        QTimer.singleShot(3200, lambda: snapshot("q2"))
        QTimer(self, singleShot=True, interval=3400, timeout=QApplication.instance().quit).start()  # dies with this overlay
    monkeypatch.setattr(ov_mod.Overlay, "__init__", init)

    code = appmod.main(["--config", str(cfg), "--demo", "--mock-llm", "--no-hotkeys"])
    assert code == 0
    n, q, key, locked, err = seen["q1"]
    assert n == 1 and q == "walk me through yourb akcgounr" and key and not err
    n, q, key, locked, err = seen["q2"]
    assert n == 2 and "duplicate rows" in q and key and not err
    # the session log was written and the review sheet lists both questions
    logs = list((tmp_path / "sessions").glob("*.jsonl"))
    assert logs
    events = [json.loads(line)["event"] for line in logs[0].read_text().splitlines()]
    assert events.count("question") == 2 and "utterance" in events and "answer" in events
    md = next((tmp_path / "sessions").glob("*.md")).read_text()
    assert "walk me through yourb akcgounr" in md and "duplicate rows" in md


def test_run_py_live_audio_path_with_fake_asr(tmp_path, monkeypatch):
    """`python run.py --replay x.wav`: audio → ASR → engine (with session log) → overlay, incl. the provisional
    prepared card while the interviewer is still talking."""
    import asyncio
    import wave

    import numpy as np

    import copilot.asr as asr_pkg
    from copilot.events import TranscriptEvent

    wav = tmp_path / "silence.wav"
    with wave.open(str(wav), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes(np.zeros(16000 * 4, dtype=np.int16).tobytes())

    class ScriptedASR:
        async def run(self, chunks, on_event):
            script = [(0.2, "interim", "could you walk me"), (0.5, "interim", "could you walk me through your"),
                      (0.8, "interim", "could you walk me through your background"),
                      (1.1, "final", "Could you walk me through your background?"), (1.1, "endpoint", "")]
            t0 = None
            async for _ in chunks:
                t0 = t0 or asyncio.get_running_loop().time()
                el = asyncio.get_running_loop().time() - t0
                while script and script[0][0] <= el:
                    _, kind, text = script.pop(0)
                    await on_event(TranscriptEvent(kind, text))
    monkeypatch.setattr(asr_pkg, "build_asr", lambda cfg, terms=None: ScriptedASR())

    cfg = tmp_path / "config.yaml"
    text = (ROOT / "config.example.yaml").read_text()
    text = text.replace('dir: "./knowledge"', f'dir: "{ROOT / "knowledge.example"}"')
    text = text.replace('dir: "./sessions"', f'dir: "{tmp_path / "sessions"}"')
    cfg.write_text(text)
    seen = {"provisional": False}
    orig_init = ov_mod.Overlay.__init__

    def init(self, *a, **k):
        orig_init(self, *a, **k)

        def poll():

            if not self.isVisible():  # an overlay left over from an earlier test

                return
            c = self._current()
            if c is not None and c.provisional:
                seen["provisional"] = True
            if c is not None and not c.provisional and c.metrics:
                seen["final"] = (c.question, c.key, getattr(c.prepared, "locked", False), c.say)
                QApplication.instance().quit()
        t = QTimer(self, interval=20, timeout=poll)
        t.start()
        QTimer(self, singleShot=True, interval=8000, timeout=QApplication.instance().quit).start()  # dies with this overlay
    monkeypatch.setattr(ov_mod.Overlay, "__init__", init)

    # a real (non-demo) session refuses fictional example data, so give it "user" data: a copy without markers
    import shutil
    kdir = tmp_path / "knowledge"
    shutil.copytree(ROOT / "knowledge.example", kdir)
    (kdir / ".example").unlink()
    for f in kdir.glob("*.md"):
        f.write_text(f.read_text().replace("(EXAMPLE)", "").replace("[EXAMPLE] ", ""))
    cfg.write_text(cfg.read_text().replace(str(ROOT / "knowledge.example"), str(kdir)))
    assert appmod.main(["--config", str(cfg), "--replay", str(wav), "--mock-llm", "--no-hotkeys"]) == 0
    assert seen["provisional"], "prepared answer should appear while the interviewer is still speaking"
    q, key, locked, say = seen["final"]
    assert q == "Could you walk me through your background?" and locked
    assert key.startswith("Analyst bridging compliance") and "data analyst at Example Brokerage" in say


def test_run_py_mic_mode_records_and_warns_when_mic_blocked(tmp_path, monkeypatch):
    """`python run.py --mic --record`: the real AudioCapture path on a (fake) microphone that macOS is
    blocking (pure digital silence) → red banner in the overlay; the audio is saved for scoring."""
    import asyncio
    import sys
    import threading
    import types

    import numpy as np

    import copilot.asr as asr_pkg
    from copilot.capture import audio as audio_mod
    from copilot.events import TranscriptEvent

    class FakeStream:
        def __init__(self, device, channels, samplerate, blocksize, dtype, callback):
            self.cb, self.n, self.rate, self.ch = callback, blocksize, samplerate, channels
            self.run = False

        def start(self):
            self.run = True

            def loop():
                import time
                while self.run:
                    self.cb(np.zeros((self.n, self.ch), dtype=np.float32), self.n, None, None)
                    time.sleep(self.n / self.rate / 4)   # 4× real time keeps the test short
            threading.Thread(target=loop, daemon=True).start()

        def stop(self):
            self.run = False

        def close(self):
            pass

    fake_sd = types.SimpleNamespace(InputStream=FakeStream, default=types.SimpleNamespace(device=(1, 2)),
                                    query_devices=lambda: [
                                        {"name": "BlackHole 2ch", "max_input_channels": 2, "default_samplerate": 48000},
                                        {"name": "MacBook Pro Microphone", "max_input_channels": 1,
                                         "default_samplerate": 48000}])
    monkeypatch.setitem(sys.modules, "sounddevice", fake_sd)
    chosen = {}
    orig_find = audio_mod.find_device

    def spy(name):
        d = orig_find(name)
        chosen["dev"] = d["name"]
        return d
    monkeypatch.setattr(audio_mod, "find_device", spy)

    class ScriptedASR:
        async def run(self, chunks, on_event):
            n = 0
            async for _ in chunks:
                n += 1
                if n == 100:
                    await on_event(TranscriptEvent("final", "Could you walk me through your background?"))
                    await on_event(TranscriptEvent("endpoint", ""))
    monkeypatch.setattr(asr_pkg, "build_asr", lambda cfg, terms=None: ScriptedASR())

    import shutil
    kdir = tmp_path / "knowledge"
    shutil.copytree(ROOT / "knowledge.example", kdir)
    (kdir / ".example").unlink()
    for f in kdir.glob("*.md"):
        f.write_text(f.read_text().replace("(EXAMPLE)", "").replace("[EXAMPLE] ", ""))
    cfg = tmp_path / "config.yaml"
    text = (ROOT / "config.example.yaml").read_text()
    text = text.replace('dir: "./knowledge"', f'dir: "{kdir}"').replace('dir: "./sessions"',
                                                                        f'dir: "{tmp_path / "sessions"}"')
    cfg.write_text(text)
    seen = {}
    orig_init = ov_mod.Overlay.__init__

    def init(self, *a, **k):
        orig_init(self, *a, **k)
        seen["waiting"] = self.waiting_text

        def poll():

            if not self.isVisible():  # an overlay left over from an earlier test

                return
            if self.warn_lb.isVisible() and "Microphone" in self.warn_lb.text():
                seen["warning"] = self.warn_lb.text()
            c = self._current()
            if c is not None and c.metrics:
                seen["locked"] = getattr(c.prepared, "locked", False)
            if "warning" in seen and "locked" in seen:
                QApplication.instance().quit()

        QTimer(self, interval=30, timeout=poll).start()
        QTimer(self, singleShot=True, interval=10000, timeout=QApplication.instance().quit).start()  # dies with this overlay
    monkeypatch.setattr(ov_mod.Overlay, "__init__", init)
    assert appmod.main(["--config", str(cfg), "--mic", "--record", "--mock-llm", "--no-hotkeys"]) == 0
    asyncio.set_event_loop(asyncio.new_event_loop())
    assert chosen["dev"] == "MacBook Pro Microphone"   # not BlackHole
    assert "Microphone test" in seen["waiting"]
    assert "Privacy" in seen["warning"] and seen["locked"]
    wavs = list((tmp_path / "sessions").glob("*.wav"))
    assert wavs and wavs[0].stat().st_size > 44
