"""Exercise the real Anthropic SDK streaming path and the Deepgram websocket session
against local fakes (no API keys, no internet)."""
import asyncio
import json

import httpx
import numpy as np
import pytest

from copilot.asr.deepgram import DeepgramASR
from copilot.config import Config


def _sse(text_chunks):
    evs = [("message_start", {"type": "message_start", "message": {
        "id": "msg_1", "type": "message", "role": "assistant", "model": "claude-haiku-4-5-20251001",
        "content": [], "stop_reason": None, "stop_sequence": None,
        "usage": {"input_tokens": 10, "output_tokens": 1}}}),
        ("content_block_start", {"type": "content_block_start", "index": 0,
                                 "content_block": {"type": "text", "text": ""}})]
    for t in text_chunks:
        evs.append(("content_block_delta", {"type": "content_block_delta", "index": 0,
                                            "delta": {"type": "text_delta", "text": t}}))
    evs += [("content_block_stop", {"type": "content_block_stop", "index": 0}),
            ("message_delta", {"type": "message_delta", "delta": {"stop_reason": "end_turn", "stop_sequence": None},
                               "usage": {"output_tokens": 20}}),
            ("message_stop", {"type": "message_stop"})]
    return "".join(f"event: {e}\ndata: {json.dumps(d)}\n\n" for e, d in evs).encode()


def test_anthropic_stream_sends_cached_system(monkeypatch):
    anthropic = pytest.importorskip("anthropic")
    from copilot.llm.anthropic_llm import AnthropicLLM

    monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
    seen = {}

    def handler(req: httpx.Request):
        seen["body"] = json.loads(req.content)
        return httpx.Response(200, headers={"content-type": "text/event-stream"},
                              content=_sse(["KEY: Use ROW_", "NUMBER\n- a\n", "SAY: done"]))

    system = [{"type": "text", "text": "rules"},
              {"type": "text", "text": "kb", "cache_control": {"type": "ephemeral"}}]
    llm = AnthropicLLM(Config().llm, system)
    try:
        import httpx2 as hx  # newer SDKs are built on httpx2
    except ImportError:
        hx = httpx
    hx_handler = lambda req: hx.Response(200, headers={"content-type": "text/event-stream"},  # noqa: E731
                                         content=(handler(req).content))
    llm.client = anthropic.AsyncAnthropic(api_key="test",  # replace transport, keep AnthropicLLM logic
                                          http_client=hx.AsyncClient(transport=hx.MockTransport(hx_handler)))

    async def go():
        return "".join([t async for t in llm.stream("INTERVIEWER JUST ASKED:\n\"dedupe?\"")])

    out = asyncio.run(go())
    assert out == "KEY: Use ROW_NUMBER\n- a\nSAY: done"
    assert seen["body"]["stream"] is True
    assert seen["body"]["system"][1]["cache_control"] == {"type": "ephemeral"}
    assert seen["body"]["model"] == "claude-haiku-4-5-20251001"


def test_deepgram_session_against_fake_server(monkeypatch):
    websockets = pytest.importorskip("websockets")
    from websockets.asyncio.server import serve

    got = {"bytes": 0, "auth": None, "close": False}

    async def handler(ws):
        got["auth"] = ws.request.headers.get("Authorization")
        n = 0
        async for msg in ws:
            if isinstance(msg, bytes):
                got["bytes"] += len(msg)
                n += 1
                if n == 3:
                    await ws.send(json.dumps({"type": "Results", "is_final": False, "start": 0, "duration": .1,
                                              "channel": {"alternatives": [{"transcript": "tell me"}]}}))
                if n == 6:
                    await ws.send(json.dumps({"type": "Results", "is_final": True, "speech_final": True,
                                              "start": 0, "duration": .3,
                                              "channel": {"alternatives": [{"transcript": "Tell me about SQL?"}]}}))
            elif json.loads(msg).get("type") == "CloseStream":
                got["close"] = True
                await ws.close()
                return

    async def go():
        async with serve(handler, "127.0.0.1", 0) as server:
            port = server.sockets[0].getsockname()[1]
            monkeypatch.setattr("copilot.asr.deepgram.build_url", lambda cfg, kt: f"ws://127.0.0.1:{port}/")
            monkeypatch.setenv("DEEPGRAM_API_KEY", "k")
            asr = DeepgramASR(Config().asr.deepgram)
            events = []

            async def on_event(ev):
                events.append(ev)

            async def chunks():
                for _ in range(8):
                    yield np.zeros(800, dtype=np.int16).tobytes()
                    await asyncio.sleep(0.01)

            await asyncio.wait_for(asr.run(chunks(), on_event), timeout=10)
            return events

    events = asyncio.run(go())
    kinds = [e.kind for e in events]
    assert got["auth"] == "Token k" and got["close"] and got["bytes"] == 8 * 1600
    assert kinds == ["status", "interim", "final", "endpoint"]
    assert events[2].text == "Tell me about SQL?"
