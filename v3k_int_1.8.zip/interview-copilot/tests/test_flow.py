"""思路 FLOW: Chinese line of thought + English words per step, for answering in your own words."""
import asyncio
import os
import time
from pathlib import Path

import pytest

from copilot.config import Config, load_config
from copilot.events import RecordingSink, TranscriptEvent
from copilot.engine.pipeline import Pipeline
from copilot.knowledge import load_knowledge
from copilot.knowledge.prompt import build_flow_message, build_system_blocks
from copilot.knowledge.qa_bank import QABank
from copilot.llm.layered_parser import LayeredParser, parse_layers, split_step
from copilot.llm.mock_llm import MockLLM

ROOT = Path(__file__).resolve().parents[1]

ANSWER = """KEY: Grain first
ZH: 考察建模
FLOW:
> 先说每张事实表的粒度 | the grain of each fact table
> 转介、服务接触各一张 | referral fact, service contact
  fact
> 共用维度 | shared Date, Client
- point a
- point b
SAY: I'd start with the grain."""


def test_parse_flow_between_zh_and_points():
    L = parse_layers(ANSWER)
    assert L["flow"].split("\n") == ["先说每张事实表的粒度 | the grain of each fact table",
                                     "转介、服务接触各一张 | referral fact, service contact fact",
                                     "共用维度 | shared Date, Client"]
    assert L["points"] == "point a\npoint b" and L["say"] == "I'd start with the grain."
    # other step styles the model might use
    assert parse_layers("FLOW: 一、结论 | result\n二、例子 | example\nSAY: s")["flow"] == "结论 | result\n例子 | example"
    assert parse_layers("思路：\n1. 先讲背景 | context\n2. 再讲行动 | action")["flow"] == "先讲背景 | context\n再讲行动 | action"
    assert split_step("先说结论 | lead with the result") == ("先说结论", "lead with the result")
    assert split_step("只有中文") == ("只有中文", "")


def test_streaming_marks_flow_complete_before_points():
    p = LayeredParser()
    for i in range(0, len(ANSWER), 6):
        p.feed(ANSWER[i:i + 6])
    assert {"key", "zh", "flow", "points"} <= p.completed


def test_prompt_asks_for_flow_and_can_turn_it_off():
    cfg = load_config(str(ROOT / "config.example.yaml"))
    cfg.knowledge.dir = str(ROOT / "knowledge.example")
    kb = load_knowledge(cfg)
    rules = build_system_blocks(cfg, kb)[0]["text"]
    assert "FLOW:\n> <中文" in rules and "instead of\n  reading SAY aloud" in rules
    assert rules.index("FLOW:") < rules.index("- <talking point") < rules.index("SAY:")
    cfg.llm.flow = False
    assert "FLOW" not in build_system_blocks(cfg, kb)[0]["text"]
    msg = build_flow_message(cfg, "Tell me about yourself", "KEY: k\nSAY: hello")
    assert msg.startswith("Write ONLY the FLOW") and "PREPARED ANSWER:\nKEY: k" in msg


def test_flow_adds_output_budget(monkeypatch):
    pytest.importorskip("anthropic")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
    from copilot.llm.anthropic_llm import AnthropicLLM
    cfg = Config()
    assert AnthropicLLM(cfg.llm, []).max_tokens == cfg.llm.max_tokens + cfg.llm.flow_tokens
    cfg.llm.flow = False
    assert AnthropicLLM(cfg.llm, []).max_tokens == cfg.llm.max_tokens


def _kb(answer: str):
    from copilot.knowledge.loader import KnowledgeBase
    kb = KnowledgeBase()
    kb.qa = QABank()
    kb.qa.load_markdown(f"## Q: Tell me about yourself\nALT: Walk me through your background\n{answer}\n")
    kb.qa.build()
    return kb


def test_prepared_answer_without_flow_gets_one_written_once_then_instant():
    cache = {}

    async def ask(cfg):
        sink = RecordingSink()
        p = Pipeline(cfg, MockLLM(ttft=0.02, tok_per_s=5000), _kb("KEY: k\nSAY: my story"), sink, flow_cache=cache)
        await p.inject_text("Could you walk me through your background?")
        await p.wait_idle()
        return sink
    cfg = Config()
    sink = asyncio.run(ask(cfg))
    flows = [e for e in sink.of("layer") if e[3] == "flow"]
    assert flows and "先说结论" in flows[-1][4]                   # streamed into the MAIN flow layer
    assert len(cache) == 1 and "先说结论" in next(iter(cache.values()))
    # second time: the cached 思路 comes with the prepared answer itself — no model call needed for it
    sink2 = asyncio.run(ask(cfg))
    prep = [e for e in sink2.of("prepared")]
    assert prep and "FLOW:" in prep[-1][3].answer
    first_flow = next(e for e in sink2.of("layer") if e[3] == "flow")
    first_alt = next(e for e in sink2.of("layer") if e[3].startswith("alt_"))
    assert first_flow[0] <= first_alt[0]                          # instant, before the model's version streams
    # turned off → no 思路 request
    cfg.llm.flow_for_prepared = False
    cache.clear()
    sink3 = asyncio.run(ask(cfg))
    assert not [e for e in sink3.of("layer") if e[3] == "flow"] and not cache


def test_prepared_answer_with_its_own_flow_is_used_verbatim():
    async def go():
        sink = RecordingSink()
        cache = {}
        p = Pipeline(Config(), MockLLM(ttft=0.02, tok_per_s=5000), _kb(ANSWER), sink, flow_cache=cache)
        await p.inject_text("Could you walk me through your background?")
        await p.wait_idle()
        return sink, cache
    sink, cache = asyncio.run(go())
    flows = [e[4] for e in sink.of("layer") if e[3] == "flow"]
    assert flows == [parse_layers(ANSWER)["flow"]] and not cache


def test_model_answer_streams_flow():
    async def go():
        sink = RecordingSink()
        p = Pipeline(Config(), MockLLM(ttft=0.02, tok_per_s=5000), _kb("KEY: k\nSAY: s"), sink)
        await p.handle(TranscriptEvent("final", "How would you design a star schema for our clinics?"))
        await p.handle(TranscriptEvent("endpoint"))
        await p.wait_idle()
        return sink
    sink = asyncio.run(go())
    flow = [e for e in sink.of("layer") if e[3] == "flow"][-1][4]
    assert len(flow.split("\n")) == 4 and "|" in flow


# ---------------------------------------------------------------- overlay
def test_overlay_shows_flow_toggles_and_remembers(tmp_path):
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    pytest.importorskip("PyQt6")
    from PyQt6.QtWidgets import QApplication

    from copilot.events import Question
    from copilot.ui.bridge import QtSink
    from copilot.ui.overlay import Overlay
    app = QApplication.instance() or QApplication([])

    class Ctl:
        model_name = "m"

    cfg = load_config(str(ROOT / "config.example.yaml"))
    sink = QtSink()
    state = tmp_path / "ui.json"
    ov = Overlay(cfg, sink, Ctl(), "m", state_path=state)
    ov.show()
    sink.on_question(Question(1, "How would you model referrals?", 0, 0))
    L = parse_layers(ANSWER)
    for k in ("key", "flow", "points", "say"):
        sink.on_layer(1, k, L[k])
    for _ in range(5):
        app.processEvents()
        time.sleep(0.01)
    html = ov.flow_lb.text()
    assert ov.flow_lb.isVisibleTo(ov) and "一" in html and "二" in html and "先说每张事实表的粒度" in html
    assert "the grain of each fact table" in html and ov.flow_hdr.text().startswith("▾ 思路")
    # focus mode keeps 思路 (answering in your own words is the point) and enlarges it
    base = ov.flow_lb.font().pixelSize()
    ov.on_hotkey("focus")
    assert ov.flow_lb.isVisibleTo(ov) and ov.flow_lb.font().pixelSize() > base and not ov.pts_lb.isVisibleTo(ov)
    ov.on_hotkey("focus")
    ov.on_hotkey("toggle_flow")
    assert not ov.flow_lb.isVisibleTo(ov) and ov.flow_hdr.text().startswith("▸ 思路")
    ov.flow_hdr.click()
    assert ov.flow_lb.isVisibleTo(ov)
    # merged follow-up: the old 思路 stays (dimmed) until the new one arrives
    sink.on_question(Question(2, "How would you model referrals? And waitlists?", 0, 0, merged_from=1))
    app.processEvents()
    c = ov._current()
    assert "flow" in c.stale and c.flow == L["flow"] and ov.flow_lb.isVisibleTo(ov)
    sink.on_layer(2, "flow", "新的思路 | new thought")
    app.processEvents()
    assert "flow" not in c.stale and "新的思路" in ov.flow_lb.text()
    ov.on_hotkey("toggle_flow")
    ov.close()
    import json
    assert json.loads(state.read_text())["show_flow"] is False


def test_plain_spoken_style_is_default_and_optional():
    cfg = load_config(str(ROOT / "config.example.yaml"))
    cfg.knowledge.dir = str(ROOT / "knowledge.example")
    kb = load_knowledge(cfg)
    rules = build_system_blocks(cfg, kb)[0]["text"]
    assert "SPOKEN, PLAIN ENGLISH" in rules and "short sentences" in rules and "not utilised/leveraged" in rules
    assert "easy to say aloud>" in rules
    cfg.llm.spoken = "polished"
    rules = build_system_blocks(cfg, kb)[0]["text"]
    assert "SPOKEN, PLAIN ENGLISH" not in rules and "easy to say aloud>" not in rules
