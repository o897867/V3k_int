"""update.py: in-place upgrade that keeps .venv / .env / config.yaml / knowledge / sessions / .state."""
import os
import shutil
import stat
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import update  # noqa: E402

USER_TOP = {"sessions", ".state", "knowledge", ".env", "config.yaml", ".venv"}


def IGNORE(d, names):
    # user folders only at the top level (copilot/knowledge is code and must be copied)
    top = Path(d).resolve() == ROOT.resolve()
    return [n for n in names if n in ("__pycache__", ".pytest_cache") or (top and n in USER_TOP)]


def _copy_app(dst: Path, version: str) -> Path:
    shutil.copytree(ROOT, dst, ignore=IGNORE)
    init = dst / "copilot" / "__init__.py"
    init.write_text(init.read_text().replace('__version__ = "', f'__version__ = "{version}"  # was "'))
    return dst


def _zip_dir(src: Path, out: Path, prefix="interview-copilot") -> Path:
    with zipfile.ZipFile(out, "w") as z:
        for f in src.rglob("*"):
            if f.is_file():
                info = zipfile.ZipInfo(f"{prefix}/{f.relative_to(src)}")
                info.external_attr = (f.stat().st_mode & 0o777) << 16
                z.writestr(info, f.read_bytes())
    return out


def _fake_python(tmp: Path) -> tuple[Path, Path]:
    log = tmp / "pip.log"
    py = tmp / "fakepy"
    py.write_text(f'#!/bin/sh\nif [ "$1" = "-m" ] && [ "$2" = "pip" ]; then echo "$@" >> {log}; exit 0; fi\n'
                  f'exec {sys.executable} "$@"\n')
    py.chmod(0o755)
    return py, log


def _old_project(tmp: Path) -> Path:
    old = _copy_app(tmp / "project", "1.0.0")
    (old / "copilot" / "stale_module.py").write_text("# removed in the new version\n")
    (old / ".env").write_text("ANTHROPIC_API_KEY=sk-ant-api03-mine\n")
    (old / "config.yaml").write_text("candidate:\n  name: Jane Doe\nllm:\n  model: claude-haiku-4-5-20251001\n")
    (old / "knowledge").mkdir()
    (old / "knowledge" / "resume.pdf").write_bytes(b"%PDF my resume")
    (old / "knowledge" / "qa.generated.md").write_text("## Q: mine\nKEY: mine")
    (old / "sessions").mkdir()
    (old / "sessions" / "session-1.md").write_text("history")
    (old / ".state").mkdir()
    (old / ".state" / "ui.json").write_text('{"zoom": 1.3}')
    (old / ".venv" / "bin").mkdir(parents=True)
    (old / ".venv" / "marker").write_text("my env")
    (old / "my_notes.txt").write_text("user file at top level")
    return old


def test_update_from_zip_keeps_user_data(tmp_path, capsys):
    old = _old_project(tmp_path)
    new = _copy_app(tmp_path / "new-src", "9.9.9")
    (new / "copilot" / "brand_new.py").write_text("X = 1\n")
    (new / "knowledge").mkdir()
    shutil.copy2(ROOT / "knowledge" / "README.md", new / "knowledge" / "README.md")  # shipped template
    (new / "requirements.txt").write_text((new / "requirements.txt").read_text() + "\nsomething-new>=1\n")
    z = _zip_dir(new, tmp_path / "interview-copilot.zip")
    py, piplog = _fake_python(tmp_path)

    assert update.main([str(z), "--target", str(old), "--python", str(py)]) == 0
    out = capsys.readouterr().out
    # user data untouched
    assert (old / ".env").read_text() == "ANTHROPIC_API_KEY=sk-ant-api03-mine\n"
    assert (old / "config.yaml").read_text().startswith("candidate:\n  name: Jane Doe")
    assert (old / "knowledge" / "resume.pdf").read_bytes() == b"%PDF my resume"
    assert (old / "knowledge" / "qa.generated.md").read_text() == "## Q: mine\nKEY: mine"
    assert (old / "knowledge" / "README.md").exists()               # template added because it was missing
    assert (old / "sessions" / "session-1.md").read_text() == "history"
    assert (old / ".state" / "ui.json").read_text() == '{"zoom": 1.3}'
    assert (old / ".venv" / "marker").read_text() == "my env"
    assert (old / "my_notes.txt").exists()
    # code replaced
    assert update.version_of(old) == "9.9.9"
    assert (old / "copilot" / "brand_new.py").exists() and not (old / "copilot" / "stale_module.py").exists()
    # launcher stays double-clickable after unzip
    assert os.stat(old / "Interview Copilot.command").st_mode & stat.S_IXUSR
    # deps installed only because requirements changed, into the given python
    assert "-m pip install -q -r" in piplog.read_text()
    # new config keys reported
    assert "+ asr.local.interim" in out and "✅ updated to 9.9.9" in out
    # backup made
    backups = list((old / ".state" / "backups").glob("code-1.0.0-*.zip"))
    assert backups and "copilot/stale_module.py" in zipfile.ZipFile(backups[0]).namelist()


def test_no_pip_when_requirements_unchanged_and_rollback(tmp_path, capsys):
    old = _old_project(tmp_path)
    new = _copy_app(tmp_path / "new-src", "2.0.0")
    py, piplog = _fake_python(tmp_path)
    assert update.main([str(new), "--target", str(old), "--python", str(py)]) == 0
    assert not piplog.exists() and "dependencies unchanged" in capsys.readouterr().out
    assert update.version_of(old) == "2.0.0"
    assert update.main(["--rollback", "--target", str(old)]) == 0
    assert update.version_of(old) == "1.0.0" and (old / "copilot" / "stale_module.py").exists()
    assert (old / ".env").read_text().startswith("ANTHROPIC_API_KEY=sk-ant-api03-mine")


def test_first_time_run_from_new_folder(tmp_path, capsys):
    """Old copy has no update.py: run the NEW folder's update.py from inside the old project."""
    old = _old_project(tmp_path)
    (old / "update.py").unlink()
    new = _copy_app(tmp_path / "new-src", "3.0.0")
    py, _ = _fake_python(tmp_path)
    r = subprocess.run([sys.executable, str(new / "update.py"), "--python", str(py)], cwd=old,
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
    assert update.version_of(old) == "3.0.0" and (old / "update.py").exists()


def test_refuses_wrong_folders(tmp_path, capsys):
    new = _copy_app(tmp_path / "new-src", "4.0.0")
    (tmp_path / "empty").mkdir()
    assert update.main([str(new), "--target", str(tmp_path / "empty")]) == 2
    assert update.main([str(new), "--target", str(new)]) == 2
    assert "same folder" in capsys.readouterr().out
