import asyncio
import math

import numpy as np
import pytest

from copilot.asr.deepgram import build_url, parse_message
from copilot.asr.vad import EnergyVAD
from copilot.capture.audio import resample_to_16k_mono
from copilot.config import Config
from copilot.engine.pipeline import Pipeline
from copilot.engine.question import QuestionKind, classify
from copilot.events import RecordingSink, TranscriptEvent
from copilot.knowledge.loader import KnowledgeBase
from copilot.knowledge.prompt import build_system_blocks, build_user_message
from copilot.knowledge.qa_bank import QABank
from copilot.llm.layered_parser import LayeredParser, parse_layers
from copilot.llm.mock_llm import MockLLM

Q = QuestionKind.QUESTION


@pytest.mark.parametrize("text,kind", [
    ("Can you tell me about yourself?", Q),
    ("So tell me about a time you had a conflict with a stakeholder", Q),
    ("Great, thanks for that. Now, walk me through how you'd build this dashboard.", Q),
    ("How would you find duplicate rows in a SQL table", Q),
    ("I'd love to hear about your experience with Power BI.", Q),
    ("Have you ever worked with Snowflake", Q),
    ("Do you have any questions for us", Q),
    ("okay", QuestionKind.FILLER),
    ("Mm-hmm. Great.", QuestionKind.FILLER),
    ("Thank you", QuestionKind.FILLER),
    ("Our team is about twelve people and we mostly support the trading desk with reporting.",
     QuestionKind.STATEMENT),
])
def test_classify(text, kind):
    assert classify(text) == kind


def test_layered_parser_streaming():
    full = ("KEY: Use a window function to dedupe\nZH: 考察SQL去重\n- ROW_NUMBER over the key\n"
            "- keep rn = 1\n- index the key columns\nSAY: I'd use ROW_NUMBER partitioned by the business key.")
    p = LayeredParser()
    seen = {}
    for i in range(0, len(full), 7):
        for layer, text in p.feed(full[i:i + 7]):
            seen[layer] = text
    assert seen["key"] == "Use a window function to dedupe"
    assert seen["zh"] == "考察SQL去重"
    assert seen["points"].split("\n") == ["ROW_NUMBER over the key", "keep rn = 1", "index the key columns"]
    assert seen["say"].startswith("I'd use ROW_NUMBER")
    assert {"key", "zh", "points"} <= p.completed


def test_parser_tolerates_missing_prefix():
    L = parse_layers("Lead with the migration project\n• cut ETL runtime 40%\nSAY: Sure.")
    assert L["key"] == "Lead with the migration project"
    assert L["points"] == "cut ETL runtime 40%"
    assert L["say"] == "Sure."


QA_MD = """
## Q: Tell me about yourself
ALT: Walk me through your background; Introduce yourself
KEY: Analyst bridging compliance, ops and data
SAY: I'm ...

## Q: Why do you want to work here?
ALT: What attracts you to this role
KEY: Mission + data maturity
SAY: ...

## Q: Tell me about a time you disagreed with a stakeholder
ALT: Describe a conflict at work
KEY: Reporting definition dispute
SAY: ...
"""


def test_qa_bank_matching():
    b = QABank()
    b.load_markdown(QA_MD)
    b.build()
    e, s = b.match("So, to start, could you walk me through your background?")
    assert e.question == "Tell me about yourself" and s > 0.5
    e, s = b.match("what attracts you to this role at our company")
    assert e.question.startswith("Why do you want") and s > 0.5
    e, s = b.match("describe a conflict you had with a colleague")
    assert "disagreed" in e.question
    m = b.match("How would you optimise a slow SQL query with many joins?")
    assert m is None or m[1] < 0.5


def test_deepgram_parse():
    t0 = 100.0
    interim = {"type": "Results", "is_final": False, "start": 1.0, "duration": 0.5,
               "channel": {"alternatives": [{"transcript": "tell me"}]}}
    final = {"type": "Results", "is_final": True, "speech_final": True, "start": 1.0, "duration": 1.2,
             "channel": {"alternatives": [{"transcript": "Tell me about yourself."}]}}
    assert [e.kind for e in parse_message(interim, t0)] == ["interim"]
    evs = parse_message(final, t0)
    assert [e.kind for e in evs] == ["final", "endpoint"]
    assert math.isclose(evs[1].audio_end, 102.2)
    assert [e.kind for e in parse_message({"type": "UtteranceEnd", "last_word_end": 3.0}, t0)] == ["endpoint"]
    assert parse_message({"type": "Metadata"}, t0) == []


def test_deepgram_url_keyterms():
    cfg = Config().asr.deepgram
    url = build_url(cfg, ["Power BI", "Snowflake"])
    assert "keyterm=Power+BI" in url and "endpointing=400" in url and url.startswith("wss://")


def test_resample():
    x = np.random.uniform(-0.5, 0.5, (4800, 2)).astype(np.float32)
    assert len(resample_to_16k_mono(x, 48000)) == 1600
    assert len(resample_to_16k_mono(x[:4410], 44100)) == 1600
    assert resample_to_16k_mono(x, 48000).dtype == np.int16


def test_vad_segments_speech():
    rate = 16000
    sil = (np.random.randn(rate) * 30).astype(np.int16)
    t = np.arange(int(rate * 1.2)) / rate
    speech = (np.sin(2 * np.pi * 220 * t) * 8000).astype(np.int16)
    vad = EnergyVAD(silence_ms=500)
    segs = []
    for chunk in np.array_split(np.concatenate([sil, speech, sil]), 60):
        segs += vad.push(chunk)
    assert len(segs) == 1
    assert 1.1 * rate < len(segs[0]) < 2.0 * rate


def test_prompt_blocks_cache():
    kb = KnowledgeBase(docs={"job_description": "Data Analyst, SQL, Power BI", "resume": "SQL 5 yrs"})
    blocks = build_system_blocks(Config(), kb)
    assert blocks[-1]["cache_control"] == {"type": "ephemeral"}
    assert "<job_description>" in blocks[-1]["text"] and "KEY:" in blocks[0]["text"]
    msg = build_user_message("Why us?", "blah Why us?", [("Tell me about yourself", "Analyst")], None)
    assert msg.endswith('"Why us?"') and "Earlier in this interview" in msg


# ------------------------------------------------------------------ pipeline

def _pipeline(**engine):
    cfg = Config()
    for k, v in engine.items():
        setattr(cfg.engine, k, v)
    kb = KnowledgeBase()
    kb.qa.load_markdown(QA_MD)
    kb.qa.build()
    sink = RecordingSink()
    return Pipeline(cfg, MockLLM(ttft=0.05, tok_per_s=2000), kb, sink), sink


def test_pipeline_answers_question_with_instant_tier():
    async def go():
        p, sink = _pipeline()
        await p.handle(TranscriptEvent("interim", "could you walk me"))
        await p.handle(TranscriptEvent("final", "Could you walk me through your background?"))
        await p.handle(TranscriptEvent("endpoint"))
        await p.wait_idle()
        return p, sink
    p, sink = asyncio.run(go())
    assert len(sink.of("question")) == 1
    prepared = [e for e in sink.of("prepared") if e[4] is False]
    assert prepared and prepared[0][3].question == "Tell me about yourself" and prepared[0][3].locked
    layer_events = sink.of("layer")
    layers = {e[3] for e in layer_events}
    # locked prepared answer fills the main layers; the model's version goes to the ALT block
    assert {"key", "say", "alt_key", "alt_points", "alt_say", "alt_done"} <= layers
    assert "bridge" not in layers  # no bridge line needed when the prepared answer is already up
    key_ev = next(e for e in layer_events if e[3] == "key")
    assert key_ev[4] == "Analyst bridging compliance, ops and data"
    # main-layer text is never touched by the model afterwards
    assert all(e[4] == key_ev[4] for e in layer_events if e[3] == "key")
    assert p.prepared_metrics and p.prepared_metrics[0]["within_budget"]
    m = sink.of("done")[0][3]
    assert m["prepared_locked"] and m["speech_end_to_key"] < 0.05


def test_pipeline_ignores_filler_and_keeps_statements_as_context():
    async def go():
        p, sink = _pipeline()
        for text in ("Okay, great.", "Our team supports the trading desk with daily risk reporting and dashboards."):
            await p.handle(TranscriptEvent("final", text))   # spoken (not typed) input
            await p.handle(TranscriptEvent("endpoint"))
        await asyncio.sleep(0)
        return p, sink
    p, sink = asyncio.run(go())
    assert sink.of("question") == []
    assert p._context_since_q


def test_pipeline_merges_continuation_and_cancels():
    async def go():
        p = Pipeline(Config(), MockLLM(ttft=0.3), KnowledgeBase(), RecordingSink())
        sink = p.sink
        await p.handle(TranscriptEvent("final", "How do you handle missing data?")); await p.handle(TranscriptEvent("endpoint"))
        await asyncio.sleep(0.05)
        await p.handle(TranscriptEvent("final", "Specifically in time series from trading systems.")); await p.handle(TranscriptEvent("endpoint"))
        await p.wait_idle()
        return sink
    sink = asyncio.run(go())
    qs = [e[2] for e in sink.of("question")]
    assert len(qs) == 2 and qs[1].merged_from == qs[0].id
    assert "time series" in qs[1].text and "missing data" in qs[1].text
    done_ids = [e[2] for e in sink.of("done")]
    assert done_ids == [qs[1].id]  # first job was cancelled


def test_pipeline_force_answer():
    async def go():
        p, sink = _pipeline()
        await p.handle(TranscriptEvent("interim", "and your experience with dashboards"))
        await p.force_answer()
        await p.wait_idle()
        return sink
    sink = asyncio.run(go())
    q = sink.of("question")[0][2]
    assert q.forced and "dashboards" in q.text
    assert sink.of("done")


def test_pipeline_survives_llm_error():
    class Boom(MockLLM):
        async def stream(self, msg):
            raise RuntimeError("quota")
            yield  # pragma: no cover

    async def go():
        p = Pipeline(Config(), Boom(), KnowledgeBase(), RecordingSink())
        await p.inject_text("What is a left join?")
        await p.wait_idle()
        return p.sink
    sink = asyncio.run(go())
    assert sink.of("error") and not sink.of("done")
