"""Local Whisper live subtitles + the ASR latency probe (with a fake Whisper; `say` isn't on Linux)."""
import asyncio
import time
from pathlib import Path

import numpy as np

from copilot import asr_probe
from copilot.asr.local_whisper import LocalWhisperASR
from copilot.asr_probe import Segment, build_probe_wav, run_probe_on_wav, score_probe, summarize, word_recall
from copilot.config import Config


def _tone(seconds, f=220):
    t = np.arange(int(16000 * seconds)) / 16000
    return (np.sin(2 * np.pi * f * t) * 8000).astype(np.int16)


def test_score_probe_alignment():
    segs = [Segment(2.0, 4.0, "tell me about yourself"), Segment(7.0, 9.5, "why this role")]
    events = [
        (2.9, "interim", "tell me"), (4.6, "final", "Tell me about yourself."), (4.6, "endpoint", ""),
        (8.2, "interim", "…"), (8.5, "interim", "why"), (10.3, "final", "Why this role?"), (10.3, "endpoint", ""),
    ]
    r = score_probe(segs, events)
    assert abs(r[0].latency - 0.6) < 1e-9 and abs(r[0].first_words - 0.9) < 1e-9 and r[0].accuracy == 1.0
    assert abs(r[1].latency - 0.8) < 1e-9 and abs(r[1].first_words - 1.5) < 1e-9  # '…' placeholder ignored
    s = summarize(r)
    assert s["detected"] == 2 and abs(s["latency_max"] - 0.8) < 1e-9


def test_score_probe_missed_segment():
    r = score_probe([Segment(1, 2, "hello there")], [(0.5, "endpoint", "")])
    assert r[0].latency is None and r[0].accuracy == 0.0


def test_word_recall():
    assert word_recall("How would you use a window function", "how would you use window functions") > 0.6


def test_build_probe_wav_bounds(tmp_path):
    clip = np.concatenate([np.zeros(1600, dtype=np.int16), _tone(1.0), np.zeros(3200, dtype=np.int16)])
    segs = build_probe_wav([clip, clip], ["a", "b"], tmp_path / "p.wav")
    lead, gap = asr_probe.LEAD_S, asr_probe.GAP_S
    assert abs(segs[0].start - (lead + 0.1)) < 0.01 and abs(segs[0].end - (lead + 1.1)) < 0.01
    assert abs(segs[1].start - (lead + len(clip) / 16000 + gap + 0.1)) < 0.01


def _fake_local(infer_s: float, **cfg_over):
    cfg = Config().asr.local
    cfg.interim_every_ms = 300
    for k, v in cfg_over.items():
        setattr(cfg, k, v)
    asr = LocalWhisperASR(cfg)
    calls = {"n": 0}

    def fake(audio):  # stands in for mlx_whisper.transcribe
        calls["n"] += 1
        time.sleep(infer_s)
        secs = len(audio) / 16000
        return "could you walk me through your background" if secs > 0.3 else ""
    asr._impl = fake
    asr.backend = "fake"
    return asr, calls


def test_local_asr_live_subtitles_through_probe(tmp_path, monkeypatch):
    monkeypatch.setattr(asr_probe, "LEAD_S", 0.5)
    monkeypatch.setattr(asr_probe, "GAP_S", 1.5)
    segs = build_probe_wav([_tone(2.0)], ["could you walk me through your background"], tmp_path / "p.wav")
    asr, calls = _fake_local(0.05)
    results = asyncio.run(run_probe_on_wav(asr, tmp_path / "p.wav", segs, timeout=30))
    r = results[0]
    assert asr.interim_enabled
    assert r.first_words is not None and r.first_words < 1.8, "live subtitles should appear while speaking"
    assert r.latency is not None and 0.4 < r.latency < 0.9  # silence_ms 0.5 + fake inference
    assert r.accuracy == 1.0
    assert calls["n"] >= 2 + 1 + 1  # 2 warm-ups + ≥1 interim + final


def test_local_asr_throttles_live_subtitles_on_slow_machine(tmp_path, monkeypatch):
    monkeypatch.setattr(asr_probe, "LEAD_S", 0.5)
    monkeypatch.setattr(asr_probe, "GAP_S", 1.5)
    build_probe_wav([_tone(1.5)], ["could you walk me through your background"], tmp_path / "p.wav")
    asr, _ = _fake_local(0.7)  # slower than interim_max_infer_s=0.6
    statuses = []

    async def go():
        from copilot.capture import WavReplay
        replay = WavReplay(str(tmp_path / "p.wav"), tail_silence_s=2.0)
        evs = []

        async def on_event(ev):
            if ev.kind == "status":
                statuses.append(ev.text)
            evs.append(ev)
        await asyncio.wait_for(asr.run(replay.chunks(), on_event), timeout=30)
        return evs
    evs = asyncio.run(go())
    assert not asr.interim_enabled and "live off" in statuses[0]
    interims = [e.text for e in evs if e.kind == "interim"]
    assert interims == ["…"]  # only the 'someone is speaking' placeholder, no stale partials
    assert [e.kind for e in evs if e.kind in ("final", "endpoint")] == ["final", "endpoint"]
