"""Offscreen UI test: full stack (engine thread + Qt overlay) with the mock LLM."""
import os
import time
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PyQt6")

from PyQt6.QtWidgets import QApplication  # noqa: E402

from copilot.app import EngineThread  # noqa: E402
from copilot.config import load_config  # noqa: E402
from copilot.engine.pipeline import Pipeline  # noqa: E402
from copilot.knowledge import load_knowledge  # noqa: E402
from copilot.llm.mock_llm import MockLLM  # noqa: E402
from copilot.ui.bridge import QtSink  # noqa: E402
from copilot.ui.overlay import Overlay  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _pump(app, secs):
    end = time.time() + secs
    while time.time() < end:
        app.processEvents()
        time.sleep(0.01)


def test_overlay_end_to_end(tmp_path):
    app = QApplication.instance() or QApplication([])
    cfg = load_config(str(ROOT / "config.example.yaml"))
    cfg.knowledge.dir = str(ROOT / "knowledge.example")
    kb = load_knowledge(cfg)
    assert kb.qa.entries and kb.get("job_description")
    sink = QtSink()
    pipe = Pipeline(cfg, MockLLM(ttft=0.1, tok_per_s=1500), kb, sink)
    eng = EngineThread(pipe, None, None, pipe.llm, sink, warmup=False)
    ov = Overlay(cfg, sink, eng, "mock", demo=True)
    ov.show()
    eng.start()
    _pump(app, 0.2)
    eng.inject_text("Great to meet you. So could you walk me through your background?")
    _pump(app, 1.5)
    c = ov._current()
    assert c is not None and c.prepared is not None and c.prepared.question == "Tell me about yourself"
    assert c.key and c.points and c.say and c.metrics
    assert "KEY" in ov.lat_lb.text()
    ov.grab().save(str(tmp_path / "overlay.png"))
    out = os.environ.get("OVERLAY_SCREENSHOT")
    if out:
        ov.grab().save(out)
    # history + toggles
    eng.inject_text("How would you find duplicate rows in a SQL table?")
    _pump(app, 1.5)
    assert len(ov.cards) == 2
    ov.on_hotkey("prev")
    assert ov._current() is ov.cards[0]
    ov.on_hotkey("next")
    assert ov.view == -1
    ov.on_hotkey("toggle_say")
    assert not ov.say_lb.isVisibleTo(ov)
    eng.stop()
    ov.close()


def test_overlay_hybrid_deep_layer():
    app = QApplication.instance() or QApplication([])
    cfg = load_config(str(ROOT / "config.example.yaml"))
    cfg.knowledge.dir = str(ROOT / "knowledge.example")
    kb = load_knowledge(cfg)
    sink = QtSink()
    pipe = Pipeline(cfg, MockLLM(ttft=0.05, tok_per_s=1500), kb, sink,
                    deep_llm=MockLLM(ttft=0.3, tok_per_s=1500, name="claude-sonnet-5"))
    eng = EngineThread(pipe, None, None, pipe.llm, sink, warmup=False)
    assert eng.model_name.endswith("+ claude-sonnet-5")
    ov = Overlay(cfg, sink, eng, eng.model_name, demo=True)
    ov.show()
    eng.start()
    _pump(app, 0.2)
    eng.inject_text("How would you design a dashboard to monitor daily trading volumes?")
    _pump(app, 2.0)
    c = ov._current()
    assert c.blocks["deep"]["key"] and c.blocks["deep"]["done"].startswith("claude-sonnet-5")
    assert ov.block_lb["deep"].isVisibleTo(ov) and "DEEP" in ov.block_hdr["deep"].text()
    out = os.environ.get("OVERLAY_SCREENSHOT_HYBRID")
    if out:
        ov.grab().save(out)
    eng.stop()
    ov.close()


def test_overlay_zoom_help_and_remembered_state(tmp_path):
    app = QApplication.instance() or QApplication([])
    cfg = load_config(str(ROOT / "config.example.yaml"))
    cfg.knowledge.dir = str(ROOT / "knowledge.example")
    state = tmp_path / ".state" / "ui.json"
    sink = QtSink()

    class Ctl:
        model_name = "mock"

    ov = Overlay(cfg, sink, Ctl(), "mock", demo=True, state_path=state)
    ov.show()
    _pump(app, 0.05)
    base = ov.key_lb.font().pixelSize()
    ov.zoom_in_btn.click()
    ov.zoom_in_btn.click()
    assert ov.key_lb.font().pixelSize() > base and abs(ov.zoom - 1.2) < 1e-9
    ov.help_btn.click()
    assert ov.help_lb.isVisibleTo(ov) and "SHORTCUTS" in ov.help_lb.text()
    ov.toggle_block("deep")                      # user collapses DEEP
    ov.on_hotkey("toggle_say")                   # and hides SAY
    ov.setGeometry(130, 140, 500, 520)
    ov.close()                                   # closing saves state
    saved = __import__("json").loads(state.read_text())
    assert saved["zoom"] == 1.2 and saved["collapsed"]["deep"] is True and saved["show_say"] is False
    assert saved["geometry"][2:] == [500, 520]

    ov2 = Overlay(cfg, sink, Ctl(), "mock", demo=True, state_path=state)   # next launch
    assert abs(ov2.zoom - 1.2) < 1e-9 and ov2.collapsed["deep"] and not ov2.show_say
    assert ov2.key_lb.font().pixelSize() == ov.key_lb.font().pixelSize()
    assert (ov2.width(), ov2.height()) == (500, 520)
    ov2.close()


def test_overlay_survives_corrupt_state_file(tmp_path):
    app = QApplication.instance() or QApplication([])  # noqa: F841
    cfg = load_config(str(ROOT / "config.example.yaml"))
    state = tmp_path / "ui.json"
    state.write_text("{not json")

    class Ctl:
        model_name = "mock"
    ov = Overlay(cfg, QtSink(), Ctl(), "mock", demo=True, state_path=state)
    assert ov.zoom == 1.0
    ov.close()
