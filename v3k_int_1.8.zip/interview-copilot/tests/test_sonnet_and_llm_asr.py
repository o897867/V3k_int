"""Sonnet handling (thinking off, no sampling params, fallback), hybrid mode, and the two
LLM-based ASR providers — all against local fakes."""
import asyncio
import json

import httpx
import numpy as np
import pytest

from copilot.asr.openai_realtime import OpenAIRealtimeASR, TurnAssembler, session_update, upsample_16k_to_24k
from copilot.asr.segment_llm import SegmentLLMASR
from copilot.config import Config
from copilot.engine.pipeline import Pipeline
from copilot.events import RecordingSink
from copilot.knowledge.loader import KnowledgeBase
from copilot.llm.mock_llm import MockLLM
from tests.test_network_paths import _sse

# ------------------------------------------------------------------ Sonnet / Anthropic


def _llm_with_transport(monkeypatch, handler, **kw):
    anthropic = pytest.importorskip("anthropic")
    from copilot.llm.anthropic_llm import AnthropicLLM

    monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
    try:
        import httpx2 as hx
    except ImportError:
        hx = httpx
    llm = AnthropicLLM(Config().llm, [{"type": "text", "text": "rules"}], **kw)
    llm.client = anthropic.AsyncAnthropic(api_key="test", max_retries=0,
                                          http_client=hx.AsyncClient(transport=hx.MockTransport(handler(hx))))
    return llm


def _collect(llm):
    async def go():
        return "".join([t async for t in llm.stream('INTERVIEWER JUST ASKED:\n"q"')])
    return asyncio.run(go())


def test_sonnet5_sends_thinking_disabled_and_no_temperature(monkeypatch):
    bodies = []

    def handler(hx):
        def h(req):
            bodies.append(json.loads(req.content))
            return hx.Response(200, headers={"content-type": "text/event-stream"}, content=_sse(["KEY: ok"]))
        return h

    llm = _llm_with_transport(monkeypatch, handler, model="claude-sonnet-5")
    assert _collect(llm) == "KEY: ok"
    b = bodies[0]
    assert b["model"] == "claude-sonnet-5"
    assert b["thinking"] == {"type": "disabled"}
    assert "temperature" not in b and "top_p" not in b


def test_adaptive_low_effort_option(monkeypatch):
    bodies = []

    def handler(hx):
        def h(req):
            bodies.append(json.loads(req.content))
            return hx.Response(200, headers={"content-type": "text/event-stream"}, content=_sse(["KEY: x"]))
        return h

    llm = _llm_with_transport(monkeypatch, handler, model="claude-sonnet-5", thinking="adaptive", effort="low")
    _collect(llm)
    assert bodies[0]["thinking"] == {"type": "adaptive"}
    assert bodies[0]["output_config"] == {"effort": "low"}
    assert bodies[0]["max_tokens"] >= 2500  # room for thinking tokens


def test_rejected_thinking_falls_back_to_model_default(monkeypatch):
    bodies = []

    def handler(hx):
        def h(req):
            body = json.loads(req.content)
            bodies.append(body)
            if "thinking" in body:
                return hx.Response(400, json={"type": "error", "error": {
                    "type": "invalid_request_error", "message": "thinking.type: disabled is not supported"}})
            return hx.Response(200, headers={"content-type": "text/event-stream"}, content=_sse(["KEY: fine"]))
        return h

    llm = _llm_with_transport(monkeypatch, handler, model="claude-some-future-model")
    assert _collect(llm) == "KEY: fine"
    assert "thinking" in bodies[0] and "thinking" not in bodies[1]
    assert llm.thinking == "default"


def test_hybrid_mode_streams_deep_layers():
    async def go():
        sink = RecordingSink()
        p = Pipeline(Config(), MockLLM(ttft=0.02, tok_per_s=3000), KnowledgeBase(), sink,
                     deep_llm=MockLLM(ttft=0.1, tok_per_s=3000, name="sonnet-mock"))
        await p.inject_text("How would you design a KPI dashboard for the trading desk?")
        await p.wait_idle()
        return p, sink
    p, sink = asyncio.run(go())
    layers = [e[3] for e in sink.of("layer")]
    assert {"key", "say", "deep_key", "deep_points", "deep_say", "deep_done"} <= set(layers)
    first_fast = layers.index("key")
    first_deep = layers.index("deep_key")
    assert first_fast < first_deep  # fast model shows first
    done = [e for e in sink.of("layer") if e[3] == "deep_done"][0][4]
    assert done.startswith("sonnet-mock")
    assert "speech_end_to_deep_done" in p.metrics[-1]


def test_new_question_cancels_deep_job_too():
    async def go():
        sink = RecordingSink()
        p = Pipeline(Config(), MockLLM(ttft=0.01, tok_per_s=3000), KnowledgeBase(), sink,
                     deep_llm=MockLLM(ttft=0.5, tok_per_s=3000, name="deep"))
        await p.inject_text("What is a CTE?")
        await asyncio.sleep(0.1)
        await p.inject_text("What is a window function?")
        await p.wait_idle()
        return sink
    sink = asyncio.run(go())
    deep_done_ids = [e[2] for e in sink.of("layer") if e[3] == "deep_done"]
    assert deep_done_ids == [2]


# ------------------------------------------------------------------ OpenAI realtime ASR

def test_turn_assembler():
    t = TurnAssembler()
    assert [e.text for e in t.on_delta("a", "Tell me")] == ["Tell me"]
    assert [e.text for e in t.on_delta("a", " about SQL")] == ["Tell me about SQL"]
    assert t.pending_item() == "a"
    evs = t.on_completed("a", "Tell me about SQL?", 1.0)
    assert [(e.kind, e.text) for e in evs] == [("final", "Tell me about SQL?"), ("endpoint", "")]
    assert t.on_timeout("a", 1.0) == []  # already finalised
    t.on_delta("b", "Why us")
    assert [e.kind for e in t.on_timeout(t.pending_item(), 2.0)] == ["final", "endpoint"]
    assert t.on_completed("b", "Why us?", 2.0) == []


def test_session_update_shape():
    msg = session_update(Config().asr.openai_realtime, ["Power BI", "Snowflake"])
    inp = msg["session"]["audio"]["input"]
    assert msg["session"]["type"] == "transcription"
    assert inp["format"] == {"type": "audio/pcm", "rate": 24000}
    assert inp["turn_detection"] is None
    assert inp["transcription"]["model"] == "gpt-live-transcribe"
    assert inp["transcription"]["keywords"] == ["Power BI", "Snowflake"]
    assert inp["transcription"]["delay"] == "minimal"


def test_upsample():
    x = (np.sin(np.arange(1600) / 5) * 1000).astype(np.int16)
    y = upsample_16k_to_24k(x)
    assert len(y) == 2400 and y.dtype == np.int16


def _speech_audio():
    rate = 16000
    sil = np.zeros(int(rate * 0.6), dtype=np.int16) + (np.random.randn(int(rate * 0.6)) * 20).astype(np.int16)
    t = np.arange(int(rate * 1.0)) / rate
    tone = (np.sin(2 * np.pi * 200 * t) * 8000).astype(np.int16)
    pcm = np.concatenate([sil, tone, sil, sil])
    return [pcm[i:i + 800].tobytes() for i in range(0, len(pcm), 800)]


def _run_realtime(monkeypatch, send_completed: bool):
    from websockets.asyncio.server import serve

    seen = {"session": None, "bytes24": 0, "commits": 0, "auth": None}

    async def handler(ws):
        seen["auth"] = ws.request.headers.get("Authorization")
        async for raw in ws:
            msg = json.loads(raw)
            if msg["type"] == "session.update":
                seen["session"] = msg
            elif msg["type"] == "input_audio_buffer.append":
                seen["bytes24"] += len(__import__("base64").b64decode(msg["audio"]))
            elif msg["type"] == "input_audio_buffer.commit":
                seen["commits"] += 1
                if seen["commits"] == 1:
                    for d in ("Could you", " walk me through", " your background?"):
                        await ws.send(json.dumps({"type": "conversation.item.input_audio_transcription.delta",
                                                  "item_id": "item_1", "delta": d}))
                    if send_completed:
                        await ws.send(json.dumps({
                            "type": "conversation.item.input_audio_transcription.completed",
                            "item_id": "item_1", "transcript": "Could you walk me through your background?"}))

    async def go():
        async with serve(handler, "127.0.0.1", 0) as server:
            port = server.sockets[0].getsockname()[1]
            cfg = Config().asr.openai_realtime
            cfg.url = f"ws://127.0.0.1:{port}/"
            cfg.final_wait_ms = 300
            monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
            asr = OpenAIRealtimeASR(cfg, keyterms=["Power BI"])
            events = []

            async def on_event(ev):
                events.append(ev)

            async def chunks():
                for c in _speech_audio():
                    yield c
                    await asyncio.sleep(0.002)

            await asyncio.wait_for(asr.run(chunks(), on_event), timeout=15)
            return events

    return asyncio.run(go()), seen


def test_realtime_asr_completed_path(monkeypatch):
    events, seen = _run_realtime(monkeypatch, send_completed=True)
    kinds = [e.kind for e in events if e.kind != "status"]
    assert seen["auth"] == "Bearer sk-test"
    assert seen["session"]["session"]["audio"]["input"]["transcription"]["keywords"] == ["Power BI"]
    assert seen["commits"] >= 1
    total16 = sum(len(c) for c in _speech_audio())
    assert abs(seen["bytes24"] - total16 * 1.5) < 64  # resampled to 24 kHz
    assert kinds[:3] == ["interim", "interim", "interim"]
    finals = [e.text for e in events if e.kind == "final"]
    assert finals == ["Could you walk me through your background?"]
    assert kinds.count("endpoint") == 1


def test_realtime_asr_falls_back_to_deltas_when_final_is_slow(monkeypatch):
    events, _ = _run_realtime(monkeypatch, send_completed=False)
    finals = [e.text for e in events if e.kind == "final"]
    assert finals == ["Could you walk me through your background?"]
    assert [e.kind for e in events].count("endpoint") == 1


# ------------------------------------------------------------------ segment LLM ASR

def test_segment_llm_asr(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    seen = {}

    def handler(req: httpx.Request):
        seen["url"] = str(req.url)
        seen["auth"] = req.headers["authorization"]
        seen["body"] = req.content
        return httpx.Response(200, json={"text": "Why do you want to work here?"})

    asr = SegmentLLMASR(Config().asr.llm_segment, keyterms=["Snowflake"])
    asr._client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    events = []

    async def on_event(ev):
        events.append(ev)

    async def chunks():
        for c in _speech_audio():
            yield c

    asyncio.run(asr.run(chunks(), on_event))
    assert seen["url"] == "https://api.openai.com/v1/audio/transcriptions"
    assert seen["auth"] == "Bearer sk-test"
    assert b"gpt-transcribe" in seen["body"] and b"Snowflake" in seen["body"] and b"RIFF" in seen["body"]
    kinds = [e.kind for e in events if e.kind != "status"]
    assert kinds == ["interim", "final", "endpoint"]


# ------------------------------------------------------------------ rejected keys must not retry forever

def test_realtime_asr_stops_on_invalid_key(monkeypatch):
    from websockets.asyncio.server import serve
    from copilot.asr.base import ASRAuthError

    async def handler(ws):  # what OpenAI did in the user's log: close with invalid_api_key
        await ws.recv()
        await ws.close(code=3000, reason="invalid_request_error.invalid_api_key")

    async def go():
        async with serve(handler, "127.0.0.1", 0) as server:
            port = server.sockets[0].getsockname()[1]
            cfg = Config().asr.openai_realtime
            cfg.url = f"ws://127.0.0.1:{port}/"
            cfg.fallback_urls = []
            monkeypatch.setenv("OPENAI_API_KEY", "sk-bad")
            asr = OpenAIRealtimeASR(cfg)

            async def chunks():
                while True:
                    yield np.zeros(800, dtype=np.int16).tobytes()
                    await asyncio.sleep(0.02)

            async def on_event(ev):
                pass
            with pytest.raises(ASRAuthError) as ei:
                await asyncio.wait_for(asr.run(chunks(), on_event), timeout=8)
            return str(ei.value)
    msg = asyncio.run(go())
    assert "OpenAI rejected the API key" in msg and "check_keys" in msg


def test_deepgram_stops_on_401(monkeypatch):
    from websockets.asyncio.server import serve
    from websockets.http11 import Response
    from websockets.datastructures import Headers
    from copilot.asr.base import ASRAuthError
    from copilot.asr.deepgram import DeepgramASR

    def reject(connection, request):
        return Response(401, "Unauthorized", Headers(), b"Invalid credentials")

    async def go():
        async with serve(lambda ws: None, "127.0.0.1", 0, process_request=reject) as server:
            port = server.sockets[0].getsockname()[1]
            monkeypatch.setattr("copilot.asr.deepgram.build_url", lambda cfg, kt: f"ws://127.0.0.1:{port}/")
            monkeypatch.setenv("DEEPGRAM_API_KEY", "bad")
            asr = DeepgramASR(Config().asr.deepgram)

            async def chunks():
                while True:
                    yield np.zeros(800, dtype=np.int16).tobytes()
                    await asyncio.sleep(0.02)

            async def on_event(ev):
                pass
            with pytest.raises(ASRAuthError):
                await asyncio.wait_for(asr.run(chunks(), on_event), timeout=8)
    asyncio.run(go())


def test_env_parsing_inline_comments_and_duplicates(tmp_path):
    from copilot.config import read_dotenv
    (tmp_path / ".env").write_text('\ufeffA=first\nA=second   # comment\nB="quoted # not comment"\n'
                                   "export C=c1\nD=v#notcomment\n", encoding="utf-8")
    env = read_dotenv(tmp_path / ".env")
    assert env == {"A": "second", "B": "quoted # not comment", "C": "c1", "D": "v#notcomment"}
