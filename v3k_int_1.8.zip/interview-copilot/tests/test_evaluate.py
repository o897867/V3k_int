"""Recognition evaluation toolkit + microphone input."""
import asyncio
import time
import wave
from pathlib import Path

import numpy as np
import pytest

from copilot import evaluate as E
from copilot.capture import audio as A
from copilot.config import EXAMPLE_DIR, load_config
from copilot.events import TranscriptEvent, now
from copilot.knowledge import load_knowledge

ROOT = Path(__file__).resolve().parents[1]


def _cfg_kb():
    cfg = load_config(None)
    cfg.knowledge.dir = str(EXAMPLE_DIR)
    return cfg, load_knowledge(cfg)


# ---------------------------------------------------------------- scoring

def test_wer_counts_and_normalisation():
    ref = E.norm_words("Walk me through your Power-BI work, please.")
    assert ref == ["walk", "me", "through", "your", "power", "bi", "work", "please"]
    c = E.wer_counts(["a", "b", "c"], ["a", "x", "c", "d"])
    assert (c["sub"], c["del"], c["ins"]) == (1, 0, 1) and abs(c["wer"] - 2 / 3) < 1e-9
    assert E.wer_counts(["a", "b"], [])["del"] == 2
    assert E.wer_counts(["a"], ["a"])["wer"] == 0


def test_split_by_reference_assigns_words_to_lines():
    refs = ["tell me about yourself", "why do you want this role", "any questions for us"]
    hyp = "tell me about your self why do you want the role any questions for us"
    parts = E.split_by_reference(refs, hyp)
    assert parts[0].startswith("tell me") and "role" in parts[1] and parts[2] == "any questions for us"


def test_keyterms_and_card_matching():
    st = E.keyterm_stats(["Power BI", "Snowflake", "SQL"], ["Do you use Power BI and SQL?"],
                         ["do you use power b i and sql"])
    assert st == {"total": 2, "hits": 1, "misses": ["Power BI"]}
    cards = ["why do you want this role", "tell me about yourself please"]
    assert E.match_cards(["Tell me about yourself.", "What is a p-value?"], cards) == [1, None]


def test_make_script_mixes_prepared_and_unprepared():
    cfg, kb = _cfg_kb()
    lines = E.make_script(kb, 10)
    assert len(lines) == 10 and len(set(lines)) == 10
    ts = E.TestSet("x", [E.Line(t) for t in lines])
    E.tag_prepared(ts, kb, cfg.engine.instant_lock_threshold)
    n_prep = sum(1 for ln in ts.lines if ln.prepared)
    assert 1 <= n_prep <= 8
    sheet = E.reader_sheet(["So, tell me, what brought you to data analytics in the first place?"] * 8)
    assert sheet.count("\n8. ") == 1 and "**…(pause)…**" in sheet
    for ln in lines:                       # "Right, and how do you…" — not "Right, and How do you…"
        for pre in ("So, um, ", "Right, and ", "So, "):
            if ln.startswith(pre):
                rest = ln[len(pre):]
                assert rest.startswith("I ") or not rest[:1].isupper(), ln
                break


# ---------------------------------------------------------------- synthetic audio

def _fake_tts(text, voice, rate, work):
    n = int(16000 * (0.25 + 0.04 * len(text.split())))
    t = np.arange(n) / 16000
    tone = 0.3 * np.sin(2 * np.pi * (180 + 40 * hash(voice) % 200) * t)
    return (np.concatenate([np.zeros(800), tone, np.zeros(800)]) * 32767).astype(np.int16)


def test_build_synthetic_timings_and_roundtrip(tmp_path):
    lines = ["Tell me about yourself.", "So, um, why this role, and why now?", "Any questions for us?"]
    ts = E.build_synthetic(lines, tmp_path / "s", ["Karen", "Daniel"], [None, 15.0], codec=False, band=True,
                           tts=_fake_tts)
    ts.save(tmp_path / "s")
    back = E.TestSet.load(tmp_path / "s")
    assert [ln.text for ln in back.lines] == lines
    starts = [ln.start for ln in back.lines]
    assert starts == sorted(starts) and all(ln.end > ln.start for ln in back.lines)
    assert "noise 15 dB" not in back.lines[0].condition and "noise 15 dB" in back.lines[2].condition
    assert all("phone band" in ln.condition for ln in back.lines)
    assert {ln.condition.split(" · ")[0] for ln in back.lines} == {"Karen", "Daniel"}
    with wave.open(str(tmp_path / "s" / "audio.wav")) as w:
        assert w.getframerate() == 16000 and w.getnframes() / 16000 > back.lines[-1].end
    assert (tmp_path / "s" / "script.txt").read_text().count("\n") == 3


def test_noise_hits_requested_snr():
    rng = np.random.default_rng(0)
    clean = (rng.standard_normal(16000) * 3000).astype(np.int16)
    noisy = E.add_noise(clean, 10.0)
    noise = noisy.astype(np.float32) - clean.astype(np.float32)
    snr = 10 * np.log10(np.mean(clean.astype(np.float32) ** 2) / np.mean(noise ** 2))
    assert 8.5 < snr < 11.5


def test_band_limit_removes_low_frequencies():
    t = np.arange(16000) / 16000
    x = (np.sin(2 * np.pi * 100 * t) * 10000).astype(np.int16)
    assert np.abs(E.band_limit(x)).max() < 500


def test_pick_voices_prefers_distinct_accents():
    avail = [("Samantha", "en_US"), ("Alex", "en_US"), ("Karen", "en_AU"), ("Daniel", "en_GB"), ("Rishi", "en_IN")]
    v = E.pick_voices(avail, 4)
    assert len(v) == 4 and len({dict(avail)[x] for x in v}) == 4


# ---------------------------------------------------------------- run + score end-to-end (fake recogniser)

class ScriptedASR:
    """Emits the scripted text (with one error) right after each line's speech ends in the replayed audio."""

    def __init__(self, ts, speed):
        self.ts, self.speed = ts, speed

    async def run(self, chunks, on_event):
        pos, done = 0.0, 0
        async for data in chunks:
            pos += len(data) / 2 / 16000
            while done < len(self.ts.lines) and pos >= self.ts.lines[done].end + 0.3:
                text = self.ts.lines[done].text.replace("BI work", "BI walk")
                await on_event(TranscriptEvent("final", text, audio_end=now()))
                await on_event(TranscriptEvent("endpoint", "", audio_end=now()))
                done += 1


def test_run_provider_and_report(tmp_path, monkeypatch):
    cfg, kb = _cfg_kb()
    entry = kb.qa.entries[0]
    lines = [entry.question, "How would you find the second highest salary in each department using SQL?",
             "Tell me about yourself and your Power BI work."]
    ts = E.build_synthetic(lines, tmp_path / "s", ["Karen"], [None], codec=False, band=False, tts=_fake_tts)
    E.tag_prepared(ts, kb, cfg.engine.instant_lock_threshold)
    assert ts.lines[0].prepared == entry.question
    speed = 4.0
    import copilot.asr as asr_mod
    monkeypatch.setattr(asr_mod, "build_asr", lambda c, terms=None: ScriptedASR(ts, speed))
    res = asyncio.run(E.run_provider(cfg, kb, "local", tmp_path / "s" / "audio.wav", speed))
    assert not res.error, res.error
    s = E.score(ts, res, ["Power BI", "SQL"])
    assert s["questions"] == 3 and s["detected"] == 3 and s["extra_cards"] == 0
    assert s["prepared_should"] >= 1 and s["prepared_locked"] == s["prepared_should"]
    assert 0 < s["wer"] < 0.15
    assert s["keyterms"]["hits"] == s["keyterms"]["total"] == 2
    assert s["latency_median"] is not None
    rep = E.render_report(ts, [s])
    assert "| local |" in rep and "said: Tell me about yourself and your Power BI work." in rep and "heard:" in rep


def test_cli_run_with_plain_script(tmp_path, monkeypatch):
    cfg, kb = _cfg_kb()
    ts = E.build_synthetic(["Why do you want this role?", "What are your strengths?"], tmp_path / "rec",
                           ["Karen"], [None], codec=False, band=False, tts=_fake_tts)
    (tmp_path / "said.txt").write_text("1. Why do you want this role?\n# comment\n2) What are your strengths?\n")
    import copilot.asr as asr_mod
    monkeypatch.setattr(asr_mod, "build_asr", lambda c, terms=None: ScriptedASR(ts, 8.0))
    monkeypatch.setattr(E, "_cfg_kb", lambda config: (cfg, kb))
    rc = E.main(["run", "--wav", str(tmp_path / "rec" / "audio.wav"), "--script", str(tmp_path / "said.txt"),
                 "--asr", "local", "--speed", "8"])
    assert rc == 0
    rep = next(tmp_path.glob("report-*.md")).read_text()
    assert "2/2" in rep


# ---------------------------------------------------------------- microphone

def test_pick_microphone_skips_loopback():
    devs = [{"index": 0, "name": "BlackHole 2ch"}, {"index": 1, "name": "MacBook Pro Microphone"},
            {"index": 2, "name": "AirPods Pro"}]
    assert A.pick_microphone(devs, 0)["index"] == 1        # default input is BlackHole → real mic instead
    assert A.pick_microphone(devs, 2)["index"] == 2        # default is AirPods → respect it
    assert A.pick_microphone([{"index": 0, "name": "BlackHole 16ch"}], 0) is None


def test_find_device_mic_alias(monkeypatch):
    devs = [{"index": 0, "name": "BlackHole 2ch", "channels": 2, "rate": 48000},
            {"index": 3, "name": "MacBook Pro Microphone", "channels": 1, "rate": 48000}]
    monkeypatch.setattr(A, "list_input_devices", lambda: devs)
    monkeypatch.setattr(A, "_default_input_index", lambda: 0)
    assert A.find_device("default")["index"] == 3
    assert A.find_device("mic")["index"] == 3
    assert A.find_device("BlackHole")["index"] == 0


def test_mic_watch_detects_blocked_and_quiet_mic():
    w = A.MicWatch(16000, zero_s=1.0, quiet_s=2.0)
    z = np.zeros(800, dtype=np.int16).tobytes()
    msgs = [w.feed(z) for _ in range(25)]
    assert sum(1 for m in msgs if m) == 1 and "Privacy" in next(m for m in msgs if m)
    w2 = A.MicWatch(16000, zero_s=1.0, quiet_s=1.0)
    quiet = (np.ones(800) * 200).astype(np.int16).tobytes()
    msgs = [w2.feed(quiet) for _ in range(25)]
    assert any(m and "quiet" in m for m in msgs)
    w3 = A.MicWatch(16000, zero_s=1.0, quiet_s=1.0)
    loud = (np.sin(np.arange(800)) * 5000).astype(np.int16).tobytes()
    assert not any(w3.feed(loud) for _ in range(40))


def test_record_mic_marks_speech(tmp_path, monkeypatch):
    """Fake microphone: silence, then a tone while 'reading'. Marks should land on the tone."""
    cfg, _ = _cfg_kb()
    speaking = {"on": False}

    class FakeCap:
        def __init__(self, *a, **k):
            self.level = 0.0

        async def chunks(self):
            t = 0
            while True:
                await asyncio.sleep(0.05)
                t += 800
                x = np.sin(np.arange(t - 800, t) * 0.2) * 8000 if speaking["on"] else np.random.randn(800) * 30
                yield x.astype(np.int16).tobytes()

    import copilot.capture as cap_mod
    monkeypatch.setattr(cap_mod, "AudioCapture", FakeCap)
    calls = {"n": 0}

    def ask(prompt):
        calls["n"] += 1
        if calls["n"] % 2 == 1:        # "press Enter, then read aloud"
            time.sleep(0.2)
            speaking["on"] = True
            time.sleep(0.6)
            speaking["on"] = False
            time.sleep(0.2)
        return ""

    marks = asyncio.run(E._record_mic(cfg, ["one", "two"], tmp_path / "a.wav", "default", ask=ask))
    assert len(marks) == 2
    for s, e in marks:
        assert 0.4 < e - s < 0.9, (s, e)


# ---------------------------------------------------------------- launcher / app wiring

def test_apply_choice_mic_mode():
    pytest.importorskip("PyQt6")
    from copilot.ui import launcher as L
    cfg = load_config(None)
    c, demo, mock = L.apply_choice(cfg, L.LaunchChoice(mode="mic", asr="local", record=True))
    assert c.audio.device == cfg.audio.mic_device and c.audio.record and not demo and not mock
    assert cfg.audio.device == "BlackHole"
    c2, demo, _ = L.apply_choice(cfg, L.LaunchChoice(mode="practice", record=True))
    assert demo and not c2.audio.record


def test_mic_flag_selects_microphone(monkeypatch):
    from copilot import app
    a = app.parse_args(["--mic"])
    assert a.mic == "default"
    assert app.parse_args(["--mic", "AirPods"]).mic == "AirPods"
    assert app.parse_args([]).mic is None


def test_launcher_mic_mode_and_overlay_warning(tmp_path):
    import os
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    pytest.importorskip("PyQt6")
    from PyQt6.QtWidgets import QApplication
    from copilot.ui import launcher as L
    app = QApplication.instance() or QApplication([])
    (tmp_path / "config.yaml").write_text((ROOT / "config.example.yaml").read_text())
    cfg = load_config(str(tmp_path / "config.yaml"))
    w = L.Launcher(cfg, str(tmp_path / "config.yaml"), tmp_path / ".state" / "launcher.json")
    w.set_choice(mode="mic", record=True)
    ch = w.current_choice()
    assert ch.mode == "mic" and ch.record and w.record_cb.isEnabled() and "microphone" in w.mode_hint.text()
    w.set_choice(mode="practice")
    assert not w.record_cb.isEnabled()
    w.close()

    from copilot.ui.bridge import QtSink
    from copilot.ui.overlay import Overlay

    class Ctl:
        model_name = "mock"

    sink = QtSink()
    ov = Overlay(cfg, sink, Ctl(), "mock", state_path=tmp_path / "ui.json", waiting_text="🎤 Mic test — ask")
    ov.show()
    app.processEvents()
    assert "Mic test" in ov.q_lb.text()
    sink.on_warning("microphone blocked")
    app.processEvents()
    assert ov.warn_lb.isVisible() and "microphone blocked" in ov.warn_lb.text()
    ov.close()
