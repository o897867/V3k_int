# My analysis · [Company] · [Role title]

<!--
怎么用：复制到 knowledge/，改名为 analysis.md，把 [方括号] 换成你的内容，用不上的小节整节删掉。

这份文件会整份放进模型的提示词（有缓存，面试中不会重复计费），模型只用这里和简历、JD 里有的事实，
所以它就是「临场答案的原料库」：写得越具体，答案越像你。

写法：
  · 事实、数字、专有名词用英文写 —— 就是你要说出口的词；给自己的提醒可以写中文。
  · 每个故事都写「影响」：之前 → 之后，下游谁受益。这是答案里「对整个系统带来了什么」的来源。
  · [方括号] 没填，模型会当作不知道，不会编，也不会说出口。
  · 注释（像这一段）不会进入模型。
  · 薪资、签证、入职时间写在 profile.md（另一个文件），不写在这里。
-->


## 0. The one-line pitch
- Who I am: [data analyst, 3 years in regulated trading, compliance + operations data]
- Why this role: [you're building X, I've done X at smaller scale and want to do it at yours]
- The strongest proof: [S1 — month-end reporting, 3 days → 4 hours]


## 1. JD requirements → my evidence
<!-- JD 里最重要的 5–8 条要求，按 JD 的侧重排序。每条都指向下面的一个故事（S1、S2…）。
     没有证据的要求放到第 3 节「短板」，不要硬凑。 -->

| JD requirement | My evidence (story) | Impact on the system (before → after) |
|---|---|---|
| [Advanced SQL] | [S1 reporting pipeline, S3 dedup] | [report 3 days → 4 hours] |
| [Stakeholder management] | [S2 AML thresholds with compliance] | [false positives −35%] |
| [Power BI] | [S4 desk dashboard] | [used daily by 40+ staff] |
| [ ] | [ ] | [ ] |


## 2. Story bank
<!-- 每段经历一个小节。这是回答「技术 → 做了什么 → 对整个系统的影响」的原料，一个故事可以回答很多题：
     把它能回答的题型写在最后一行，模型就知道什么时候用它。 -->

### S1 · [Short name, e.g. Month-end regulatory reporting automation]
- When / where: [2024, Company X, compliance team]
- Problem: [what was broken, slow or risky — and who felt it]
- My part: [what I owned vs what the team did]
- Tech: [Python, SQL Server, Power BI] — why these: [one line]
- What I did: [2–3 concrete actions]
- Impact on the system: [before → after; who downstream benefited — team, report, decision, risk, cost, speed]
- How I know: [dashboard / ticket count / manager feedback — or "rough estimate"]
- Hard part or trade-off: [what I'd say if they dig in]
- Answers questions about: [automation; a project you're proud of; improving a process; SQL/Python in practice]

### S2 · [Short name]
- When / where: [ ]
- Problem: [ ]
- My part: [ ]
- Tech: [ ] — why these: [ ]
- What I did: [ ]
- Impact on the system: [ ]
- How I know: [ ]
- Hard part or trade-off: [ ]
- Answers questions about: [conflict; influencing without authority; a disagreement]

<!-- 建议准备 5–8 个故事，覆盖：一个最骄傲的项目、一次冲突/分歧、一次失败或犯错、一次赶工期、
     一次跟不懂技术的人沟通、一次主动发现问题、一次学新技术。 -->


## 3. Gaps → honest pivot
<!-- JD 要、你没有或不够的东西。每条：真实程度 → 最接近的经历 → 打算怎么补。 -->
- [dbt]: [never used in production] → [I model in plain SQL with CTEs and tests — S1] → [doing the dbt course now]
- [ ]: [ ] → [ ] → [ ]


## 4. The company and the team
- What they do and who pays them: [ ]
- What's happening now (news, launches, regulation): [ ]
- The team and its stack (from the JD / LinkedIn): [ ]
- Why them, specifically — not "a great company": [ ]
- Who is interviewing me and what they care about: [ ]


## 5. Words to use
<!-- 产品名、公司内部叫法、缩写、技术名词。它们会同时帮语音识别听准，也让答案用对词。一行逗号分隔即可。 -->
[Power BI, DAX, SQL Server, ASIC, AML, KYC, Snowflake, dbt, Airflow]


## 6. Don't say
- [Don't criticise my previous employer]
- [Don't name a salary first — see profile.md]
- [ ]


## 7. My questions for them
1. [What would success look like in the first 90 days?]
2. [ ]
3. [ ]
