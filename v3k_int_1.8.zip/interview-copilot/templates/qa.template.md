# Prepared answers · [Company] · [Role title]

<!--
怎么用：复制这个文件到 knowledge/，改名为 qa.md，然后把 [方括号] 换成你自己的内容。
注释（像这一段）不会进入模型，也不会显示在悬浮窗里，可以放心留着。

━━ 每道题一个块，字段顺序固定 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ## Q:      面试官最可能的原话，英文一句                          必填
  ALT:       3–5 种不同的问法，用分号 ; 隔开                       强烈建议 · 实时匹配靠它，越口语越好
  ID:        O1 / B3 / T12 …                                       可选 · 对应你自己的题库编号
  TAGS:      opener | behavioural | technical | closing, ★★★      可选 · 给自己分类用
  ZH:        这题在考什么（≤25 字）                                 可选 · 显示在问题下面
  KEY:       先说出口的一句（≤14 个英文词）                         必填 · 讲经历的题，用「影响」开头
  FLOW:      3–4 行「> 中文一步 | 这一步要用的英文词」               可选 · 不写的话，第一次命中时自动生成并缓存
  - 要点     2–4 条，每条 ≤12 词；讲经历的题，其中一条以 Impact: 开头  建议
  SAY:       完整口述稿，70–120 词，一段                            必填
  追问:      可能的追问 → 你的简短回答（每条一行，可写多行）          可选 · 给模型当上下文
  NOTE:      只给自己看的提醒（可写多行）                            可选 · 不会被说出口

━━ 讲经历的题：三拍，不要只说「我用了什么技术做了什么」 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ① 问题     一句话：什么坏了 / 慢了 / 有风险，谁受影响
  ② 做法     我做了什么、用了什么（技术只提跟问题有关的），为什么这么选
  ③ 影响     对整个系统带来了什么：下游哪个团队 / 报表 / 决策 / 风险 / 成本 / 速度变了
             最好是「之前 → 之后」的数字；没有数字就说具体的变化，
             比如 "ops stopped fixing it by hand"、"compliance had it before the market opened"

  KEY 用 ③ 开头："Cut the month-end report from 3 days to 4 hours by …"
  FLOW 的顺序就是：问题 → 做法 → 影响 → 联系岗位

━━ 规则 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  · [方括号] = 还没填的内容。模型永远不会把方括号里的东西说出口，也不会替你编。
  · 数字写准：你在面试里会被追问。估算的就写 "about" 或 "roughly"。
  · SAY 用说话的方式写：短句、常用词、I'm / I'd / didn't，不用 leveraged / spearheaded。
  · 一题一块。两道题意思一样，就合并成一块，把另一种问法写进 ALT。
  · 已经有旧格式的题库（题目文件 + 参考答案文件，用 O1、B3 这种编号对应）也能继续用：
    两份一起拖进启动窗口即可。新写的题建议用这个格式。
  · 写完后检查：python -m copilot.bank check
    会列出哪些问法能立刻匹配、哪些会串到别的题，以及哪些经历题没说出影响。
-->


## Q: Tell me about yourself.
ALT: Walk me through your background; Give me a quick overview of your experience; Tell me a bit about your career so far; Introduce yourself
ID: [O1]
TAGS: opener, ★★★
ZH: 90 秒讲清你是谁、做过什么、为什么是这个岗位
KEY: [Data analyst who turns messy operational data into reports the business runs on]
FLOW:
> 现在是谁、做什么 | [data analyst, regulated trading]
> 最能代表我的一件事 | [automated month-end reporting]
> 带来的影响 | [3 days → 4 hours, zero late filings]
> 为什么是这个岗位 | [bigger data platform, product decisions]
- [Current role: what I own, in one line]
- Impact: [the one result I'm proudest of, before → after]
- [Why this role, in one line]
SAY: [I'm a data analyst at X. My job sits between compliance, operations and data. The piece I'm proudest of is our month-end reporting. It used to take three days of copy-paste. I rebuilt it as a Python and SQL pipeline, and now it takes about four hours, so compliance files on time every month. I'd like to do the same kind of work on a bigger platform, which is why this role caught my eye.]
NOTE: [控制在 90 秒；别展开第二个项目，等他追问]


## Q: Tell me about a data pipeline or process you built.
ALT: Walk me through something you automated; Describe an ETL process you designed; Tell me about a project you're proud of; What's the most complex thing you've built
ID: [T3]
TAGS: behavioural, technical, ★★★
ZH: 考察端到端 ownership，以及你做的东西对下游有什么用
KEY: [Rebuilt the nightly client-data load so compliance had reports by 8 am, not noon]
FLOW:
> 问题：报表经常迟到 | [nightly load failed, reports late]
> 做法：增量加载 + 校验 | [incremental loads, Python, row-count checks]
> 影响：下游提前 4 小时 | [compliance by 8 am, no manual fixes]
> 联系岗位 | [same pattern for your warehouse]
- Problem: [the load failed about twice a week, reports were late]
- Did: [switched to incremental loads in Python + SQL Server, added row-count checks and alerts]
- Impact: [reports ready by 8 am instead of noon; ops stopped fixing it by hand]
SAY: [Our nightly client-data load failed about twice a week, so the compliance reports were often late. I rebuilt it with incremental loads in Python and SQL Server, and added row-count checks that alert me before anyone else notices. Since then the reports are ready by 8 am instead of noon, and ops don't fix it by hand any more. That meant compliance could review exceptions before the market opened.]
追问: [How did you test it?] → [ran old and new side by side for two weeks and compared row counts]
追问: [What would you do differently?] → [add data contracts with the upstream team earlier]
NOTE: [数字来源：Jira 工单统计；如果被问到，说是 roughly]


## Q: How would you find duplicate records in a table?
ALT: How do you detect duplicates in SQL; Write a query to find duplicate customers; How would you deduplicate a table
ID: [S2]
TAGS: technical, SQL, ★★
ZH: 考 SQL：GROUP BY / 窗口函数，以及去重规则怎么定
KEY: [GROUP BY the business key and keep counts above one — or ROW_NUMBER to pick one]
- ⌨ SELECT email, COUNT(*) FROM customers GROUP BY email HAVING COUNT(*) > 1
- ⌨ ROW_NUMBER() OVER (PARTITION BY email ORDER BY updated_at DESC) = 1 keeps the newest
- [First agree what "the same record" means with the business]
- Impact: [where I used it: cleaned X duplicate clients, so the KYC dashboard stopped double-counting]
SAY: [First I'd agree what counts as the same record, for example the same email. Then GROUP BY that key and keep the groups with more than one row. To remove them, I'd use ROW_NUMBER partitioned by the key and keep the newest row. I did this on our client table. It removed a few hundred duplicates, so the KYC dashboard stopped double-counting clients.]


<!-- ↓ 空白骨架：复制下面整块，填好后删掉方括号。问题以 [ 开头的块会被跳过，所以留着也没关系。 -->

## Q: [The question, the way the interviewer would say it]
ALT: [another way to ask it]; [another]; [a casual one: "so, um, how did you…"]
ID: [ID]
TAGS: [behavioural | technical | opener | closing], [★]
ZH: [这题在考什么]
KEY: [≤14 words — lead with the impact for work stories]
FLOW:
> [问题] | [English words]
> [做法（用了什么）] | [English words]
> [影响（对整个系统）] | [English words]
> [联系岗位] | [English words]
- [Problem]
- [What I did, with what]
- Impact: [before → after, who downstream benefited]
SAY: [70–120 words, spoken: problem → what I did, with what → what it changed for the whole system.]
追问: [likely follow-up] → [short answer]
NOTE: [只给自己看的提醒]
