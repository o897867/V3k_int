#!/usr/bin/env python3
"""Upgrade Interview Copilot in place — keeps your environment, keys, settings, files and history.

    # from your current project folder, with the new download:
    python update.py ~/Downloads/interview-copilot.zip

    # the very first time (your current copy has no update.py yet): unzip the new version anywhere, then
    cd ~/Downloads/interview-copilot            # ← your EXISTING project
    .venv/bin/python ~/Downloads/new/interview-copilot/update.py

    python update.py --rollback                 # undo the last update

Never touched:  .venv/  venv/  .env  config.yaml  knowledge/  sessions/  .state/  (and any file of yours
                that isn't part of the app)
Replaced:       copilot/  scripts/  tests/  knowledge.example/  templates/  and the app's top-level files
Backup first:   .state/backups/code-<version>-<time>.zip   (used by --rollback)
Dependencies:   `pip install -r requirements.txt` into your existing .venv — only if requirements changed
Standard library only, so it runs even if the app's dependencies are broken.
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

PROTECTED = {".venv", "venv", ".env", "config.yaml", "knowledge", "sessions", ".state", ".git"}
MANAGED_DIRS = ["copilot", "scripts", "tests", "knowledge.example", "templates"]
SKIP_NAMES = {"__pycache__", ".pytest_cache", ".DS_Store"}


def log(msg: str) -> None:
    print(msg, flush=True)


def is_app_root(p: Path) -> bool:
    return (p / "run.py").is_file() and (p / "copilot").is_dir()


def find_app_root(p: Path) -> Path | None:
    if is_app_root(p):
        return p
    for child in sorted(p.iterdir()) if p.is_dir() else []:
        if child.is_dir() and is_app_root(child):
            return child
    return None


def version_of(root: Path) -> str:
    try:
        m = re.search(r'__version__\s*=\s*"([^"]+)"', (root / "copilot" / "__init__.py").read_text(encoding="utf-8"))
        return m.group(1) if m else "?"
    except OSError:
        return "?"


def extract_zip(zpath: Path, dest: Path) -> None:
    """zipfile ignores Unix permissions; restore them so the .command launcher stays executable."""
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            out = dest / info.filename
            if not str(out.resolve()).startswith(str(dest.resolve())):
                raise RuntimeError(f"unsafe path in zip: {info.filename}")
            z.extract(info, dest)
            mode = (info.external_attr >> 16) & 0o777
            if mode and not info.is_dir():
                os.chmod(out, mode)


def app_files(root: Path) -> list[Path]:
    """Top-level files that belong to the app (everything at the top of the SOURCE except protected)."""
    return [f for f in root.iterdir() if f.is_file() and f.name not in PROTECTED and f.name not in SKIP_NAMES]


def _ignore(_dir, names):
    return [n for n in names if n in SKIP_NAMES]


def backup(target: Path, source_top_files: list[str]) -> Path:
    bdir = target / ".state" / "backups"
    bdir.mkdir(parents=True, exist_ok=True)
    out = bdir / f"code-{version_of(target)}-{datetime.now():%Y%m%d-%H%M%S}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for d in MANAGED_DIRS:
            base = target / d
            if base.is_dir():
                for f in base.rglob("*"):
                    if f.is_file() and not any(p in SKIP_NAMES for p in f.parts):
                        z.write(f, f.relative_to(target))
        for name in set(source_top_files) | {f.name for f in app_files(target)}:
            f = target / name
            if f.is_file() and name not in PROTECTED:
                z.write(f, name)
    return out


def config_keys(path: Path) -> set[str]:
    """Dotted keys of a YAML file (PyYAML if available; otherwise an indentation-based fallback)."""
    if not path.exists():
        return set()
    try:
        import yaml
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}

        def walk(d, pre=""):
            for k, v in d.items():
                yield pre + str(k)
                if isinstance(v, dict):
                    yield from walk(v, pre + str(k) + ".")
        return set(walk(data))
    except Exception:
        keys, stack = set(), []
        for line in path.read_text(encoding="utf-8").splitlines():
            m = re.match(r"^(\s*)([A-Za-z_][\w-]*):", line)
            if not m or line.lstrip().startswith("#"):
                continue
            depth = len(m.group(1)) // 2
            stack = stack[:depth] + [m.group(2)]
            keys.add(".".join(stack))
        return keys


def venv_python(target: Path, override: str | None) -> str:
    if override:
        return override
    for cand in (target / ".venv" / "bin" / "python", target / "venv" / "bin" / "python",
                 target / ".venv" / "Scripts" / "python.exe"):
        if cand.exists():
            return str(cand)
    return sys.executable


def do_update(source: Path, target: Path, deps: str = "auto", python: str | None = None) -> int:
    src_root = find_app_root(source)
    if src_root is None:
        log(f"❌ {source} doesn't contain the app (run.py + copilot/)")
        return 2
    if src_root.resolve() == target.resolve():
        log("❌ source and target are the same folder. Run this from your EXISTING project folder, pointing at "
            "the NEW zip or folder:  python update.py ~/Downloads/interview-copilot.zip")
        return 2
    if not is_app_root(target):
        log(f"❌ {target} doesn't look like an Interview Copilot folder (no run.py / copilot/). "
            "cd into your existing project first, or pass --target.")
        return 2
    old_v, new_v = version_of(target), version_of(src_root)
    log(f"Updating {target}\n  {old_v} → {new_v}")

    old_req = (target / "requirements.txt").read_text(encoding="utf-8") if (target / "requirements.txt").exists() else ""
    new_req = (src_root / "requirements.txt").read_text(encoding="utf-8") if (src_root / "requirements.txt").exists() else ""
    old_cfg_keys = config_keys(target / "config.yaml")
    top = app_files(src_root)

    b = backup(target, [f.name for f in top])
    log(f"  backup of current code → {b.relative_to(target)}")

    for d in MANAGED_DIRS:
        dst = target / d
        if dst.exists():
            shutil.rmtree(dst)  # removes modules that no longer exist in the new version
        if (src_root / d).is_dir():
            shutil.copytree(src_root / d, dst, ignore=_ignore)
    for f in top:
        shutil.copy2(f, target / f.name)
    # knowledge/: never overwrite the user's files, only add the README if it's missing
    if (src_root / "knowledge").is_dir():
        (target / "knowledge").mkdir(exist_ok=True)
        for f in (src_root / "knowledge").iterdir():
            if f.is_file() and not (target / "knowledge" / f.name).exists():
                shutil.copy2(f, target / "knowledge" / f.name)
    log(f"  replaced: {', '.join(MANAGED_DIRS)} + {len(top)} top-level files")
    log("  kept:     .venv, .env, config.yaml, knowledge/, sessions/, .state/")

    py = venv_python(target, python)
    need = deps == "always" or (deps == "auto" and old_req.strip() != new_req.strip())
    if need:
        log(f"  requirements changed → installing into {py}")
        r = subprocess.run([py, "-m", "pip", "install", "-q", "-r", str(target / "requirements.txt")])
        if r.returncode != 0:
            log("  ⚠ pip install failed — the code is updated; run it yourself:\n"
                f"    {py} -m pip install -r requirements.txt")
    else:
        log("  dependencies unchanged — nothing to install")

    new_keys = sorted(config_keys(target / "config.example.yaml") - old_cfg_keys) if old_cfg_keys else []
    if new_keys:
        log("  new settings available (defaults apply automatically; copy from config.example.yaml to change):")
        for k in new_keys[:25]:
            log(f"    + {k}")

    check = subprocess.run([py, "-c", "import copilot.app, copilot.ui.launcher"], cwd=target,
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
    if sys.platform == "win32" and (target / "scripts" / "win_shortcut.py").exists():
        subprocess.run([py, str(target / "scripts" / "win_shortcut.py")], cwd=target)   # new icon / shortcut
    starter = "the Interview Copilot shortcut or “Interview Copilot.bat”" if sys.platform == "win32" \
        else "“Interview Copilot.command” or python run.py"
    if check.returncode == 0:
        log(f"✅ updated to {new_v}. Start it as before ({starter}).")
    else:
        log("⚠ updated, but the app doesn't import cleanly:\n" + check.stderr.strip()[-800:]
            + "\n  Undo with: python update.py --rollback")
    (target / ".state").mkdir(exist_ok=True)
    (target / ".state" / "version").write_text(new_v, encoding="utf-8")
    return 0


def rollback(target: Path) -> int:
    bdir = target / ".state" / "backups"
    backups = sorted(bdir.glob("code-*.zip"), key=lambda p: p.stat().st_mtime) if bdir.exists() else []
    if not backups:
        log("❌ no backups in .state/backups")
        return 2
    last = backups[-1]
    log(f"Restoring {last.name}")
    for d in MANAGED_DIRS:
        if (target / d).exists():
            shutil.rmtree(target / d)
    extract_zip(last, target)
    log(f"✅ restored code from {last.name} (your .env, config, knowledge, sessions were never changed)")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("source", nargs="?", help="new version: .zip or unzipped folder (default: this script's folder)")
    ap.add_argument("--target", default=".", help="your existing project folder (default: current folder)")
    ap.add_argument("--deps", choices=["auto", "always", "never"], default="auto")
    ap.add_argument("--python", help="python used for pip (default: <target>/.venv/bin/python)")
    ap.add_argument("--rollback", action="store_true", help="restore the code from the last backup")
    a = ap.parse_args(argv)
    target = Path(a.target).expanduser().resolve()
    if a.rollback:
        return rollback(target)
    src = Path(a.source).expanduser().resolve() if a.source else Path(__file__).resolve().parent
    if src.suffix.lower() == ".zip":
        with tempfile.TemporaryDirectory() as t:
            extract_zip(src, Path(t))
            return do_update(Path(t), target, a.deps, a.python)
    return do_update(src, target, a.deps, a.python)


if __name__ == "__main__":
    sys.exit(main())
