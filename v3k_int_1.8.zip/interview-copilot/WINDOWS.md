# Interview Copilot · Windows 使用说明

英文面试实时辅助：听 Teams / Zoom / Google Meet 里面试官的声音，1–2 秒内在一个悬浮窗里给出**要点（KEY）、中文思路、口述稿**。答案基于你自己的简历、JD、求职信和准备好的题库。

**适用**：Windows 10（2004 及以后）/ Windows 11，64 位。不需要显卡——Windows 版默认用云端语音识别。

**你需要准备**

| | 用途 | 去哪里拿 |
|---|---|---|
| Anthropic API key（必需） | 写答案 | https://console.anthropic.com → API Keys |
| Deepgram **或** OpenAI key（二选一） | 语音识别 | Deepgram：https://console.deepgram.com（最快，新账号有免费额度）· OpenAI：https://platform.openai.com/api-keys |
| 你的简历、JD（必需），求职信、自己的分析、题库（可选） | 知识库 | md / txt / pdf / docx 都可以 |

---

## 1. 安装（只需一次，约 5 分钟）

1. **解压**：右键 zip → 「全部解压缩」。不要在压缩包预览窗口里直接双击运行。建议放在 `文档\interview-copilot`。
2. **双击 `install.bat`**
   - 弹出「Windows 已保护你的电脑」→ 点「更多信息」→「仍要运行」。
   - 电脑上没有 Python 时，会问是否自动安装 Python 3.12，按 **Y**。装好后**关闭这个窗口，再双击一次 `install.bat`**。
   - 所有依赖装在本文件夹的 `.venv` 里，不影响电脑上的其他程序。
3. 安装结束会用记事本打开 `.env`：把 key 粘贴在对应的 `=` 后面（不要加引号、空格），**保存**，关闭。
4. 桌面和开始菜单里会多一个带圆相图标的 **Interview Copilot** 快捷方式。

## 2. 每次使用

**双击桌面上的 Interview Copilot**（或文件夹里的 `Interview Copilot.bat`），打开启动窗口：

- **一 文件**：把简历、JD、求职信、分析、题库和参考答案**直接拖进窗口**。「Templates」按钮打开推荐格式的模板（分析 `analysis.template.md`、预备答案 `qa.template.md`），复制到 `knowledge` 文件夹，改名为 `analysis.md` / `qa.md` 后填写。
- **二 Keys**：「Edit keys…」改 key，「Test keys online」在线验证（不收费）。
- **三 运行**
  - Mode：**Interview** 正式面试 · **Mic test** 自己对着麦克风提问来试 · **Practice** 打字提问 · **UI test** 不用 key 看界面
  - Speech：**Deepgram** 或 **OpenAI realtime**（有哪个 key 就自动选哪个）
  - Answers：**Haiku** 最快（推荐）；Sonnet 选项用的是 Sonnet 5.5
- 点「Health check」体检一次，再点朱红色的 **Start** 印章（缺东西时它只是一圈虚线，旁边会写缺什么）。
- 右上角 `Auto / 墨 / 紙`：跟随 Windows 的深浅色 / 深色 / 浅色；窗口标题栏也会跟着变成同一种纸色（Windows 11）。

旁边的黑色命令行窗口是日志，**不要关**（可以最小化）；出问题时截图发给维护者。

## 3. 连接 Teams / Zoom / Meet —— 不用装任何东西

工具录的是 Windows **默认扬声器 / 耳机正在播放的声音**，面试官的声音从哪里出来，它就听哪里。

1. 右下角音量图标 → 选择你要用的耳机或扬声器，设为**默认输出**。
2. Teams：设置 → 设备 → 扬声器，选**同一个设备**（或「与系统相同」）。Zoom / Meet 同理。
3. **验证**：Teams → 设置 → 设备 →「进行测试通话」。你说完话、测试机器人回放时，悬浮窗里应该出现识别出的文字。

**蓝牙耳机特别注意**：通话时 Windows 常会切到一个叫「耳机 / Headset（Hands-Free）」的设备，而默认输出仍是「耳机（立体声）/ Headphones」，于是工具听不到。遇到时二选一：

- 用有线 / USB 耳机，或电脑扬声器；
- 或者打开 `config.yaml`，把 `audio:` 下面的 `device: "loopback"` 改成设备名的一部分，比如 `device: "Hands-Free"`。

想确认能不能听到声音：在本文件夹空白处按住 Shift 右键 →「在终端中打开」，运行
`.venv\Scripts\python scripts\check_audio.py`，同时播放一段视频，进度条会动。

## 4. 悬浮窗怎么看

从上到下：面试官正在说的话 → 问题 → **KEY（先说这一句）** → **思路**（中文的说话顺序，每步后面是要用的英文词）→ 要点 → **SAY**（完整口述稿）。

左侧留了一条窄窄的页边，所有标记都放在这里：问题前的「“」、KEY 前的一笔墨痕、思路的「一 二 三」、要点的「–」。眼睛顺着页边往下走，就知道读到哪一层。

- 左上角的**圆相**：听的时候随声音轻轻起伏，写答案时一笔一笔画出来，暂停时变成空心。还没有问题时，中间有一个大圆相按「吸 4 秒、呼 6 秒」起伏，可以跟着它调整呼吸。

- **想用自己的话说**：保留思路，按 `Ctrl+Alt+S` 收起 SAY。
- 你准备过的题会**立刻**显示你自己的答案：盖上一枚朱印「備」，旁边写着 your prepared answer；模型的版本折叠在下面。
- 右上角：`−` `+` 字号 · `◎` 专注模式 · `◐` 深色 / 浅色 · `?` 全部快捷键。窗口可拖动、右下角可调大小，位置会记住。

| 快捷键 | 作用 |
|---|---|
| **Ctrl+Alt+Space** | 立刻回答（还没识别成问题、等不及时） |
| **Ctrl+Alt+R** | 没听清：显示一句 “Sorry, could you say that again?” 并重新听 |
| **Ctrl+Alt+Y** | 显示 / 隐藏中文思路 |
| **Ctrl+Alt+S** | 显示 / 隐藏 SAY 口述稿 |
| **Ctrl+Alt+F** | 专注模式：只留 KEY + 思路 + SAY，字更大 |
| **Ctrl+Alt+K** | 速查：时间线、数字、项目名 |
| Ctrl+Alt+← / → | 上一题 / 下一题（也可以点窗口上的 ‹ ›） |
| Ctrl+Alt+P | 暂停 / 继续监听 |
| Ctrl+Alt+H | 隐藏 / 显示悬浮窗 |
| Ctrl + = / − / 0 | 字号（悬浮窗有焦点时） |

个别旧的 Intel 显卡驱动把 `Ctrl+Alt+方向键` 用来旋转屏幕；遇到的话用窗口上的 ‹ › 按钮翻页，或在 `config.yaml` 的 `hotkeys:` 里改键。

## 5. 升级

把新版 zip **拖到 `update.bat` 上**。`.venv`、`.env`、`config.yaml`、`knowledge`、`sessions` 都会保留；需要时自动补装依赖；桌面快捷方式会顺便补上 / 换成新图标；出问题可以回滚（命令行：`.venv\Scripts\python update.py --rollback`）。

## 6. 常见问题

- **Speech 里没有 Local Whisper**：Windows 版默认用云端识别。想离线识别且有 NVIDIA 显卡：`.venv\Scripts\pip install faster-whisper`，重启后就会出现。
- **识别不到面试官的声音**：见第 3 节，多半是默认输出设备和 Teams 用的不是同一个。
- **Mic test 没反应**：设置 → 隐私和安全性 → 麦克风 → 打开「允许桌面应用访问你的麦克风」。
- **快捷键没反应**：悬浮窗有焦点时快捷键一定有效；全局无效时，可能是其他软件占用了这个组合键或被安全软件拦截，在 `config.yaml` 的 `hotkeys:` 里换一个。
- **ARM 电脑（骁龙 Snapdragon）**：请安装 **x64 版** Python 3.12（不是 ARM64 版），其余步骤相同。
- **字体**：只用 Windows 自带字体：英文口述稿用 Sitka（为屏幕阅读设计的衬线体），中文提示用楷体，其余用 Segoe UI / 微软雅黑。想让中文思路也像书页上的宋体：安装免费的「思源宋体 / Noto Serif SC」，重启工具即可自动使用。
- **屏幕缩放 125% / 150%、多个显示器**：都支持；把悬浮窗拖到另一块缩放不同的屏幕上，纸纹和印章会按新屏幕重新绘制。
- **不想要桌面快捷方式**：`.venv\Scripts\python scripts\win_shortcut.py --remove`。
- **隐私**：key 只保存在本机的 `.env`；会议声音只发给你选的识别服务（Deepgram 或 OpenAI），问题和你的资料发给 Anthropic 用来写答案。默认不保存录音；只有在启动窗口勾选「Save the audio」时才会保存到 `sessions\`。
- **把工具分享给别人**：直接分享这个 zip 即可——里面不包含你的 key、资料和记录（都在你自己解压后的文件夹里）。
