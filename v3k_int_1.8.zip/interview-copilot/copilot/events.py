"""Events passed between layers. The UI only ever sees these objects."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Protocol


def now() -> float:
    return time.monotonic()


@dataclass
class TranscriptEvent:
    """Produced by the ASR layer.

    kind:
      interim  – unstable partial hypothesis for the current phrase
      final    – stable text for a phrase (append to the utterance)
      endpoint – the speaker paused; the utterance is complete
    """
    kind: str
    text: str = ""
    audio_end: float | None = None  # monotonic wall time the speech ended (best estimate)
    t: float = field(default_factory=now)


@dataclass
class Question:
    id: int
    text: str
    t_speech_end: float
    t_trigger: float
    forced: bool = False
    merged_from: int | None = None
    from_statement: bool = False  # triggered by a long statement, not a question form → UI warns


@dataclass
class PreparedMatch:
    question: str
    answer: str
    score: float
    locked: bool = False  # score ≥ instant_lock_threshold → this IS the answer shown (model becomes ALT)
    unconfirmed: bool = False  # locked while they were still talking, final wording matched less well


class Sink(Protocol):
    """What the engine talks to (implemented by the Qt bridge, tests and the CLI)."""

    def on_transcript(self, final_text: str, interim: str) -> None: ...
    def on_question(self, q: Question) -> None: ...
    def on_prepared(self, qid: int, match: PreparedMatch, live: bool) -> None: ...
    def on_layer(self, qid: int, layer: str, text: str) -> None: ...
    def on_done(self, qid: int, metrics: dict) -> None: ...
    def on_status(self, text: str) -> None: ...
    def on_error(self, text: str) -> None: ...


class NullSink:
    def __getattr__(self, name):
        return lambda *a, **k: None


class RecordingSink:
    """Collects every event — used by tests and the latency bench."""

    def __init__(self):
        self.events: list[tuple] = []

    def _rec(self, *ev):
        self.events.append((now(),) + ev)

    def on_transcript(self, final_text, interim):
        self._rec("transcript", final_text, interim)

    def on_question(self, q):
        self._rec("question", q)

    def on_prepared(self, qid, match, live):
        self._rec("prepared", qid, match, live)

    def on_layer(self, qid, layer, text):
        self._rec("layer", qid, layer, text)

    def on_done(self, qid, metrics):
        self._rec("done", qid, metrics)

    def on_status(self, text):
        self._rec("status", text)

    def on_error(self, text):
        self._rec("error", text)

    def of(self, kind):
        return [e for e in self.events if e[1] == kind]
