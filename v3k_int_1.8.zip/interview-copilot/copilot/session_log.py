"""Session log: JSONL of every event + a Markdown review sheet with latency stats."""
from __future__ import annotations

import json
import statistics
import time
from datetime import datetime
from pathlib import Path


class SessionLogger:
    def __init__(self, directory: Path):
        directory.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        self.jsonl = directory / f"session-{stamp}.jsonl"
        self.md = directory / f"session-{stamp}.md"
        self._fh = open(self.jsonl, "a", encoding="utf-8")
        self._answers: list[dict] = []
        self._prepared: list[dict] = []
        self._t0 = time.time()

    def log(self, event: str, /, **data) -> None:
        """event is positional-only, so callers may pass any field name (including 'kind') in **data.
        Logging must never break the engine: a failure here is reported once and otherwise ignored."""
        try:
            rec = {"t": round(time.time() - self._t0, 3), "event": event, **data}
            self._fh.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
            self._fh.flush()
            if event == "answer":
                self._answers.append(rec)
            elif event == "prepared":
                self._prepared.append(rec)
        except Exception as e:
            if not getattr(self, "_warned", False):
                self._warned = True
                import logging
                logging.getLogger(__name__).warning("session log write failed (%s); continuing without it", e)

    def close(self) -> Path:
        self._fh.close()
        self.md.write_text(render_report(self._answers, self._prepared), encoding="utf-8")
        return self.md


def pct(xs: list[float], p: float) -> float:
    if not xs:
        return float("nan")
    xs = sorted(xs)
    k = (len(xs) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def latency_table(metrics: list[dict]) -> str:
    rows = ["| stage | p50 (s) | p90 (s) | max (s) |", "|---|---|---|---|"]
    for k in ("endpoint_to_trigger", "trigger_to_first_token", "speech_end_to_key", "speech_end_to_done"):
        xs = [m[k] for m in metrics if k in m]
        if xs:
            rows.append(f"| {k} | {pct(xs, .5):.2f} | {pct(xs, .9):.2f} | {max(xs):.2f} |")
    return "\n".join(rows)


def render_report(answers: list[dict], prepared: list[dict] | None = None) -> str:
    out = [f"# Interview session — {datetime.now():%Y-%m-%d %H:%M}", ""]
    prepared = prepared or []
    if prepared:
        xs = [p["speech_end_to_prepared"] for p in prepared]
        ok = sum(1 for p in prepared if p.get("within_budget"))
        out += ["## Prepared answers (instant tier)", "",
                f"{len(prepared)} questions matched your prepared answers; **{ok}/{len(prepared)}** were on screen "
                f"within the 1.5 s budget (p50 {pct(xs, .5):.2f} s, max {max(xs):.2f} s after the interviewer stopped).", ""]
    ms = [a["metrics"] for a in answers]
    if ms:
        within = sum(1 for m in ms if m["speech_end_to_done"] <= 5) / len(ms)
        out += ["## Latency", "", latency_table(ms), "",
                f"Full answer within 5 s: **{within:.0%}** of {len(ms)} questions "
                f"(median KEY at {statistics.median(m['speech_end_to_key'] for m in ms):.2f} s).", ""]
    out += ["## Questions & suggested answers", ""]
    for a in answers:
        L = a["layers"]
        out += [f"### Q{a['id']}. {a['question']}", "", f"**KEY:** {L.get('key', '')}", ""]
        if L.get("points"):
            out += [f"- {p}" for p in L["points"].split("\n")] + [""]
        if L.get("say"):
            out += [f"> {L['say']}", ""]
        out += [f"_{a['metrics']['speech_end_to_done']:.2f} s · {a['metrics']['model']}_", ""]
    return "\n".join(out)
