"""Interview Copilot — real-time, layered interview assistant for macOS.

Layer map (each package is one layer; data flows top → bottom):

    capture/   system audio (BlackHole loopback) → 16 kHz mono PCM chunks
    asr/       PCM → streaming transcript events (Deepgram or local Whisper)
    engine/    transcript → question detection / merging → answer jobs
    knowledge/ JD + resume + cover letter + analysis + prepared Q&A (instant tier)
    llm/       streaming generation, parsed into display layers
    ui/        always-on-top layered overlay + global hotkeys
"""

__version__ = "1.8.0"
