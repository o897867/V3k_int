import sys
from copilot.knowledge.bank import main
sys.exit(main())
