from __future__ import annotations

from typing import AsyncIterator


class LLM:
    name = "llm"

    async def warmup(self) -> None:
        """Open the HTTPS connection and prime the prompt cache before the interview starts."""

    async def keep_warm(self) -> None:
        """Optional background loop that keeps connection / prompt cache hot between questions."""
        return None

    def stream(self, user_message: str) -> AsyncIterator[str]:
        raise NotImplementedError
