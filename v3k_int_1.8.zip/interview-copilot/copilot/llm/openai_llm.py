"""OpenAI or any OpenAI-compatible endpoint (e.g. Groq / local LM Studio via base_url)."""
from __future__ import annotations

import os
from typing import AsyncIterator

from .base import LLM


class OpenAILLM(LLM):
    def __init__(self, cfg, system_blocks: list[dict], model: str | None = None):
        from openai import AsyncOpenAI

        self.cfg = cfg
        self.model = model or cfg.openai.model
        self.name = self.model
        self.system = "\n\n".join(b["text"] for b in system_blocks)
        self.client = AsyncOpenAI(base_url=cfg.openai.base_url or None,
                                  api_key=os.environ.get("OPENAI_API_KEY", "not-needed"))

    async def warmup(self) -> None:
        await self.client.chat.completions.create(
            model=self.model, max_tokens=1,
            messages=[{"role": "system", "content": self.system}, {"role": "user", "content": "OK"}])

    async def stream(self, user_message: str) -> AsyncIterator[str]:
        resp = await self.client.chat.completions.create(
            model=self.model, stream=True, temperature=self.cfg.temperature,
            max_tokens=self.cfg.max_tokens + (getattr(self.cfg, "flow_tokens", 0) if getattr(self.cfg, "flow", False)
                                              else 0),
            messages=[{"role": "system", "content": self.system}, {"role": "user", "content": user_message}],
        )
        async for chunk in resp:
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
