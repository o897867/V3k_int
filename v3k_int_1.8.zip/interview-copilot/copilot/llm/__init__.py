from .base import LLM  # noqa: F401
from .layered_parser import LayeredParser  # noqa: F401


def build_llm(cfg, system_blocks, deep: bool = False):
    """deep=True builds the optional second ('hybrid') model from llm.deep_* settings."""
    c = cfg.llm
    p = c.provider
    if p == "anthropic":
        from .anthropic_llm import AnthropicLLM
        if deep:
            return AnthropicLLM(c, system_blocks, model=c.deep_model, thinking=c.deep_thinking,
                                effort=c.deep_effort, max_tokens=c.deep_max_tokens)
        return AnthropicLLM(c, system_blocks)
    if p == "openai":
        from .openai_llm import OpenAILLM
        return OpenAILLM(c, system_blocks, model=c.deep_model if deep else None)
    if p == "mock":
        from .mock_llm import MockLLM
        return MockLLM(ttft=1.1, tok_per_s=65, name="mock-deep") if deep else MockLLM()
    raise ValueError(f"unknown llm provider {p}")
