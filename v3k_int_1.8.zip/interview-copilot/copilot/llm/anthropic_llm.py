"""Claude via the Anthropic SDK, streaming, with prompt caching on the knowledge block.

Model choice (see README §4):
- claude-haiku-4-5-20251001 (default): fastest first token, no thinking.
- claude-sonnet-5-5 (Sonnet default since 1.8): better answers, but it THINKS BY DEFAULT (adaptive, effort=high),
  which adds seconds before the first word. Thinking can no longer be switched off on 5.5 — {"type": "disabled"}
  is a 400 — so llm.thinking=disabled is sent as its lowest setting, {"type": "between_tools"}: with no tools in
  the request that means no thinking at all. It needs an explicit effort; live answers use `medium`.
- claude-sonnet-5: same idea, but accepts thinking={"type": "disabled"}.
  Both reject non-default temperature/top_p/top_k, so those are never sent to them.

Latency hygiene:
- long-lived keep-alive pool (SDK default drops idle connections after 5 s, and a new
  TLS handshake Melbourne → US costs ~300 ms per question)
- keep_warm(): free `count_tokens` pings hold the connection open; a 1-token call every
  4 min keeps the 5-minute prompt cache alive during long answers/pauses
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import os
import time
from typing import AsyncIterator

from .base import LLM

log = logging.getLogger(__name__)

# models that refuse sampling parameters (400 on non-default temperature)
_NO_SAMPLING = ("claude-sonnet-5", "claude-opus-5", "claude-fable", "claude-mythos")
# models whose lowest thinking setting is "between_tools" ("disabled" is a 400); others are learnt from the error
_LOWEST_BETWEEN_TOOLS = ("claude-sonnet-5-5",)
LIVE_EFFORT = "medium"   # effort sent with between_tools when llm.effort is empty


class AnthropicLLM(LLM):
    def __init__(self, cfg, system_blocks: list[dict], model: str | None = None, thinking: str | None = None,
                 effort: str | None = None, max_tokens: int | None = None):
        import anthropic

        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise RuntimeError("ANTHROPIC_API_KEY is not set (put it in .env)")
        self.cfg = cfg
        self.model = model or cfg.model
        self.name = self.model
        self.system = system_blocks
        self.thinking = (thinking if thinking is not None else cfg.thinking) or "default"
        self.effort = (effort if effort is not None else cfg.effort) or ""
        self.max_tokens = (max_tokens or cfg.max_tokens) + (getattr(cfg, "flow_tokens", 0) if getattr(cfg, "flow", False)
                                                             else 0)
        if self.thinking == "adaptive":  # thinking tokens count against max_tokens
            self.max_tokens = max(self.max_tokens, 2500)
        self._between = self.model.startswith(_LOWEST_BETWEEN_TOOLS)
        self._last_call = 0.0
        self._last_cache = 0.0
        kwargs = {"timeout": 30.0, "max_retries": 1}
        try:  # SDK-flavoured client (the SDK may use httpx or httpx2 internally)
            Limits = type(anthropic.DEFAULT_CONNECTION_LIMITS)
            kwargs["http_client"] = anthropic.DefaultAsyncHttpxClient(
                limits=Limits(max_connections=20, max_keepalive_connections=5, keepalive_expiry=600))
        except Exception as e:  # older SDKs: fall back to defaults
            log.debug("custom keep-alive not applied: %s", e)
        self.client = anthropic.AsyncAnthropic(**kwargs)
        self._params = set(inspect.signature(self.client.messages.stream).parameters)
        self._extra = self._build_extra()

    def _build_extra(self) -> dict:
        extra: dict = {}
        body: dict = {}

        def put(key, value):
            (extra if key in self._params else body)[key] = value

        if self.thinking == "disabled" and self._between:
            put("thinking", {"type": "between_tools"})     # no tools in the request → no thinking
            put("output_config", {"effort": self.effort or LIVE_EFFORT})
        elif self.thinking == "disabled":
            put("thinking", {"type": "disabled"})
        elif self.thinking == "adaptive":
            put("thinking", {"type": "adaptive"})
        if self.effort and self.thinking != "disabled":
            put("output_config", {"effort": self.effort})
        if "temperature" in self._params and not self.model.startswith(_NO_SAMPLING):
            extra["temperature"] = self.cfg.temperature
        if body:
            extra["extra_body"] = body
        return extra

    def _drop_thinking(self, err: Exception) -> bool:
        """If the model rejects the thinking/effort settings, fall back to model defaults once."""
        msg = str(err).lower()
        if "between_tools" in msg and self.thinking == "disabled" and not self._between:
            log.info("%s can't disable thinking — using its lowest setting (between_tools)", self.model)
            self._between = True
            self._extra = self._build_extra()
            return True
        if ("thinking" in msg or "output_config" in msg or "effort" in msg) and self.thinking != "default":
            log.warning("%s rejected thinking=%s/effort=%s — using model defaults: %s",
                        self.model, self.thinking, self.effort, err)
            self.thinking, self.effort = "default", ""
            self._extra = self._build_extra()
            return True
        return False

    async def warmup(self) -> None:
        try:
            await self._cache_ping()
        except Exception as e:
            if self._drop_thinking(e):
                await self._cache_ping()
            else:
                raise

    async def _cache_ping(self) -> None:
        extra = {k: v for k, v in self._extra.items() if k != "temperature"}
        await self.client.messages.create(
            model=self.model, max_tokens=16 if self.thinking == "disabled" else 1024, system=self.system,
            messages=[{"role": "user", "content": "Reply with OK."}], **extra,
        )
        self._last_call = self._last_cache = time.monotonic()

    async def keep_warm(self, conn_every: float = 20.0, cache_every: float = 240.0) -> None:
        while True:
            await asyncio.sleep(5)
            t = time.monotonic()
            try:
                if t - self._last_cache > cache_every:
                    await self._cache_ping()
                elif t - self._last_call > conn_every:
                    await self.client.messages.count_tokens(
                        model=self.model, messages=[{"role": "user", "content": "ping"}])
                    self._last_call = time.monotonic()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.debug("keep-warm failed: %s", e)
                self._last_call = time.monotonic()

    async def stream(self, user_message: str) -> AsyncIterator[str]:
        for attempt in (0, 1):
            self._last_call = self._last_cache = time.monotonic()
            got_any = False
            try:
                async with self.client.messages.stream(
                    model=self.model,
                    max_tokens=self.max_tokens,
                    system=self.system,
                    messages=[{"role": "user", "content": user_message}],
                    **self._extra,
                ) as s:
                    async for text in s.text_stream:  # thinking blocks (if any) are not in text_stream
                        got_any = True
                        yield text
                self._last_call = time.monotonic()
                return
            except asyncio.CancelledError:
                raise
            except Exception as e:
                if attempt == 0 and not got_any and self._drop_thinking(e):
                    continue
                raise
