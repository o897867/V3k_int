"""Offline stand-in with realistic timing — for UI work, demos and tests (no API key)."""
from __future__ import annotations

import asyncio
import re
from typing import AsyncIterator

from .base import LLM


class MockLLM(LLM):
    name = "mock"

    def __init__(self, ttft: float = 0.45, tok_per_s: float = 180.0, name: str = "mock"):
        self.ttft, self.rate, self.name = ttft, tok_per_s, name

    async def stream(self, user_message: str) -> AsyncIterator[str]:
        if user_message.startswith("Write ONLY the FLOW"):
            text = ("FLOW:\n> （演示）先说结论 | lead with the result\n> 再讲一个具体例子 | a concrete example\n"
                    "> 最后联系到这个岗位 | tie it to this role")
            await asyncio.sleep(self.ttft)
            for tok in re.findall(r"\S+\s*|\n", text):
                yield tok
                await asyncio.sleep(1 / self.rate)
            return
        m = re.search(r'INTERVIEWER JUST ASKED:\n"(.*)"', user_message, re.S)
        q = (m.group(1) if m else "the question").strip()
        text = (
            f"KEY: Mock answer — lead with what your work changed for the whole system\n"
            f"ZH: （演示）面试官在问：{q[:20]}\n"
            f"FLOW:\n> 问题：什么坏了、谁受影响 | the problem, who felt it\n> 做法：做了什么、用了什么 | what I did, with what\n"
            f"> 影响：对整个系统 | what it changed downstream\n> 联系到这个岗位 | why it matters here\n"
            f"- Problem: what was slow, broken or risky\n"
            f"- Did: the specific action, tool or query you used\n"
            f"- Impact: before → after, and who downstream benefited\n"
            f"SAY: This is a mock answer so you can test the overlay without an API key. "
            f"In a real session this paragraph is a 70 to 120 word spoken answer to: \"{q}\", "
            f"grounded in your resume, cover letter and your own analysis of the role."
        )
        await asyncio.sleep(self.ttft)
        for tok in re.findall(r"\S+\s*|\n", text):
            yield tok
            await asyncio.sleep(1 / self.rate)
