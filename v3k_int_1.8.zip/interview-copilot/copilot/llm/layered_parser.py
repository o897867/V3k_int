"""Incrementally split a streaming answer into display layers: key / zh / flow / points / say.

The UI renders each layer as soon as its first tokens arrive, so the KEY line is
readable ~1 s after the question ends even though the full SAY paragraph takes longer.

FLOW (思路) is the answer's line of thought in Chinese, one step per line, each with the few English words the
candidate needs to say it — so they can speak freely instead of reading SAY aloud:

    FLOW:
    > 先定每张事实表的粒度 | grain of each fact table
    > 转介、服务接触各一张事实表 | referral fact, service contact fact
"""
from __future__ import annotations

import re

LAYERS = ("key", "zh", "flow", "points", "say")
_HDR = re.compile(r"^\s*(KEY|ZH|SAY|POINTS|FLOW|思路)\s*[:：]\s*", re.I)
_BULLET = re.compile(r"^\s*(?:[-•*]|\d+[.)])\s+")
_STEP = re.compile(r"^\s*(?:>|→|›|»|\d+[.)、]|[①②③④⑤⑥]|[一二三四五六][、.．])\s*")


def parse_layers(buf: str) -> dict[str, str]:
    out = {k: "" for k in LAYERS}
    points: list[str] = []
    steps: list[str] = []
    cur = None
    for raw in buf.split("\n"):
        line = raw.strip()
        if not line:
            continue
        m = _HDR.match(line)
        if m:
            tag = m.group(1).lower()
            cur = {"points": "points", "思路": "flow"}.get(tag, tag)
            rest = line[m.end():].strip()
            if cur == "points":
                if rest:
                    points.append(_BULLET.sub("", rest))
            elif cur == "flow":
                if rest:
                    steps.append(_STEP.sub("", rest))
            else:
                out[cur] = (out[cur] + " " + rest).strip() if rest else out[cur]
            continue
        if cur == "flow" and not (_BULLET.match(line) and line[:1] in "-•*"):
            # a step: "> 中文 | English", "1. …", "① …" — or a continuation of the previous one
            if _STEP.match(line) or not steps:
                steps.append(_STEP.sub("", line).replace("**", ""))
            else:
                steps[-1] += " " + line.replace("**", "")
            continue
        if _BULLET.match(line) and cur != "say":
            cur = "points"
            points.append(_BULLET.sub("", line))
            continue
        line = line.replace("**", "")
        if cur is None:  # model skipped the KEY: prefix
            cur = "key"
        if cur == "points":
            if points:
                points[-1] += " " + line
            else:
                points.append(line)
        else:
            out[cur] = (out[cur] + " " + line).strip()
    out["points"] = "\n".join(p.replace("**", "") for p in points)
    out["flow"] = "\n".join(x.strip() for x in steps if x.strip())
    return out


def split_step(step: str) -> tuple[str, str]:
    """'先定粒度 | grain of each fact' → ('先定粒度', 'grain of each fact'). English part may be missing."""
    for sep in (" | ", "｜", "|", " — ", " / "):
        if sep in step:
            zh, en = step.split(sep, 1)
            return zh.strip(), en.strip()
    return step.strip(), ""


class LayeredParser:
    def __init__(self):
        self.buf = ""
        self.state = {k: "" for k in LAYERS}
        self.completed: set[str] = set()

    def feed(self, chunk: str) -> list[tuple[str, str]]:
        """Returns [(layer, full_text_of_layer)] for every layer that changed."""
        self.buf += chunk
        new = parse_layers(self.buf)
        changed = [(k, new[k]) for k in LAYERS if new[k] != self.state[k]]
        self.state = new
        # a layer is 'complete' once a later layer has started
        if new["key"] and "\n" in self.buf.lstrip():  # first line (KEY) has ended
            self.completed.add("key")
        started = [k for k in LAYERS if new[k]]
        if started:
            last = max(LAYERS.index(k) for k in started)
            for k in LAYERS[:last]:
                if new[k]:
                    self.completed.add(k)
        return changed
