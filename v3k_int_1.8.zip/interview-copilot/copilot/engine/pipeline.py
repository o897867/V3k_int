"""Engine layer: transcript events → questions → (instant match ‖ streamed LLM answer) → sink.

Latency path for a normal question (Deepgram + Haiku, typical):
    interviewer stops ─ endpointing 400 ms ─ final+endpoint ─ classify <1 ms ─ instant match <5 ms
    ─ LLM first token ~0.5–0.9 s ─ KEY line complete ~+0.3 s ─ points ~+0.8 s ─ SAY ~+1.5 s
    ⇒ KEY on screen ≈ 1.3–2 s after the interviewer stops; full answer ≈ 3–4 s.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import re
from collections import deque

import random

from ..events import PreparedMatch, Question, Sink, TranscriptEvent, now
from ..knowledge.prompt import build_flow_message, build_user_message
from ..llm.layered_parser import LayeredParser, parse_layers
from .question import QuestionKind, classify, question_topic

log = logging.getLogger(__name__)


class Pipeline:
    def __init__(self, cfg, llm, kb, sink: Sink, logger=None, deep_llm=None, flow_cache=None):
        self.cfg, self.ecfg = cfg, cfg.engine
        self.llm, self.kb, self.sink, self.logger = llm, kb, sink, logger
        self.deep_llm = deep_llm              # hybrid mode: stronger model streaming in parallel
        self._deep_job: asyncio.Task | None = None
        self.paused = False
        self._parts: list[str] = []          # finals of the utterance in progress
        self._interim = ""
        self._utt_start: float | None = None
        self._finals: deque[tuple[float, str]] = deque(maxlen=400)
        self._context_since_q: list[str] = []  # non-question statements since the last question
        self._next_id = 1
        self._last_q: Question | None = None
        self._job: asyncio.Task | None = None
        self._history: deque[tuple[str, str]] = deque(maxlen=max(0, self.ecfg.history_turns))
        self._live_key: str | None = None
        self._live_locked: tuple | None = None   # (qid, entry, score, t_shown) of a provisional card on screen
        self._last_live_t = 0.0
        self.metrics: list[dict] = []
        self.prepared_metrics: list[dict] = []   # one per prepared hit: speech_end_to_prepared etc.
        self._bridge_i = 0
        # 思路 for prepared answers that don't have one: written once by the model, then instant (JsonState or dict)
        self._flow_cache = flow_cache if flow_cache is not None else {}
        self._flow_job: asyncio.Task | None = None

    # ------------------------------------------------------------------ input
    async def handle(self, ev: TranscriptEvent) -> None:
        if ev.kind == "status":
            self.sink.on_status(ev.text)
            return
        if self.paused:
            return
        if ev.kind == "interim":
            if self._utt_start is None:
                self._utt_start = ev.t
            self._interim = ev.text
            self.sink.on_transcript(" ".join(self._parts), self._interim)
            self._live_match()
        elif ev.kind == "final":
            if self._utt_start is None:
                self._utt_start = ev.t
            self._parts.append(ev.text)
            self._finals.append((ev.t, ev.text))
            self._interim = ""
            self.sink.on_transcript(" ".join(self._parts), "")
            if self.logger:
                self.logger.log("final", text=ev.text)
            self._live_match()
        elif ev.kind == "endpoint":
            if not self._parts and self._interim:  # endpoint before the last final: keep the interim
                self._parts.append(self._interim)
            if self._parts:
                text = " ".join(self._parts).strip()
                start = self._utt_start or ev.t
                self._parts, self._interim, self._utt_start = [], "", None
                await self._on_utterance(text, ev.audio_end or ev.t, start)

    async def inject_text(self, text: str) -> None:
        """Demo / typed input: like a spoken utterance, but never merged into the previous question
        (typing is deliberate — a second typed line is a new question)."""
        t = now()
        log.info("engine received: %r", text)
        self._finals.append((t, text))
        self.sink.on_transcript(text, "")
        await self._on_utterance(text, t, t, allow_merge=False, typed=True)

    async def force_answer(self) -> None:
        """Hotkey: answer whatever has been said so far, right now."""
        text = " ".join([*self._parts, self._interim]).strip()
        self._parts, self._interim, self._utt_start = [], "", None
        if not text and self._context_since_q:
            text = " ".join(self._context_since_q[-2:])
        if not text and self._last_q:
            text = self._last_q.text
        if not text:
            self.sink.on_status("Nothing heard yet to answer")
            return
        t = now()
        await self._start(Question(self._take_id(), text, t, t, forced=True))

    # ------------------------------------------------------------- decisions
    async def _on_utterance(self, text: str, t_end: float, t_start: float, allow_merge: bool = True,
                            typed: bool = False) -> None:
        kind = classify(text, self.ecfg.min_question_words)
        if self.logger:
            self.logger.log("utterance", text=text, kind=kind.value)
        if kind == QuestionKind.FILLER:
            log.info("ignored as filler: %r", text)
            return
        lq = self._last_q
        if allow_merge and lq is not None and (t_start - lq.t_speech_end) <= self.ecfg.merge_window_s:
            # interviewer kept talking after a short pause → same question, re-answer with the full text
            merged = Question(self._take_id(), f"{lq.text} {text}", t_end, now(), merged_from=lq.id)
            await self._start(merged)
            return
        if kind == QuestionKind.QUESTION:
            await self._start(Question(self._take_id(), text, t_end, now()))
        elif typed or (self.ecfg.statement_trigger_words and len(text.split()) >= self.ecfg.statement_trigger_words):
            # typed demo input is always answered; long spoken statements too — both flagged as statements
            await self._start(Question(self._take_id(), text, t_end, now(), from_statement=True))
        else:
            log.info("kept as context (not a question): %r", text[:80])
            self._context_since_q.append(text)
            self._context_since_q = self._context_since_q[-6:]

    def _take_id(self) -> int:
        i = self._next_id
        self._next_id += 1
        return i

    def _live_match(self) -> None:
        if not self.ecfg.live_match_on_interim or not self.kb.qa.entries:
            return
        t = now()
        if t - self._last_live_t < 0.25:
            return
        self._last_live_t = t
        text = " ".join([*self._parts, self._interim])
        if len(text.split()) < 3:
            return
        m = self.kb.qa.match(text)
        if m and m[1] >= self.ecfg.instant_match_threshold + 0.1 and m[0].question != self._live_key:
            self._live_key = m[0].question
            locked = m[1] >= self.ecfg.instant_lock_threshold
            if locked:
                self._live_locked = (self._next_id, m[0], m[1], t)
            # qid = the id the coming question will get, so the UI can turn the provisional card into the real one
            self.sink.on_prepared(self._next_id, PreparedMatch(m[0].question, self._answer_text(m[0]), m[1], locked),
                                  True)
            if self.logger:
                self.logger.log("live_prepared", question=m[0].question, score=round(m[1], 3), locked=locked)

    # --------------------------------------------------------------- answering
    async def _start(self, q: Question) -> None:
        for job in (self._job, self._deep_job, self._flow_job):
            if job and not job.done():
                job.cancel()
        self._last_q = q
        self._live_key = None
        live = self._live_locked if self._live_locked and self._live_locked[0] == q.id else None
        self._live_locked = None
        context = self._context_since_q[-3:]
        self._context_since_q = []
        self.sink.on_question(q)
        log.info("question #%d: %r%s", q.id, q.text[:80], " (from statement)" if q.from_statement else "")
        if self.logger:
            self.logger.log("question", id=q.id, text=q.text, forced=q.forced, merged_from=q.merged_from)

        hint = None
        locked = False
        m = self.kb.qa.match(q.text)
        if live is not None and not (m and m[1] >= self.ecfg.instant_lock_threshold):
            # A provisional prepared answer was already on screen while they spoke, but the final wording
            # matches less well. The candidate may be reading it — never overwrite it. Keep it in the main
            # layers flagged 'unconfirmed'; the model's answer goes to the MODEL VERSION block right below.
            _, entry, score, t_shown = live
            locked = True
            self.sink.on_prepared(q.id, PreparedMatch(entry.question, self._answer_text(entry), score, True,
                                                      unconfirmed=True),
                                  False)
            pm = {"id": q.id, "score": round(score, 3), "prepared": entry.question, "unconfirmed": True,
                  "speech_end_to_prepared": max(0.0, t_shown - q.t_speech_end), "within_budget": True}
            self.prepared_metrics.append(pm)
            if self.logger:
                self.logger.log("prepared", **pm)
            hint = f"Q: {entry.question}\n{entry.answer}"
            m = None
        if m:
            entry, score = m
            locked = score >= self.ecfg.instant_lock_threshold
            if score >= self.ecfg.instant_match_threshold:
                self.sink.on_prepared(q.id, PreparedMatch(entry.question, self._answer_text(entry), score, locked),
                                      False)
            if locked:
                # Tier-1: the candidate's own prepared answer goes straight into the main layers.
                # Nothing the model streams later may overwrite it (the model goes to the ALT block).
                layers = parse_layers(self._answer_text(entry))
                for layer in ("key", "zh", "flow", "points", "say"):
                    if layers.get(layer):
                        self.sink.on_layer(q.id, layer, layers[layer])
                t_prep = now()
                pm = {"id": q.id, "score": round(score, 3), "prepared": entry.question,
                      "speech_end_to_prepared": t_prep - q.t_speech_end,
                      "within_budget": (t_prep - q.t_speech_end) <= self.ecfg.prepared_budget_s}
                self.prepared_metrics.append(pm)
                if self.logger:
                    self.logger.log("prepared", **pm)
            if score >= self.ecfg.instant_match_threshold * 0.8:
                hint = f"Q: {entry.question}\n{entry.answer}"
        if not locked:
            self.sink.on_layer(q.id, "bridge", self._bridge(q.text))
        else:
            entry = self._locked_entry(q)
            if entry is not None and self._needs_flow(entry):
                self._flow_job = asyncio.create_task(self._prepared_flow(q, entry))

        recent = self._recent_text(q.t_trigger)
        if context:
            recent = (" ".join(context) + " " + recent).strip()
        msg = build_user_message(q.text, recent[-1200:], list(self._history), hint)
        self._job = asyncio.create_task(self._answer(q, msg, prefix="alt_" if locked else ""))
        if self.deep_llm is not None:
            self._deep_job = asyncio.create_task(self._answer_deep(q, msg))

    # ------------------------------------------------------------------ 思路 for prepared answers
    @staticmethod
    def _flow_key(entry) -> str:
        return hashlib.sha1((entry.question + "\n" + entry.answer).encode()).hexdigest()[:16]

    def _answer_text(self, entry) -> str:
        """The prepared answer, plus its cached 思路 if the file itself has none."""
        if parse_layers(entry.answer)["flow"]:
            return entry.answer
        flow = self._flow_cache.get(self._flow_key(entry))
        if not flow:
            return entry.answer
        return entry.answer + "\nFLOW:\n" + "\n".join("> " + x for x in flow.split("\n") if x)

    def _needs_flow(self, entry) -> bool:
        lc = self.cfg.llm
        return bool(getattr(lc, "flow", False) and getattr(lc, "flow_for_prepared", False)
                    and not parse_layers(self._answer_text(entry))["flow"])

    def _locked_entry(self, q: Question):
        pm = next((x for x in reversed(self.prepared_metrics) if x["id"] == q.id), None)
        if pm is None:
            return None
        return next((e for e in self.kb.qa.entries if e.question == pm["prepared"]), None)

    async def _prepared_flow(self, q: Question, entry) -> None:
        """Write the 思路 of a prepared answer (follows its order, adds nothing), stream it into the main 'flow'
        layer, and cache it so the next time this answer matches the 思路 is on screen instantly."""
        buf, last = "", ""
        try:
            async for chunk in self.llm.stream(build_flow_message(self.cfg, entry.question, entry.answer)):
                buf += chunk
                text = buf if re.search(r"(?m)^\s*(FLOW|思路)\s*[:：]", buf) else "FLOW:\n" + buf
                flow = parse_layers(text)["flow"]
                if flow and flow != last:
                    last = flow
                    self.sink.on_layer(q.id, "flow", flow)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("prepared 思路 failed: %s", e)
            return
        if last:
            key = self._flow_key(entry)
            if hasattr(self._flow_cache, "save"):
                self._flow_cache.set(key, last)
                self._flow_cache.save()
            else:
                self._flow_cache[key] = last
            if self.logger:
                self.logger.log("prepared_flow", id=q.id, prepared=entry.question, flow=last)

    def _bridge(self, text: str, kind: str | None = None) -> str:
        """A natural sentence to say out loud while the answer loads. Rotates within a kind."""
        phrases = self.ecfg.bridge_phrases or {}
        kind = kind or question_topic(text)
        pool = phrases.get(kind) or phrases.get("general") or []
        if not pool:
            return ""
        self._bridge_i += 1
        return pool[(self._bridge_i + random.randint(0, 1)) % len(pool)] if len(pool) > 1 else pool[0]

    def clarify(self) -> str:
        """Hotkey: show a 'could you repeat that' line and discard the half-heard utterance."""
        self._parts, self._interim, self._utt_start = [], "", None
        text = self._bridge("", kind="clarify")
        qid = self._last_q.id if self._last_q else 0
        self.sink.on_layer(qid, "clarify", text)
        return text

    def _recent_text(self, t: float) -> str:
        return " ".join(txt for ts, txt in self._finals if t - ts <= self.ecfg.recent_context_s)

    async def _answer(self, q: Question, msg: str, prefix: str = "") -> None:
        """prefix='' → main layers; prefix='alt_' → secondary block (a prepared answer holds the main layers)."""
        parser = LayeredParser()
        t_first = t_key = None
        try:
            async for chunk in self.llm.stream(msg):
                if t_first is None:
                    t_first = now()
                for layer, text in parser.feed(chunk):
                    self.sink.on_layer(q.id, prefix + layer, text)
                if t_key is None and "key" in parser.completed:
                    t_key = now()
        except asyncio.CancelledError:
            if self.logger:
                self.logger.log("cancelled", id=q.id)
            raise
        except Exception as e:  # network / quota / auth — never crash the session
            log.exception("LLM error")
            self.sink.on_error(f"LLM error: {e.__class__.__name__}: {str(e)[:160]}")
            return
        t_done = now()
        t_key = t_key or t_done
        if prefix:  # prepared answer was already on screen; KEY latency is the prepared one
            pm = next((x for x in reversed(self.prepared_metrics) if x["id"] == q.id), None)
            if pm:
                t_key = q.t_speech_end + pm["speech_end_to_prepared"]
            self.sink.on_layer(q.id, prefix + "done", f"{getattr(self.llm, 'name', 'model')} · {t_done - q.t_speech_end:.1f}s")
        m = {
            "id": q.id, "model": getattr(self.llm, "name", "?"), "forced": q.forced, "prepared_locked": bool(prefix),
            "endpoint_to_trigger": q.t_trigger - q.t_speech_end,
            "trigger_to_first_token": (t_first or t_done) - q.t_trigger,
            "speech_end_to_key": t_key - q.t_speech_end,
            "speech_end_to_done": t_done - q.t_speech_end,
        }
        self.metrics.append(m)
        key = parser.state["key"]
        if prefix and self.prepared_metrics and self.prepared_metrics[-1]["id"] == q.id:
            prep = next((e for e in self.kb.qa.entries if e.question == self.prepared_metrics[-1]["prepared"]), None)
            key = (parse_layers(prep.answer).get("key") if prep else "") or key
        self._history.append((q.text, key))
        self.sink.on_done(q.id, m)
        if self.logger:
            self.logger.log("answer", id=q.id, question=q.text, layers=parser.state, metrics=m)

    async def _answer_deep(self, q: Question, msg: str) -> None:
        """Hybrid mode: the stronger model's answer streams into 'deep_*' layers below the fast one."""
        parser = LayeredParser()
        try:
            async for chunk in self.deep_llm.stream(msg):
                for layer, text in parser.feed(chunk):
                    self.sink.on_layer(q.id, "deep_" + layer, text)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("deep model error: %s", e)
            self.sink.on_layer(q.id, "deep_error", f"{e.__class__.__name__}: {str(e)[:120]}")
            return
        secs = now() - q.t_speech_end
        self.sink.on_layer(q.id, "deep_done", f"{getattr(self.deep_llm, 'name', 'deep')} · {secs:.1f}s")
        if self.metrics and self.metrics[-1]["id"] == q.id:
            self.metrics[-1]["speech_end_to_deep_done"] = secs
        if self.logger:
            self.logger.log("deep_answer", id=q.id, layers=parser.state, seconds=secs)

    async def wait_idle(self) -> None:
        for job in (self._job, self._deep_job, self._flow_job):
            if job:
                try:
                    await job
                except asyncio.CancelledError:
                    pass
