"""Is this utterance something the candidate must answer?

Heuristic on purpose: it runs in microseconds on every endpoint. A missed question
is recoverable (⌘⇧Space forces an answer); a model call here would cost ~500 ms.
"""
from __future__ import annotations

import re
from enum import Enum


class QuestionKind(str, Enum):
    QUESTION = "question"      # clearly a question / prompt to answer
    STATEMENT = "statement"    # substantive, but not a question (company intro, context)
    FILLER = "filler"          # 'okay', 'great', 'mm-hmm', 'thanks'


_FILLER = {
    "ok", "okay", "great", "cool", "right", "yeah", "yes", "yep", "sure", "awesome", "perfect", "mm", "mhm",
    "mm-hmm", "uh", "um", "hmm", "thanks", "thank you", "sounds good", "got it", "nice", "alright", "all right",
    "wonderful", "excellent", "fantastic", "good", "lovely", "interesting", "i see", "fair enough", "no worries",
    "that's great", "that makes sense", "makes sense", "brilliant", "amazing", "wow", "oh",
}

_STARTERS = (
    "what", "what's", "whats", "why", "how", "how's", "when", "where", "who", "which", "whose",
    "can you", "could you", "would you", "will you", "do you", "did you", "have you", "are you", "were you",
    "is there", "is it", "are there", "was there", "should", "shall we",
    "tell me", "tell us", "walk me", "walk us", "talk me", "talk us", "describe", "explain", "give me",
    "give us", "share", "take me through", "take us through", "run me through", "run us through",
    "i'd like to hear", "i would like to hear", "i'd love to hear", "i'm curious", "i am curious",
    "i'd like to know", "i want to know", "let's talk about", "let's hear", "imagine", "suppose",
    "say you", "if you were", "if you had", "in your opinion", "in your experience", "any questions",
    "anything you", "how about", "what about", "talk about", "elaborate", "expand on", "go into",
    "can we", "could we", "would it", "so what", "so how", "so why", "so tell", "so can", "so could",
    "and what", "and how", "and why", "and can", "and could", "and do", "and did", "and have",
)
_IMPERATIVE_ANYWHERE = re.compile(
    r"\b(tell (me|us)|walk (me|us)|talk (me|us)|describe|explain|give (me|us)( an| a)? example|"
    r"share (an|a|some)|take (me|us) through|run (me|us) through|elaborate|expand on|"
    r"how would you|what would you|how do you|what do you|why do you|why did you|how did you|what did you|"
    r"do you have|have you (ever|used|worked|had)|are you (familiar|comfortable)|can you|could you|"
    r"would you)\b", re.I)


def _norm(t: str) -> str:
    return re.sub(r"[^\w\s'?-]", "", t.lower()).strip()


def classify(text: str, min_words: int = 3) -> QuestionKind:
    t = _norm(text)
    if not t:
        return QuestionKind.FILLER
    words = t.replace("?", " ").split()
    bare = " ".join(words)
    if bare in _FILLER or all(w in _FILLER for w in words):
        return QuestionKind.FILLER
    if "?" in text and len(words) >= 2:
        return QuestionKind.QUESTION
    # any sentence starting like a question counts (interviewers preface a lot)
    for sent in re.split(r"(?<=[.!?])\s+|,\s+(?=so\b|and\b|now\b)", text.lower()):
        s = _norm(sent)
        s = re.sub(r"^(so|and|now|okay|ok|great|right|alright|cool|well|um|uh)[\s,]+", "", s)
        if s.startswith(_STARTERS) and len(s.split()) >= min_words - 1:
            return QuestionKind.QUESTION
    if _IMPERATIVE_ANYWHERE.search(text) and len(words) >= min_words:
        return QuestionKind.QUESTION
    if len(words) < min_words:
        return QuestionKind.FILLER
    return QuestionKind.STATEMENT


_BEHAVIOURAL = re.compile(r"\b(tell (me|us) about a time|describe a (time|situation)|give (me|us) an example|"
                          r"a time when|situation where|how did you (handle|deal)|ever had to|"
                          r"conflict|disagree|mistake|fail|challeng|difficult|proud|achievement)\w*", re.I)
_TECHNICAL = re.compile(r"\b(sql|python|query|join|index|window function|cte|dax|power bi|tableau|dashboard|"
                        r"model|pipeline|etl|schema|statistic|regression|p[- ]value|a/?b test|how would you (build|"
                        r"design|implement|approach|calculate|find|optimi[sz]e|write)|difference between|explain (how|what)|"
                        r"what is (a|an|the)|algorithm|data (quality|model)|api|docker|cloud|aws|azure)\b", re.I)
_MOTIVATION = re.compile(r"\b(why (do you|are you|this|us|our|would you)|what (attracts|interests|motivates)|"
                         r"where do you see|career|goals?|why should we)\b", re.I)


def question_topic(text: str) -> str:
    """Coarse topic used to pick a bridge phrase: behavioural | technical | motivation | general."""
    if _BEHAVIOURAL.search(text):
        return "behavioural"
    if _TECHNICAL.search(text):
        return "technical"
    if _MOTIVATION.search(text):
        return "motivation"
    return "general"
