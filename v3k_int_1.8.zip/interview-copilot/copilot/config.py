"""Configuration: YAML file + environment variables (+ optional .env)."""
from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any

import yaml

log = logging.getLogger(__name__)


@dataclass
class CandidateCfg:
    name: str = "the candidate"
    english_variant: str = "Australian"  # spelling / phrasing of generated answers
    answer_style: str = "confident, conversational, specific; STAR for behavioural questions"


@dataclass
class KnowledgeCfg:
    dir: str = "./knowledge"
    # Logical name → file name inside `dir`. Any of md / txt / pdf / docx.
    files: dict = field(default_factory=lambda: {
        "job_description": "jd.md",
        "resume": "resume.md",
        "cover_letter": "cover_letter.md",
        "my_analysis": "analysis.md",
        "profile": "profile.md",
        "cheatsheet": "cheatsheet.md",   # numbers/dates/names you might blank on (⌘⇧K); prepare.py generates one
    })
    qa_files: list = field(default_factory=lambda: ["qa.md", "qa.generated.md"])


@dataclass
class AudioCfg:
    device: str = "BlackHole"  # substring of the input device name
    mic_device: str = "default"  # used by --mic / launcher "Mic test": "default" = macOS input, or a name
    block_ms: int = 50
    target_rate: int = 16000
    record: bool = False       # save what the recogniser hears to sessions/<session>.wav (for evaluation)


@dataclass
class DeepgramCfg:
    model: str = "nova-3"
    language: str = "en"
    endpointing_ms: int = 400
    utterance_end_ms: int = 1000
    keyterms: list = field(default_factory=list)
    auto_keyterms_from_jd: bool = True


@dataclass
class LocalAsrCfg:
    model: str = "mlx-community/whisper-large-v3-turbo"
    silence_ms: int = 500
    max_segment_s: float = 25.0
    # Live subtitles from the local model: re-transcribe the utterance in progress every `interim_every_ms`.
    # Needed for the live prepared-answer match (card on screen before they finish). Self-throttling:
    # interim passes stop whenever one inference takes longer than `interim_max_infer_s`, so a slower Mac
    # never delays the final transcript.
    interim: bool = True
    interim_every_ms: int = 700
    interim_min_s: float = 1.0
    interim_max_infer_s: float = 0.6


@dataclass
class OpenAIRealtimeAsrCfg:
    """LLM-based streaming ASR (OpenAI Realtime API, transcription session — NOT the GPT-Live agent API)."""
    url: str = "wss://api.openai.com/v1/realtime?intent=transcription"
    # OpenAI's docs don't spell out the transcription-session URL; these are tried in order on connect errors.
    fallback_urls: list = field(default_factory=lambda: [
        "wss://api.openai.com/v1/realtime?model=gpt-live-transcribe",
        "wss://api.openai.com/v1/realtime",
    ])
    model: str = "gpt-live-transcribe"
    delay: str = "minimal"        # minimal | low | medium | high | xhigh (accuracy ↔ latency)
    language: str = "en"
    prompt: str = "A live job interview conducted in English over a video call."
    silence_ms: int = 500         # client-side VAD: pause length that commits a turn
    final_wait_ms: int = 600      # after commit, wait this long for the final text, else use the streamed text
    api_key_env: str = "OPENAI_API_KEY"


@dataclass
class SegmentAsrCfg:
    """LLM-based ASR per speech segment, any OpenAI-compatible /audio/transcriptions endpoint
    (OpenAI gpt-transcribe, Groq whisper-large-v3-turbo, a local server …)."""
    base_url: str = "https://api.openai.com/v1"
    model: str = "gpt-transcribe"
    api_key_env: str = "OPENAI_API_KEY"
    language: str = "en"
    prompt: str = "A live job interview conducted in English over a video call."
    silence_ms: int = 500
    max_segment_s: float = 25.0


@dataclass
class AsrCfg:
    provider: str = "deepgram"  # deepgram | openai_realtime | llm_segment | local
    deepgram: DeepgramCfg = field(default_factory=DeepgramCfg)
    openai_realtime: OpenAIRealtimeAsrCfg = field(default_factory=OpenAIRealtimeAsrCfg)
    llm_segment: SegmentAsrCfg = field(default_factory=SegmentAsrCfg)
    local: LocalAsrCfg = field(default_factory=LocalAsrCfg)


@dataclass
class OpenAICfg:
    model: str = "gpt-4o-mini"
    base_url: str | None = None


@dataclass
class LlmCfg:
    provider: str = "anthropic"  # anthropic | openai | mock
    model: str = "claude-haiku-4-5-20251001"
    max_tokens: int = 450
    temperature: float = 0.3      # ignored by models/SDKs that no longer accept it (e.g. Sonnet 5)
    # Sonnet 5 / Opus 5 think by default, which costs ~1-3 s before the first word.
    # disabled → send thinking:{type:disabled}; adaptive → let it think (use effort: low);
    # default → send nothing (model default).
    thinking: str = "disabled"
    effort: str = ""              # low | medium | high — only meaningful when thinking is on
    say_words: str = "70-120"     # length of the SAY paragraph (shorter = finishes sooner)
    # 思路 FLOW: the answer's line of thought in Chinese + the English words for each step, streamed right after
    # KEY, so you can answer in your own words instead of reading SAY aloud. Adds ~0.3 s before points/SAY.
    # spoken: plain = simple, conversational English that is easy to say (short sentences, everyday words);
    #         polished = the older, more formal written style
    spoken: str = "plain"
    impact: bool = True           # work answers: problem → what I did (with what) → effect on the whole system
    flow: bool = True
    flow_steps: str = "3-4"
    flow_tokens: int = 180        # extra output budget on top of max_tokens when flow is on
    flow_for_prepared: bool = True  # prepared answers without a FLOW get one written once (cached) when they lock
    # Hybrid mode: a second, stronger model answers in parallel and appears as its own layer.
    deep_model: str = ""          # e.g. claude-sonnet-5-5 ; empty = off
    deep_thinking: str = "disabled"
    deep_effort: str = ""
    deep_say_words: str = "90-140"
    deep_max_tokens: int = 700
    prepare_model: str = "claude-sonnet-5-5"
    keep_models: bool = False     # true = don't move old default model ids (claude-sonnet-5) to the current one
    warmup: bool = True
    openai: OpenAICfg = field(default_factory=OpenAICfg)


@dataclass
class EngineCfg:
    merge_window_s: float = 3.0       # follow-on speech within this window extends the question
    min_question_words: int = 3
    statement_trigger_words: int = 22  # also answer long non-question statements (missed question = worse than a spare card)
    recent_context_s: float = 90.0
    history_turns: int = 3
    instant_match_threshold: float = 0.50  # show the PREPARED hint card
    instant_lock_threshold: float = 0.72   # prepared answer fills the main layers instantly; model → ALT block
    live_match_on_interim: bool = True     # match while they are still speaking (provisional card)
    prepared_budget_s: float = 1.5         # requirement: prepared answer on screen within this after speech end
    # said aloud while the answer loads — buys 2-3 s and sounds natural. Picked by question kind.
    bridge_phrases: dict = field(default_factory=lambda: {
        "behavioural": ["Sure — let me think of a specific example.",
                        "Good question. The example that comes to mind is from my current role."],
        "technical": ["Sure. Let me walk through how I'd approach that.",
                      "Okay — let me break that down step by step."],
        "motivation": ["Yes — a couple of things drew me to this."],
        "general": ["That's a good question — let me think about that for a second.",
                    "Sure, happy to talk about that."],
        "clarify": ["Sorry, could you say that again? The audio cut out for a second.",
                    "Just to make sure I answer the right thing — do you mean … ?"],
    })


@dataclass
class UiCfg:
    theme: str = "auto"              # auto (follow macOS) | sumi (dark ink) | washi (light paper)
    width: int = 520
    height: int = 640
    opacity: float = 0.97
    font_scale: float = 1.0
    position: str = "top-right"  # top-right | top-left | bottom-right | bottom-left
    show_zh: bool = True
    show_say: bool = True
    show_flow: bool = True           # 思路 under KEY (⌘⇧Y). Tip: with 思路 on, hide SAY (⌘⇧S) to speak freely
    focus_font_scale: float = 1.35   # ⌘⇧F focus mode: only KEY + SAY, bigger
    focus_default: bool = False      # start in focus mode (least clutter)


@dataclass
class HotkeysCfg:
    enabled: bool = True
    force_answer: str = "<cmd>+<shift>+<space>"
    toggle_visible: str = "<cmd>+<shift>+h"
    toggle_say: str = "<cmd>+<shift>+s"
    toggle_flow: str = "<cmd>+<shift>+y"   # 思路: Chinese line of thought under KEY
    prev: str = "<cmd>+<shift>+<left>"
    next: str = "<cmd>+<shift>+<right>"
    click_through: str = "<cmd>+<shift>+t"
    pause: str = "<cmd>+<shift>+p"
    focus: str = "<cmd>+<shift>+f"       # teleprompter: KEY + SAY only, large
    facts: str = "<cmd>+<shift>+k"       # cheat sheet (cheatsheet.md / profile.md)
    clarify: str = "<cmd>+<shift>+r"     # show a 'could you repeat that' line and re-listen


@dataclass
class LoggingCfg:
    dir: str = "./sessions"


@dataclass
class Config:
    candidate: CandidateCfg = field(default_factory=CandidateCfg)
    knowledge: KnowledgeCfg = field(default_factory=KnowledgeCfg)
    audio: AudioCfg = field(default_factory=AudioCfg)
    asr: AsrCfg = field(default_factory=AsrCfg)
    llm: LlmCfg = field(default_factory=LlmCfg)
    engine: EngineCfg = field(default_factory=EngineCfg)
    ui: UiCfg = field(default_factory=UiCfg)
    hotkeys: HotkeysCfg = field(default_factory=HotkeysCfg)
    logging: LoggingCfg = field(default_factory=LoggingCfg)
    base_dir: str = "."

    def path(self, p: str) -> Path:
        pp = Path(p).expanduser()
        return pp if pp.is_absolute() else (Path(self.base_dir) / pp).resolve()


def _merge(dc: Any, data: dict) -> Any:
    """Recursively apply a dict onto a dataclass instance (unknown keys are ignored)."""
    if not isinstance(data, dict):
        return dc
    for f in fields(dc):
        if f.name not in data:
            continue
        cur = getattr(dc, f.name)
        val = data[f.name]
        if is_dataclass(cur):
            _merge(cur, val)
        elif isinstance(cur, dict) and isinstance(val, dict):
            cur.update(val)
        else:
            setattr(dc, f.name, val)
    return dc


def parse_env_value(raw: str) -> str:
    """Standard .env value rules: quoted values keep everything inside the quotes; unquoted values end at
    an inline comment (whitespace followed by '#'). `KEY=abc   # note` → 'abc'."""
    v = raw.strip()
    if v[:1] in ("'", '"'):
        q = v[0]
        end = v.find(q, 1)
        return v[1:end] if end != -1 else v[1:]
    m = re.search(r"\s#", v)
    return (v[:m.start()] if m else v).strip()


def read_dotenv(path: Path) -> dict[str, str]:
    """Parse a .env file. Duplicate keys: the LAST one wins (same as python-dotenv)."""
    out: dict[str, str] = {}
    if not path.exists():
        return out
    for line in path.read_text(encoding="utf-8-sig").splitlines():  # -sig drops a UTF-8 BOM
        line = line.strip()
        if line.startswith("export "):
            line = line[7:].strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = parse_env_value(v)
    return out


def load_dotenv(path: Path) -> None:
    """Values already set in the shell environment are NOT overridden."""
    for k, v in read_dotenv(path).items():
        os.environ.setdefault(k, v)


EXAMPLE_DIR = Path(__file__).resolve().parents[1] / "knowledge.example"


def load_config(path: str | None) -> Config:
    cfg = Config()
    if path:
        p = Path(path).expanduser().resolve()
        with open(p, encoding="utf-8") as fh:
            _merge(cfg, yaml.safe_load(fh) or {})
        cfg.base_dir = str(p.parent)
    load_dotenv(Path(cfg.base_dir) / ".env")
    from .oscompat import adapt_config
    adapt_config(cfg)
    upgrade_models(cfg)
    return cfg


# Model ids that earlier versions wrote into config.yaml as *defaults*. They still work; we move them to the
# current default so an old config doesn't pin you to it. Set `llm.keep_models: true` to keep yours as written.
MODEL_UPGRADES = {"claude-sonnet-5": "claude-sonnet-5-5"}


def upgrade_models(cfg: Config) -> list[str]:
    if getattr(cfg.llm, "keep_models", False):
        return []
    changed = []
    for name in ("model", "deep_model", "prepare_model"):
        old = getattr(cfg.llm, name, "")
        if old in MODEL_UPGRADES:
            setattr(cfg.llm, name, MODEL_UPGRADES[old])
            changed.append(f"llm.{name}: {old} → {MODEL_UPGRADES[old]}")
    for c in changed:
        log.info("config: %s", c)
    return changed
