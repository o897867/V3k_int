"""Thread-safe bridge: the asyncio engine thread emits Qt signals; Qt queues them onto the UI thread."""
from __future__ import annotations

from PyQt6.QtCore import QObject, pyqtSignal


class QtSink(QObject):
    transcript = pyqtSignal(str, str)
    question = pyqtSignal(object)
    prepared = pyqtSignal(int, object, bool)
    layer = pyqtSignal(int, str, str)
    done = pyqtSignal(int, object)
    status = pyqtSignal(str)
    error = pyqtSignal(str)
    warning = pyqtSignal(str)
    hotkey = pyqtSignal(str)

    # --- Sink protocol (called from the engine thread) ---
    def on_transcript(self, final_text, interim):
        self.transcript.emit(final_text, interim)

    def on_question(self, q):
        self.question.emit(q)

    def on_prepared(self, qid, match, live):
        self.prepared.emit(qid, match, live)

    def on_layer(self, qid, layer, text):
        self.layer.emit(qid, layer, text)

    def on_done(self, qid, metrics):
        self.done.emit(qid, metrics)

    def on_status(self, text):
        self.status.emit(text)

    def on_error(self, text):
        self.error.emit(text)

    def on_warning(self, text):
        self.warning.emit(text)
