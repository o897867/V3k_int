"""Visual language: 侘寂 (wabi-sabi) — natural pigments, paper, ink, quiet hierarchy.

Two palettes, both drawn from traditional Japanese colours:

  墨 SUMI   dark  — warm charcoal ink, unbleached-silk text. Default over a video call: it recedes.
  和紙 WASHI light — warm paper, ink text. For bright rooms / light-mode meetings.

Accents are used for meaning only, never decoration:
  黄土 ōdo ochre      the KEY line — what to say first
  苔 koke moss        your own prepared answer / listening
  藍 ai indigo        中文 gist, help
  柿 kaki persimmon   "say this now" (bridge, clarify)
  弁柄 bengara red    problems
  錆浅葱 / 藤鼠        the model's alternative / the deep model

Type: serif (Iowan Old Style / Songti on a Mac, Sitka on Windows) for words you SAY — the KEY line and the spoken
answer read like a book page; sans (SF / PingFang, Segoe UI / YaHei) for everything you SCAN. Contrast of every text colour against its background is
unit-tested (≥ 4.5:1 for body text, ≥ 3:1 for secondary labels).
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import QColor, QFont, QImage, QPainter, QPainterPath, QPen, QPixmap

# One stack per platform. Qt picks per glyph down the list, so Latin comes first and CJK after it.
#
#   role    macOS                                 Windows (all ship with Windows 10/11)
#   sans    SF Pro · PingFang SC                  Segoe UI Variable · Microsoft YaHei UI
#   serif   Iowan Old Style · Songti SC           Sitka (Matthew Carter's screen-reading serif) · Noto Serif SC
#                                                 if installed, else YaHei — SimSun's bitmap strikes look broken
#                                                 at 14–16 px
#   kai     Iowan · Kaiti SC                      Sitka · KaiTi 楷体
#   mono    SF Mono · Menlo                       Cascadia Mono · Consolas
SANS_MAC = ["SF Pro Text", ".AppleSystemUIFont", "Helvetica Neue", "PingFang SC", "Hiragino Sans"]
SERIF_MAC = ["Iowan Old Style", "Songti SC", "STSong", "Hiragino Mincho ProN"]
KAI_MAC = ["Iowan Old Style", "Kaiti SC", "STKaiti", "Kaiti TC", "BiauKai", "Songti SC"]
MONO_MAC = ["SF Mono", "Menlo"]

SANS_WIN = ["Segoe UI Variable Text", "Segoe UI", "Microsoft YaHei UI", "Microsoft YaHei"]
SERIF_WIN = ["Sitka Text", "Sitka", "Georgia", "Cambria", "Noto Serif SC", "Source Han Serif SC",
             "Microsoft YaHei UI", "Microsoft YaHei"]
KAI_WIN = ["Sitka Text", "Sitka", "Georgia", "KaiTi", "STKaiti", "Microsoft YaHei UI"]
MONO_WIN = ["Cascadia Mono", "Consolas"]

# Linux / anything else (CI, screenshots)
SANS_ANY = ["Noto Sans CJK SC", "DejaVu Sans"]
SERIF_ANY = ["Lora", "Noto Serif CJK SC", "DejaVu Serif"]
MONO_ANY = ["DejaVu Sans Mono"]

# Optical sizes on Windows: the variable fonts carry separate cuts for small, text and display sizes.
_WIN_OPTICAL = {
    "sans": [(11.5, "Segoe UI Variable Small"), (19.5, "Segoe UI Variable Text"), (999, "Segoe UI Variable Display")],
    "serif": [(11.5, "Sitka Small"), (19.5, "Sitka Text"), (27.5, "Sitka Subheading"), (999, "Sitka Heading")],
    "kai": [(11.5, "Sitka Small"), (19.5, "Sitka Text"), (999, "Sitka Subheading")],
}


def _is_win(win: bool | None) -> bool:
    import sys
    return sys.platform == "win32" if win is None else win


def stacks(win: bool | None = None) -> dict[str, list[str]]:
    """Font families per role for this platform (mac stacks elsewhere, since they fall through harmlessly)."""
    if _is_win(win):
        return {"sans": SANS_WIN + SANS_ANY, "serif": SERIF_WIN + SERIF_ANY, "kai": KAI_WIN + SERIF_ANY,
                "mono": MONO_WIN + MONO_ANY}
    return {"sans": SANS_MAC + SANS_WIN + SANS_ANY, "serif": SERIF_MAC + ["Georgia", "Cambria"] + SERIF_ANY,
            "kai": KAI_MAC + SERIF_ANY, "mono": MONO_MAC + MONO_WIN + MONO_ANY}


def families(role: str, px: float = 14, win: bool | None = None) -> list[str]:
    fams = list(stacks(win).get(role, stacks(win)["sans"]))
    if _is_win(win) and role in _WIN_OPTICAL:
        cut = next(name for limit, name in _WIN_OPTICAL[role] if px <= limit)
        fams = [cut] + [f for f in fams if f != cut]
    return fams


def css_family(role: str, px: float = 14, win: bool | None = None) -> str:
    """The same stack for rich-text spans: font-family:"Sitka Text", Georgia, …"""
    return ", ".join(f'"{f}"' for f in families(role, px, win))


# kept for anything importing the old names
SANS, SERIF, KAI, MONO = (stacks()[r] for r in ("sans", "serif", "kai", "mono"))


@dataclass(frozen=True)
class Theme:
    name: str
    dark: bool
    bg: str          # window
    surface: str     # quiet panels (hint card, facts, help)
    hair: str        # hairlines, borders
    text: str        # body
    strong: str      # question / KEY — the brightest ink
    muted: str       # secondary labels (≥ 4.5:1)
    faint: str       # decoration only: footer hints, placeholder (≥ 3:1)
    say: str         # the spoken answer: a touch softer than body, for long reading
    stale: str       # text waiting to be replaced (merged follow-up)
    accent: str      # 黄土 KEY mark
    prep: str        # 苔 your prepared answer, listening
    zh: str          # 藍 Chinese gist
    bridge: str      # 柿 say-now
    err: str         # 弁柄
    alt: str         # 錆浅葱 model version
    deep: str        # 藤鼠 deep model
    bg_alpha: int = 244
    grain: int = 7   # paper-texture strength (alpha of the grain dots)

    def rgba(self, color: str, a: float) -> str:
        c = QColor(color)
        return f"rgba({c.red()},{c.green()},{c.blue()},{a:.2f})"

    def qcolor(self, color: str, alpha: int | None = None) -> QColor:
        c = QColor(color)
        if alpha is not None:
            c.setAlpha(alpha)
        return c


SUMI = Theme(
    name="sumi", dark=True,
    bg="#1c1b19", surface="#262420", hair="#3a3631",
    text="#e6e0d3", strong="#f4efe4", muted="#a39c8f", faint="#7d766b", say="#d8d1c3", stale="#6a645b",
    accent="#cda35e", prep="#9eae76", zh="#94adbb", bridge="#d9a071", err="#d4735a",
    alt="#9fb4aa", deep="#b0a3c0",
)

WASHI = Theme(
    name="washi", dark=False,
    bg="#f3efe5", surface="#e9e3d6", hair="#d8d0c0",
    text="#2e2b27", strong="#1b1917", muted="#6b655b", faint="#857e71", say="#3a3631", stale="#9a9282",
    accent="#7f5d20", prep="#566a36", zh="#35596e", bridge="#9a4f25", err="#a3381f",
    alt="#46645a", deep="#645684", bg_alpha=247, grain=9,
)

THEMES = {"sumi": SUMI, "washi": WASHI}
LABELS = {"auto": "Follow Windows" if _is_win(None) else "Follow macOS", "sumi": "墨 Sumi — dark", "washi": "和紙 Washi — light"}


def system_is_dark() -> bool:
    try:
        from PyQt6.QtGui import QGuiApplication
        app = QGuiApplication.instance()
        if app is None:
            return True
        scheme = app.styleHints().colorScheme()
        if scheme == Qt.ColorScheme.Dark:
            return True
        if scheme == Qt.ColorScheme.Light:
            return False
        return app.palette().window().color().lightness() < 128
    except Exception:
        return True


def resolve(name: str | None) -> Theme:
    """'sumi' | 'washi' | 'auto' (follow macOS appearance) → Theme."""
    if name in THEMES:
        return THEMES[name]
    return SUMI if system_is_dark() else WASHI


def font(px: int, *, serif: bool = False, mono: bool = False, weight: int = 400, italic: bool = False,
         role: str = "") -> QFont:
    """role: sans (scan) · serif (say — Iowan + Songti) · kai (Chinese annotation) · mono (code)."""
    role = role or ("mono" if mono else "serif" if serif else "sans")
    f = QFont()
    f.setFamilies(families(role, px))
    f.setPixelSize(max(8, int(px)))
    f.setWeight(QFont.Weight(weight))
    f.setItalic(italic)
    # macOS ignores hinting; on Windows vertical-only hinting keeps baselines crisp at 100 % scaling while
    # letting DirectWrite keep the shapes (full hinting would fall back to GDI and distort the serif).
    f.setHintingPreference(QFont.HintingPreference.PreferVerticalHinting if _is_win(None)
                           else QFont.HintingPreference.PreferNoHinting)
    return f


# ---------------------------------------------------------------- materials

_GRAIN: dict[tuple, QPixmap] = {}


def paper_grain(t: Theme, size: int = 160) -> QPixmap:
    """A tile of faint fibres + specks, like handmade paper. Generated once per theme."""
    k = (t.name, size)
    if k in _GRAIN:
        return _GRAIN[k]
    img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    rnd = random.Random(7)
    ink = QColor(255, 255, 255) if t.dark else QColor(60, 45, 25)
    for _ in range(size * size // 9):                     # specks
        c = QColor(ink)
        c.setAlpha(rnd.randint(1, t.grain))
        p.setPen(c)
        p.drawPoint(rnd.randrange(size), rnd.randrange(size))
    for _ in range(size // 5):                            # a few long, soft fibres
        c = QColor(ink)
        c.setAlpha(max(1, t.grain // 2))
        p.setPen(QPen(c, 0.6))
        x, y = rnd.uniform(0, size), rnd.uniform(0, size)
        path = QPainterPath(QPointF(x, y))
        for _ in range(3):
            x += rnd.uniform(-14, 14)
            y += rnd.uniform(-14, 14)
            path.lineTo(QPointF(x, y))
        p.drawPath(path)
    p.end()
    _GRAIN[k] = QPixmap.fromImage(img)
    return _GRAIN[k]


def ink_stroke(p: QPainter, x: float, top: float, bottom: float, color: QColor, seed: int = 0,
               width: float = 3.0) -> None:
    """A vertical brush stroke (see art.brush)."""
    from . import art
    art.brush(p, QPointF(x, top), QPointF(x + 0.6, bottom), width, color, seed, bow=0.4)


def enso(p: QPainter, rect: QRectF, color: QColor, level: float = 0.0, angle: float = 0.0,
         hollow: bool = False) -> None:
    """円相 (see art.enso)."""
    from . import art
    art.enso(p, rect, color, sweep=1.0, level=level, hollow=hollow, rotation=angle)


def contrast(fg: str, bg: str) -> float:
    """WCAG contrast ratio."""
    def lum(h: str) -> float:
        c = QColor(h)
        vals = []
        for v in (c.redF(), c.greenF(), c.blueF()):
            vals.append(v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4)
        return 0.2126 * vals[0] + 0.7152 * vals[1] + 0.0722 * vals[2]
    a, b = lum(fg), lum(bg)
    hi, lo = max(a, b), min(a, b)
    return (hi + 0.05) / (lo + 0.05)
