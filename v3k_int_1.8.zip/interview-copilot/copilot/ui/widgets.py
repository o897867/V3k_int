"""Hand-made controls for the launcher: brush-underlined tabs, dotted leaders, the vermilion seal button, and the
page that carries the ink-wash header. They paint themselves from the current theme (theme.py) with the materials in
art.py, and stay ordinary Qt widgets underneath (keyboard focus, QButtonGroup, accessibility names)."""
from __future__ import annotations

from PyQt6.QtCore import QPointF, QRectF, QSize, Qt
from PyQt6.QtGui import QColor, QFontMetrics, QPainter, QPainterPath, QPen
from PyQt6.QtWidgets import QLabel, QPushButton, QWidget

from . import art
from . import theme as TH


class InkTab(QPushButton):
    """A choice written as a word; the chosen one is underlined with a single brush stroke."""

    def __init__(self, text: str, theme_ref, small: bool = False, parent=None):
        super().__init__(text, parent)
        self.T_ref = theme_ref            # callable → current Theme
        self.small = small
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFlat(True)
        self.setAttribute(Qt.WidgetAttribute.WA_Hover)
        self.setFont(TH.font(12 if small else 13.5))
        self.setAccessibleName(text)

    def sizeHint(self) -> QSize:
        f = TH.font(12 if self.small else 13.5, weight=600)
        w = QFontMetrics(f).horizontalAdvance(self.text())
        return QSize(w + (18 if self.small else 26), 26 if self.small else 34)

    def minimumSizeHint(self) -> QSize:
        return self.sizeHint()

    def paintEvent(self, _):
        T = self.T_ref()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        on, hov, en = self.isChecked(), self.underMouse(), self.isEnabled()
        f = TH.font(12 if self.small else 13.5, weight=600 if on else 400)
        p.setFont(f)
        fm = p.fontMetrics()
        tw = fm.horizontalAdvance(self.text())
        x = (self.width() - tw) / 2
        base = self.height() / 2 + fm.ascent() / 2 - 3
        col = QColor(T.strong if on else (T.text if hov else T.muted))
        if not en:
            col = QColor(T.faint)
        p.setPen(col)
        p.drawText(QPointF(x, base), self.text())
        y = base + (5 if self.small else 7)
        if on:
            px = art.brush_pixmap(int(tw + 10), 8, QColor(T.accent), hash(self.text()) % 97, self.devicePixelRatioF(),
                                  vertical=False, width=2.6 if self.small else 3.2, dry=0.7)
            p.drawPixmap(QPointF(x - 4, y - 4), px)
        elif hov and en:
            p.setPen(QPen(QColor(T.hair), 1))
            p.drawLine(QPointF(x, y), QPointF(x + tw, y))
        if self.hasFocus() and not on:
            p.setPen(QPen(QColor(T.accent), 1, Qt.PenStyle.DotLine))
            p.drawLine(QPointF(x, y), QPointF(x + tw, y))
        p.end()


class LeaderLabel(QLabel):
    """A row name followed by a dotted leader running to the edge of its column — like a table of contents."""

    def __init__(self, text: str, theme_ref, parent=None):
        super().__init__(text, parent)
        self.T_ref = theme_ref

    def paintEvent(self, e):
        super().paintEvent(e)
        T = self.T_ref()
        p = QPainter(self)
        fm = self.fontMetrics()
        x0 = fm.horizontalAdvance(self.text()) + 8
        y = fm.ascent() + 1
        c = QColor(T.faint)
        c.setAlphaF(0.55)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(c)
        x = x0
        while x < self.width() - 6:
            p.drawEllipse(QPointF(x, y), 0.65, 0.65)
            x += 4.5
        p.end()


class SealButton(QPushButton):
    """The one vermilion thing on the page: the primary action, printed like a seal. Disabled, it is only an
    outline — the seal hasn't been pressed yet."""

    def __init__(self, text: str, theme_ref, parent=None):
        super().__init__(text, parent)
        self.T_ref = theme_ref
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_Hover)
        self.setMinimumSize(128, 42)
        self.setFont(TH.font(14, role="serif", weight=600))
        self.setAccessibleName(text)

    def sizeHint(self) -> QSize:
        return QSize(136, 44)

    def paintEvent(self, _):
        T = self.T_ref()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(2, 2, self.width() - 4, self.height() - 4)
        down = self.isDown()
        if self.isEnabled():
            shu = QColor(art.SHU[T.name])
            if self.underMouse() and not down:
                shu = shu.lighter(108)
            if down:
                shu = shu.darker(112)
                r.translate(0, 1)
            seal = art.seal_pixmap("", int(r.width()), int(r.height()), shu, seed=21, dpr=self.devicePixelRatioF(),
                                   wear=0.3)
            p.drawPixmap(r.topLeft(), seal)
            p.setPen(QColor("#fbf5ea"))
        else:
            path = QPainterPath()
            path.addRoundedRect(r.adjusted(0.5, 0.5, -0.5, -0.5), 5, 5)
            p.setPen(QPen(QColor(T.hair), 1, Qt.PenStyle.DashLine))
            p.drawPath(path)
            p.setPen(QColor(T.faint))
        f = self.font()
        f.setLetterSpacing(f.SpacingType.AbsoluteSpacing, 1.5)
        p.setFont(f)
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, self.text())
        if self.hasFocus():
            p.setPen(QPen(QColor(T.accent), 1, Qt.PenStyle.DotLine))
            p.drawRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 6, 6)
        p.end()


class InkPage(QWidget):
    """The scrolling page: carries the ink-wash mountains behind the title, so they scroll away with it."""

    def __init__(self, theme_ref, header_h: int = 210, parent=None):
        super().__init__(parent)
        self.T_ref = theme_ref
        self.header_h = header_h
        self._cache = None

    def paintEvent(self, _):
        T = self.T_ref()
        w, h = self.width(), self.header_h
        key = (w, h, T.name, round(self.devicePixelRatioF(), 2))
        if self._cache is None or self._cache[0] != key:
            from PyQt6.QtGui import QImage, QPixmap
            dpr = self.devicePixelRatioF()
            img = QImage(int(w * dpr), int(h * dpr), QImage.Format.Format_ARGB32_Premultiplied)
            img.fill(Qt.GlobalColor.transparent)
            img.setDevicePixelRatio(dpr)
            q = QPainter(img)
            art.mountains(q, QRectF(0, 0, w, h), QColor(T.strong), T.dark, seed=8)
            q.end()
            self._cache = (key, QPixmap.fromImage(img))
        p = QPainter(self)
        p.drawPixmap(0, 0, self._cache[1])
        p.end()
