"""Remembered overlay/launcher state (window geometry, zoom, collapsed sections, launcher choices).

Stored as JSON under <project>/.state/ — outside the code folders, so upgrades never touch it."""
from __future__ import annotations

import json
import logging
from pathlib import Path

log = logging.getLogger(__name__)


class JsonState:
    def __init__(self, path: Path | None, defaults: dict | None = None):
        self.path = path
        self.data: dict = dict(defaults or {})
        if path and path.exists():
            try:
                self.data.update(json.loads(path.read_text(encoding="utf-8")))
            except Exception as e:  # a corrupt state file must never stop the app
                log.warning("ignoring unreadable state file %s: %s", path, e)

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value) -> None:
        self.data[key] = value

    def save(self) -> None:
        if not self.path:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self.path)
        except Exception as e:
            log.warning("could not save state %s: %s", self.path, e)
