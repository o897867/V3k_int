"""Hand-made materials, painted in code: brush, 円相 ensō, 印 seal, 和紙 paper, 山水 ink-wash mountains, app icon.

Everything is deterministic (seeded), so a stroke never shimmers when a label repaints, and cached as pixmaps where
it is drawn often. Nothing here is decoration for its own sake — each mark carries one meaning:

  brush stroke   "say this first" (KEY) · the chosen option (launcher tabs)
  ensō           the copilot's state — breathes while listening, draws itself while writing
  vermilion seal "this is YOUR answer" (a prepared answer locked in) · the app's signature · Start
  paper / ink    the ground everything sits on — warm, slightly uneven, never flat grey
"""
from __future__ import annotations

import math
import random

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import (QBrush, QColor, QFont, QImage, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap,
                         QRadialGradient)

SHU = {"sumi": "#be4630", "washi": "#b7402a"}          # 朱 vermilion — seal ink (label on it ≥ 4.5:1)
# Seal characters are drawn as outlines (never bitmap strikes), so SimSun is fine here on Windows; the heavier
# Office Song faces carve better when present.
SEAL_FONT = ["Songti SC", "STSong", "Hiragino Mincho ProN", "Noto Serif CJK SC", "Noto Serif CJK JP",
             "Source Han Serif SC", "STZhongsong", "SimSun", "NSimSun"]


def _col(c, a: float | None = None) -> QColor:
    q = QColor(c)
    if a is not None:
        q.setAlphaF(max(0.0, min(1.0, a)))
    return q


def _smooth_noise(n: int, rnd: random.Random, octaves: int = 4) -> list[float]:
    """1-D value noise in [-1, 1], n samples, a few octaves (for ridgelines and wobble)."""
    out = [0.0] * n
    amp, total = 1.0, 0.0
    for o in range(octaves):
        k = 3 * (2 ** o) + 1
        pts = [rnd.uniform(-1, 1) for _ in range(k + 1)]
        for i in range(n):
            x = i / max(1, n - 1) * k
            j = int(x)
            f = x - j
            f = f * f * (3 - 2 * f)
            out[i] += amp * (pts[j] * (1 - f) + pts[min(j + 1, k)] * f)
        total += amp
        amp *= 0.5
    return [v / total for v in out]


# ============================================================================ brush

def brush(p: QPainter, a: QPointF, b: QPointF, width: float, color: QColor, seed: int = 0,
          dry: float = 0.55, bow: float = 0.0) -> None:
    """One calligraphic stroke from a to b: the brush lands (a slightly swollen head), travels, and runs dry —
    the body tapers and splits into bristle streaks (掠れ kasure) near the end."""
    dx, dy = b.x() - a.x(), b.y() - a.y()
    length = math.hypot(dx, dy)
    if length < 3:
        return
    ux, uy = dx / length, dy / length
    nx, ny = -uy, ux
    rnd = random.Random(seed)
    wob = _smooth_noise(24, rnd, 2)
    n = 24

    def at(t: float, off: float) -> QPointF:
        i = min(n - 1, int(t * (n - 1)))
        lateral = off + bow * math.sin(math.pi * t) * length * 0.04 + wob[i] * width * 0.12
        return QPointF(a.x() + ux * length * t + nx * lateral, a.y() + uy * length * t + ny * lateral)

    def w_at(t: float) -> float:
        head = 1.0 + 0.22 * math.exp(-((t - 0.06) / 0.07) ** 2)      # the press where the brush lands
        return width * head * (1.0 - 0.62 * t ** 1.6)

    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    # body (fades as the ink runs out)
    body_end = 1.0 - 0.35 * dry
    left = [at(t, -w_at(t) / 2) for t in (i / n * body_end for i in range(n + 1))]
    right = [at(t, w_at(t) / 2) for t in (i / n * body_end for i in range(n + 1))]
    path = QPainterPath(left[0])
    for pt in left[1:]:
        path.lineTo(pt)
    for pt in reversed(right):
        path.lineTo(pt)
    path.closeSubpath()
    g = QLinearGradient(a, at(body_end, 0))
    g.setColorAt(0.0, _col(color, color.alphaF()))
    g.setColorAt(0.7, _col(color, color.alphaF() * 0.9))
    g.setColorAt(1.0, _col(color, color.alphaF() * 0.35))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(g))
    p.drawPath(path)
    # bristles: thin streaks that outlast the body and break up where the brush is dry
    k = 7
    for j in range(k):
        off = (j / (k - 1) - 0.5) * 0.8
        end = 1.0 - rnd.uniform(0.0, 0.25) * dry
        start = body_end * rnd.uniform(0.45, 0.8)
        steps = 16
        pen_w = max(0.35, width * rnd.uniform(0.09, 0.16))
        prev = None
        for s in range(steps + 1):
            t = start + (end - start) * s / steps
            pt = at(t, off * w_at(min(t, body_end)) * (1.0 + 0.5 * (t - start)))
            skip = t > 0.7 and rnd.random() < dry * 0.35
            if prev is not None and not skip:
                alpha = color.alphaF() * (0.75 - 0.6 * (t - start) / max(1e-3, end - start)) * rnd.uniform(0.6, 1)
                p.setPen(QPen(_col(color, alpha), pen_w, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                p.drawLine(prev, pt)
            prev = None if skip else pt
    p.restore()


def brush_pixmap(w: int, h: int, color: QColor, seed: int, dpr: float = 2.0, vertical: bool = True,
                 width: float = 3.4, dry: float = 0.55) -> QPixmap:
    """Cached stroke as a pixmap (a KEY mark repaints many times while an answer streams)."""
    key = (w, h, color.rgba(), seed, round(dpr, 2), vertical, width, dry)
    px = _BRUSH_CACHE.get(key)
    if px is not None:
        return px
    img = QImage(int(w * dpr), int(h * dpr), QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    img.setDevicePixelRatio(dpr)
    p = QPainter(img)
    if vertical:
        brush(p, QPointF(w / 2, 1.5), QPointF(w / 2 + 0.6, h - 1), width, color, seed, dry, bow=0.4)
    else:
        brush(p, QPointF(1.5, h / 2), QPointF(w - 1, h / 2 + 0.3), width, color, seed, dry, bow=-0.5)
    p.end()
    px = QPixmap.fromImage(img)
    if len(_BRUSH_CACHE) > 400:
        _BRUSH_CACHE.clear()
    _BRUSH_CACHE[key] = px
    return px


_BRUSH_CACHE: dict = {}


# ============================================================================ ensō

def enso(p: QPainter, rect: QRectF, color: QColor, sweep: float = 1.0, level: float = 0.0, hollow: bool = False,
         seed: int = 3, weight: float = 1.0, rotation: float = 0.0) -> None:
    """円相 — one breath, one stroke. Starts heavy at about seven o'clock, travels clockwise over the top, thins and
    breaks into dry bristles before it closes. `sweep` 0..1 draws it progressively (the brush travelling);
    `level` swells a soft ink dot in the centre (the microphone; < 0 = none); `hollow` = paused."""
    size = min(rect.width(), rect.height())
    base_w = size * 0.092 * weight * (0.55 if hollow else 1.0)
    r = size / 2 - base_w * 0.75 - 0.8
    cx, cy = rect.center().x(), rect.center().y()
    rnd = random.Random(seed)
    total = 326.0                     # never closed
    a0 = 118.0 + rotation
    sw = max(0.0, min(1.0, sweep))
    wob = _smooth_noise(96, rnd, 3)
    squash = 1.0 + rnd.uniform(-0.05, 0.05)
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    def pt(t: float, dr: float) -> QPointF:
        i = min(95, int(t * 95))
        rr = r * (1.0 + wob[i] * 0.05) + dr
        ang = math.radians(a0 + total * t)
        return QPointF(cx + rr * math.cos(ang) * squash, cy + rr * math.sin(ang) / squash)

    def w_at(t: float) -> float:
        head = 1.0 + 0.6 * math.exp(-((t - 0.035) / 0.05) ** 2)      # the brush lands heavily
        body = 1.1 - 0.85 * t ** 1.5                                 # and runs out of ink
        return base_w * head * max(0.12, body) * (1.0 + 0.12 * wob[min(95, int(t * 95))])

    alpha = color.alphaF() * (0.5 if hollow else 1.0)
    big = size > 40
    target = p
    if big and sw > 0.005:
        # large ensō: paint on its own layer so dry-brush streaks can be carved out of the ink
        dpr = p.device().devicePixelRatioF() if p.device() else 1.0
        layer = QImage(int(rect.width() * dpr) + 2, int(rect.height() * dpr) + 2,
                       QImage.Format.Format_ARGB32_Premultiplied)
        layer.fill(Qt.GlobalColor.transparent)
        layer.setDevicePixelRatio(dpr)
        target = QPainter(layer)
        target.setRenderHint(QPainter.RenderHint.Antialiasing)
        target.translate(-rect.x(), -rect.y())
    if sw > 0.005:
        p_main = p
        p = target
        body_end = min(sw, 0.955)
        n = max(10, int(120 * body_end))
        ts = [i / n * body_end for i in range(n + 1)]
        outer = [pt(t, w_at(t) / 2) for t in ts]
        inner = [pt(t, -w_at(t) / 2) for t in ts]
        path = QPainterPath(outer[0])
        for q in outer[1:]:
            path.lineTo(q)
        for q in reversed(inner):
            path.lineTo(q)
        path.closeSubpath()
        # the brush lands round, not cut square (one filled shape, so translucent ink doesn't double up)
        h0 = w_at(0.0) * 0.5
        path.addEllipse(pt(0.0, 0.0), h0 * 1.02, h0 * 0.92)
        path.setFillRule(Qt.FillRule.WindingFill)
        path = path.simplified()
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_col(color, alpha))
        p.drawPath(path)
        if big:
            # dry streaks carved through the second half of the stroke
            p.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationOut)
            for j in range(7):
                off = (j / 6 - 0.5) * 0.8
                t0 = rnd.uniform(0.38, 0.62)
                prev = None
                for st in range(40):
                    t = t0 + (body_end - t0) * st / 39
                    q_ = pt(t, off * w_at(t))
                    if prev is not None and rnd.random() > 0.35:
                        a = 0.35 + 0.55 * (t - t0) / max(1e-3, body_end - t0)
                        p.setPen(QPen(QColor(0, 0, 0, int(255 * a * rnd.uniform(0.4, 1.0))),
                                      max(0.4, base_w * rnd.uniform(0.04, 0.09)), Qt.PenStyle.SolidLine,
                                      Qt.PenCapStyle.RoundCap))
                        p.drawLine(prev, q_)
                    prev = q_
            p.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceOver)
        # bristle streaks: begin inside the body and continue past it where the ink is dry
        if size >= 14:
            k = 9 if size > 40 else 5
            for j in range(k):
                off = (j / (k - 1) - 0.5) * 0.95
                t0 = rnd.uniform(0.5, 0.72)
                t1 = min(sw, rnd.uniform(0.97, 1.0))
                if t1 <= t0:
                    continue
                pen_w = max(0.35, base_w * rnd.uniform(0.07, 0.13))
                prev = None
                steps = 26
                for st in range(steps + 1):
                    t = t0 + (t1 - t0) * st / steps
                    q = pt(t, off * max(w_at(t), base_w * 0.35))
                    gap = t > 0.78 and rnd.random() < 0.28
                    if prev is not None and not gap:
                        a = alpha * (0.9 - 0.55 * (t - t0) / (t1 - t0)) * rnd.uniform(0.65, 1.0)
                        p.setPen(QPen(_col(color, a), pen_w, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                        p.drawLine(prev, q)
                    prev = None if gap else q
        if target is not p_main:
            target.end()
            p = p_main
            p.drawImage(QPointF(rect.x(), rect.y()), layer)
    if not hollow and level >= 0:
        lv = max(0.0, min(1.0, level))
        d = r * (0.18 + 0.4 * lv)
        rg = QRadialGradient(QPointF(cx, cy), d)
        rg.setColorAt(0.0, _col(color, (0.4 + 0.5 * lv) * color.alphaF()))
        rg.setColorAt(1.0, _col(color, 0.0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(rg))
        p.drawEllipse(QPointF(cx, cy), d, d)
    p.restore()


# ============================================================================ 印 seal

def seal_pixmap(text: str, w: int, h: int, color: QColor, seed: int = 1, dpr: float = 2.0,
                frame: bool = True, wear: float = 1.0) -> QPixmap:
    """A carved vermilion seal (白文: the characters are cut away, the paper shows through). Uneven ink, slightly
    rough edges, an inner frame. 1 char = square; 2 chars = tall, read top to bottom; 4 chars = 2 × 2."""
    key = (text, w, h, color.rgba(), seed, round(dpr, 2), frame, wear)
    if key in _SEAL_CACHE:
        return _SEAL_CACHE[key]
    W, H = int(w * dpr), int(h * dpr)
    img = QImage(W, H, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
    rnd = random.Random(seed)
    m = 1.2 * dpr
    rad = min(W, H) * 0.09
    # rough rounded rectangle
    pts = []
    for side in range(4):
        for i in range(10):
            t = i / 10
            if side == 0:
                x, y = m + (W - 2 * m) * t, m
            elif side == 1:
                x, y = W - m, m + (H - 2 * m) * t
            elif side == 2:
                x, y = W - m - (W - 2 * m) * t, H - m
            else:
                x, y = m, H - m - (H - 2 * m) * t
            j = rnd.uniform(-0.55, 0.55) * dpr
            pts.append(QPointF(x + (j if side in (1, 3) else 0), y + (j if side in (0, 2) else 0)))
    path = QPainterPath()
    path.addRoundedRect(QRectF(m, m, W - 2 * m, H - 2 * m), rad, rad)
    rough = QPainterPath(pts[0])
    for q in pts[1:]:
        rough.lineTo(q)
    rough.closeSubpath()
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(color)
    p.drawPath(path.intersected(rough))
    # carve: inner frame + characters
    p.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationOut)
    ink = QColor(0, 0, 0, 255)
    if frame:
        inset = min(W, H) * 0.095
        p.setPen(QPen(ink, max(1.0 * dpr, min(W, H) * 0.028)))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(QRectF(inset, inset, W - 2 * inset, H - 2 * inset), rad * 0.6, rad * 0.6)
    chars = [c for c in text if not c.isspace()]
    cells: list[QRectF] = []
    pad = min(W, H) * (0.2 if frame else 0.14)
    if len(chars) == 1:
        cells = [QRectF(pad, pad, W - 2 * pad, H - 2 * pad)]
    elif len(chars) == 2:
        ch = (H - 2 * pad) / 2
        cells = [QRectF(pad, pad, W - 2 * pad, ch), QRectF(pad, pad + ch, W - 2 * pad, ch)]
    elif len(chars) >= 3:
        cw, ch = (W - 2 * pad) / 2, (H - 2 * pad) / 2
        # traditional order: right column top→bottom, then left column
        cells = [QRectF(pad + cw, pad, cw, ch), QRectF(pad + cw, pad + ch, cw, ch),
                 QRectF(pad, pad, cw, ch), QRectF(pad, pad + ch, cw, ch)]
    for c, cell in zip(chars, cells):
        f = QFont()
        f.setFamilies(SEAL_FONT)
        f.setWeight(QFont.Weight.Black)
        f.setPixelSize(max(6, int(min(cell.width(), cell.height()) * 1.02)))
        # as an outline path, centred on its ink: glyph caches may use a font's bitmap strikes (SimSun has them
        # below ~17 px), which would carve a pixel staircase into the seal
        glyph = QPainterPath()
        glyph.addText(0, 0, f, c)
        b = glyph.boundingRect()
        if b.isEmpty():
            continue
        glyph.translate(cell.center().x() - b.center().x(), cell.center().y() - b.center().y())
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(ink)
        p.drawPath(glyph)
    # uneven ink: little voids, more of them near the edges
    for _ in range(int(W * H / (55 * dpr * dpr) * wear)):
        x, y = rnd.uniform(0, W), rnd.uniform(0, H)
        edge = min(x, y, W - x, H - y) / max(1.0, min(W, H))
        if rnd.random() < 0.55 + (0.35 if edge < 0.12 else 0.0):
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(0, 0, 0, rnd.randint(40, 190)))
            s = rnd.uniform(0.4, 1.3) * dpr
            p.drawEllipse(QPointF(x, y), s, s * rnd.uniform(0.6, 1.2))
    p.end()
    img.setDevicePixelRatio(dpr)
    px = QPixmap.fromImage(img)
    _SEAL_CACHE[key] = px
    return px


_SEAL_CACHE: dict = {}


# ============================================================================ paper & ink stone

_PAPER: dict = {}


def paper(w: int, h: int, dark: bool, base: QColor, dpr: float = 2.0, seed: int = 11) -> QPixmap:
    """The ground: base colour + low-frequency mottling + kōzo fibres (washi) or ink-stone sheen (sumi) +
    specks + a soft vignette. Full-size (no tiling seams); cached per size."""
    key = (w, h, dark, base.rgba(), round(dpr, 2), seed)
    if key in _PAPER:
        return _PAPER[key]
    if len(_PAPER) > 6:
        _PAPER.clear()
    W, H = max(1, int(w * dpr)), max(1, int(h * dpr))
    img = QImage(W, H, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(base)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    rnd = random.Random(seed)
    light, darkc = (QColor(255, 250, 238), QColor(0, 0, 0)) if dark else (QColor(255, 253, 246), QColor(92, 70, 40))
    # mottling: a tiny random image scaled up smoothly = soft clouds
    gw, gh = 13, 16
    cloud = QImage(gw, gh, QImage.Format.Format_ARGB32_Premultiplied)
    for yy in range(gh):
        for xx in range(gw):
            v = rnd.random()
            c = QColor(light if v > 0.5 else darkc)
            c.setAlpha(int(abs(v - 0.5) * 2 * (10 if dark else 18)))
            cloud.setPixelColor(xx, yy, c)
    p.drawImage(QRectF(0, 0, W, H), cloud)
    # fibres
    n_fib = int(W * H / (1800 * dpr * dpr)) * (1 if dark else 2)
    for _ in range(n_fib):
        x, y = rnd.uniform(0, W), rnd.uniform(0, H)
        ang = rnd.uniform(0, math.pi)
        ln = rnd.uniform(12, 70) * dpr
        c = QColor(light if rnd.random() < 0.6 else darkc)
        c.setAlpha(rnd.randint(4, 10) if dark else rnd.randint(8, 18))
        p.setPen(QPen(c, rnd.uniform(0.35, 0.9) * dpr))
        path = QPainterPath(QPointF(x, y))
        cx1 = x + math.cos(ang) * ln * 0.5 + rnd.uniform(-8, 8) * dpr
        cy1 = y + math.sin(ang) * ln * 0.5 + rnd.uniform(-8, 8) * dpr
        path.quadTo(QPointF(cx1, cy1), QPointF(x + math.cos(ang) * ln, y + math.sin(ang) * ln))
        p.drawPath(path)
    # specks (and on sumi, a rare mica glint)
    for _ in range(int(W * H / (140 * dpr * dpr))):
        c = QColor(darkc if (not dark and rnd.random() < 0.7) else light)
        c.setAlpha(rnd.randint(6, 22) if not dark else rnd.randint(4, 14))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(c)
        s = rnd.uniform(0.3, 0.9) * dpr
        p.drawEllipse(QPointF(rnd.uniform(0, W), rnd.uniform(0, H)), s, s)
    if dark:
        for _ in range(int(W * H / (9000 * dpr * dpr))):
            p.setBrush(QColor(255, 244, 220, rnd.randint(18, 40)))
            s = rnd.uniform(0.3, 0.6) * dpr
            p.drawEllipse(QPointF(rnd.uniform(0, W), rnd.uniform(0, H)), s, s)
        # a faint sheen from the top, like light on an ink stone
        g = QLinearGradient(0, 0, 0, H * 0.35)
        g.setColorAt(0.0, QColor(255, 248, 230, 10))
        g.setColorAt(1.0, QColor(255, 248, 230, 0))
        p.fillRect(QRectF(0, 0, W, H * 0.35), QBrush(g))
    # vignette
    rg = QRadialGradient(QPointF(W * 0.45, H * 0.4), max(W, H) * 0.8)
    rg.setColorAt(0.0, QColor(0, 0, 0, 0))
    rg.setColorAt(0.7, QColor(0, 0, 0, 0))
    rg.setColorAt(1.0, QColor(0, 0, 0, 34 if dark else 18))
    p.fillRect(QRectF(0, 0, W, H), QBrush(rg))
    p.end()
    img.setDevicePixelRatio(dpr)
    px = QPixmap.fromImage(img)
    _PAPER[key] = px
    return px


# ============================================================================ 山水 ink-wash mountains

def mountains(p: QPainter, rect: QRectF, ink: QColor, dark: bool, seed: int = 5) -> None:
    """山水: layered peaks dissolving into mist (atmospheric perspective) — far ranges pale and soft, near ones
    darker, sharper and dry-brushed along the ridge. Painted on its own layer and faded with alpha masks, so the
    paper texture shows through everywhere. Heaviest on the right: the left stays quiet for the title."""
    rnd = random.Random(seed)
    w, h = int(rect.width()), int(rect.height())
    if w < 4 or h < 4:
        return
    dpr = p.device().devicePixelRatioF() if p.device() else 1.0
    layer = QImage(int(w * dpr), int(h * dpr), QImage.Format.Format_ARGB32_Premultiplied)
    layer.fill(Qt.GlobalColor.transparent)
    layer.setDevicePixelRatio(dpr)
    q = QPainter(layer)
    q.setRenderHint(QPainter.RenderHint.Antialiasing)
    specs = [  # base (fraction of h), peak height, alpha, jaggedness, number of peaks
        (0.66, 0.40, 0.07 if dark else 0.09, 0.10, 3),
        (0.76, 0.38, 0.10 if dark else 0.14, 0.16, 3),
        (0.87, 0.36, 0.15 if dark else 0.21, 0.24, 2),
        (0.98, 0.32, 0.21 if dark else 0.30, 0.32, 2),
    ]
    n = 220
    for li, (base, height, alpha, jag, npk) in enumerate(specs):
        peaks = [(rnd.uniform(0.55, 0.98), rnd.uniform(0.07, 0.15) + 0.02 * li, rnd.uniform(0.55, 1.0))
                 for _ in range(npk)]
        detail = _smooth_noise(n, rnd, 6)
        ys = []
        for i in range(n):
            t = i / (n - 1)
            m = max(pk_h * math.exp(-((t - pk_x) / pk_w) ** 2) for pk_x, pk_w, pk_h in peaks)
            m += 0.08 * t                                    # rises gently to the right
            ridged = (1 - abs(detail[i])) * jag * m          # sharp, rocky detail where the range is high
            ys.append(h * (base - height * (m + ridged)))
        ridge = [QPointF(w * i / (n - 1), ys[i]) for i in range(n)]
        path = QPainterPath(QPointF(0, h))
        for pt_ in ridge:
            path.lineTo(pt_)
        path.lineTo(QPointF(w, h))
        path.closeSubpath()
        top = min(ys)
        g = QLinearGradient(0, top, 0, min(h, top + h * 0.55))
        g.setColorAt(0.0, _col(ink, alpha))
        g.setColorAt(0.35, _col(ink, alpha * 0.6))
        g.setColorAt(1.0, _col(ink, 0.0))
        q.setPen(Qt.PenStyle.NoPen)
        q.setBrush(QBrush(g))
        q.drawPath(path)
        # dry-brush ridge line, strongest on the high ground
        prev = None
        for i, pt_ in enumerate(ridge):
            hgt = (h * base - ys[i]) / max(1.0, h * height)
            if prev is not None and hgt > 0.12 and rnd.random() > 0.12:
                q.setPen(QPen(_col(ink, min(1.0, alpha * 2.2) * min(1.0, hgt * 1.4)), 0.5 + 1.1 * hgt,
                              Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                q.drawLine(prev, pt_)
            prev = pt_
        # 皴 cun: a few short texture strokes down the slopes of the nearer ranges
        if li >= 2:
            for _ in range(40):
                i = rnd.randrange(n)
                hgt = (h * base - ys[i]) / max(1.0, h * height)
                if hgt < 0.35:
                    continue
                x0, y0 = ridge[i].x(), ys[i] + rnd.uniform(2, 10)
                ln = rnd.uniform(6, 18) * hgt
                q.setPen(QPen(_col(ink, alpha * rnd.uniform(0.4, 0.9)), rnd.uniform(0.4, 0.9)))
                q.drawLine(QPointF(x0, y0), QPointF(x0 + rnd.uniform(-3, 3), y0 + ln))
    # mist: fade the lower half and the left side away (alpha masks — the paper shows through)
    q.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationOut)
    bg = QLinearGradient(0, h * 0.55, 0, h)
    bg.setColorAt(0.0, QColor(0, 0, 0, 0))
    bg.setColorAt(1.0, QColor(0, 0, 0, 255))
    q.fillRect(QRectF(0, 0, w, h), QBrush(bg))
    lg = QLinearGradient(0, 0, w * 0.6, 0)
    lg.setColorAt(0.0, QColor(0, 0, 0, 255))
    lg.setColorAt(0.5, QColor(0, 0, 0, 200))
    lg.setColorAt(1.0, QColor(0, 0, 0, 0))
    q.fillRect(QRectF(0, 0, w * 0.6, h), QBrush(lg))
    for _ in range(3):                                       # drifting bands of cloud
        y = rnd.uniform(0.45, 0.85) * h
        band = QLinearGradient(0, y - h * 0.06, 0, y + h * 0.06)
        band.setColorAt(0.0, QColor(0, 0, 0, 0))
        band.setColorAt(0.5, QColor(0, 0, 0, 120))
        band.setColorAt(1.0, QColor(0, 0, 0, 0))
        q.fillRect(QRectF(0, y - h * 0.06, w, h * 0.12), QBrush(band))
    q.end()
    p.drawImage(rect.topLeft(), layer)


# ============================================================================ icon

def app_icon_pixmap(size: int = 512, win: bool | None = None) -> QPixmap:
    """The app's mark: an ensō on warm paper, sealed with 面 in vermilion. Also the Dock / taskbar icon.

    Drawn per size, like a type designer's optical sizes: below 48 px the stroke gets heavier and the tile fills
    more of the square, and the seal becomes a plain vermilion chop, since a carved character that small is only
    noise. On Windows the tile bleeds nearer the edge (Windows icons have no Big Sur margin)."""
    import sys
    win = sys.platform == "win32" if win is None else win
    small, tiny = size <= 48, size <= 24
    img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    inset = size * (0.02 if tiny else 0.04 if small else 0.06 if win else 0.1)
    r = QRectF(inset, inset, size - 2 * inset, size - 2 * inset)
    sq = QPainterPath()
    rad = r.width() * (0.2 if tiny else 0.22 if (small or win) else 0.25)
    sq.addRoundedRect(r, rad, rad)
    p.setClipPath(sq)
    p.drawPixmap(r.toRect(), paper(max(1, int(r.width())), max(1, int(r.height())), False, QColor("#f3efe5"), 1.0,
                                   seed=3))
    p.setClipping(False)
    p.setPen(QPen(QColor(0, 0, 0, 70 if small else 40), max(0.6, size * 0.004)))
    p.drawPath(sq)
    m = r.width() * (0.12 if tiny else 0.13 if small else 0.15)
    er = r.adjusted(m, m * 0.9, -m, -m * 1.1)
    enso(p, er, QColor("#221f1c"), sweep=1.0, level=-1, seed=9, weight=1.9 if tiny else 1.5 if small else 1.2)
    s = r.width() * (0.27 if tiny else 0.24 if small else 0.23 if win else 0.25)
    p.translate(r.right() - s * (1.08 if small else 1.25), r.bottom() - s * (1.1 if small else 1.3))
    p.rotate(-4)
    if small:
        chop = QPainterPath()
        chop.addRoundedRect(QRectF(0, 0, s, s), s * 0.18, s * 0.18)
        p.fillPath(chop, QColor(SHU["washi"]))
    else:
        p.drawPixmap(0, 0, seal_pixmap("面", int(s), int(s), QColor(SHU["washi"]), seed=4, dpr=1.0))
    p.end()
    return QPixmap.fromImage(img)
