"""macOS niceties for the overlay (optional, needs pyobjc):
keep it visible on every Space and over full-screen Meet/Teams windows, and
don't hide it when another app is focused."""
from __future__ import annotations

import logging
import sys

log = logging.getLogger(__name__)


def float_over_everything(widget) -> None:
    if sys.platform != "darwin":
        return
    try:
        import objc
        from AppKit import (NSWindowCollectionBehaviorCanJoinAllSpaces,
                            NSWindowCollectionBehaviorFullScreenAuxiliary)

        view = objc.objc_object(c_void_p=int(widget.winId()))
        win = view.window()
        win.setCollectionBehavior_(NSWindowCollectionBehaviorCanJoinAllSpaces
                                   | NSWindowCollectionBehaviorFullScreenAuxiliary)
        win.setLevel_(25)  # NSStatusWindowLevel: above full-screen app windows
        if hasattr(win, "setHidesOnDeactivate_"):
            win.setHidesOnDeactivate_(False)
    except Exception as e:
        log.info("pyobjc window tweaks skipped: %s", e)
