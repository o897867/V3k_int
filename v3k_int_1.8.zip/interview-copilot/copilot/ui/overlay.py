"""The layered overlay window.

Visual layers, top → bottom (each appears as soon as its data exists):
  L0  live transcript of the interviewer (still-forming words fainter)
  L1  detected question  (+ 中文 gist)                          ← right after the endpoint
  B   say now — one sentence to say out loud while the rest loads    ← 0 ms (rule-based)
  L2  KEY — the one line to say first                          ← prepared: 0 ms · model: ~1–2 s
  思路 FLOW — the answer's line of thought in Chinese, each step with the English words it needs (⌘⇧Y),
      so you can answer in your own words instead of reading SAY aloud
  L3  talking points with evidence
  L4  SAY — full spoken answer (toggle ⌘⇧S)
  ALT model's version when a prepared answer holds L2–L4 (never overwrites what you're reading)
  DEEP hybrid mode: the stronger model's answer

Designed for someone whose mind has gone blank:
  · a prepared answer is shown in full (KEY + points + SAY) the moment it matches — usually before
    the interviewer finishes the sentence (provisional card), always ≤ 1.5 s after they stop
  · text already on screen is never replaced by streaming text; a merged follow-up dims the old
    answer instead of blanking it
  · ⌘⇧F focus mode: only KEY + SAY, large, for reading verbatim
  · ⌘⇧K facts panel: numbers / dates / names you might not recall
  · ⌘⇧R clarify: a polite "could you repeat that" line, and the half-heard utterance is discarded

Look (theme.py palettes, art.py materials) — an editorial page on washi paper or an ink stone:
  · one text column; every mark hangs in a 26 px gutter to its left — the quote mark before the question, the
    brush stroke before KEY, the numerals 一二三 before 思路, the dashes before points, the vermilion seal 備 when
    the answer is your own. The eye runs down the gutter to find its place.
  · type has roles: Iowan Old Style / Songti = words you SAY (KEY, 思路, SAY) · Kaiti = the 中文 gist, a teacher's
    note in the margin · SF / PingFang = things you SCAN (question, points, status).
  · the status is an ensō: it breathes with the microphone, draws itself stroke by stroke while an answer is being
    written, is left hollow when paused. With no question yet, a large ensō breathes slowly (4 s in, 6 s out).
  · motion is ink soaking into paper: new layers fade in (220 ms), the seal is stamped (scale 1.35 → 1, 260 ms),
    the window itself fades in. Streaming updates never animate — only arrivals do.
  · controls stay faint until the pointer is over the window.
"""
from __future__ import annotations

import html
from dataclasses import dataclass, field
from pathlib import Path

import math
import time

from PyQt6.QtCore import QEasingCurve, QPoint, QPointF, QPropertyAnimation, QRect, QRectF, Qt, QTimer
from PyQt6.QtGui import QColor, QFont, QKeySequence, QPainter, QPainterPath, QPen, QPixmap, QShortcut
from PyQt6.QtWidgets import (QApplication, QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel, QLineEdit,
                             QPushButton, QScrollArea, QSizeGrip, QVBoxLayout, QWidget)

from ..llm.layered_parser import parse_layers, split_step
from . import art
from . import theme as TH
from .hotkeys import pynput_to_qt
from .state import JsonState

BLOCKS = ("alt", "deep")  # secondary answer blocks, in display order
BLOCK_TITLE = {"alt": "MODEL VERSION", "deep": "DEEP"}
ACTIONS = ("force_answer", "toggle_visible", "toggle_say", "toggle_flow", "prev", "next", "click_through", "pause",
           "focus", "facts", "clarify")
ZOOM_MIN, ZOOM_MAX, ZOOM_STEP = 0.7, 2.2, 0.1
NUMERALS = "一二三四五六七八"
RADIUS = 13.0
GUTTER = 26          # every mark hangs here; text starts at this x


@dataclass
class Card:
    qid: int
    question: str
    forced: bool = False
    provisional: bool = False     # built from a live match before the interviewer finished
    stale: set = field(default_factory=set)  # merged follow-up: layers still showing the old answer (dimmed)
    from_statement: bool = False  # triggered by a long statement, may not be a question
    zh: str = ""
    flow: str = ""
    key: str = ""
    points: str = ""
    say: str = ""
    bridge: str = ""
    prepared: object = None
    metrics: dict = field(default_factory=dict)
    error: str = ""
    blocks: dict = field(default_factory=lambda: {b: {} for b in BLOCKS})


def esc(s: str) -> str:
    return html.escape(s or "")


# ============================================================================ small widgets

class InkLabel(QLabel):
    """A text block with an optional mark hanging in the gutter to its left:
    mark  → a brush stroke (KEY, say-now, panels) · glyph → a hanging character (the question's “)
    seal  → a vermilion seal, stamped in with a little animation (your own prepared answer)."""

    def __init__(self, seed: int = 0):
        super().__init__()
        self.mark: QColor | None = None
        self.glyph: tuple[str, QColor, QFont] | None = None
        self.seal: QPixmap | None = None
        self.seal_t = 1.0             # stamp animation progress 0 → 1
        self.mark_x = 8.0
        self.seed = seed
        self._stamp_timer: QTimer | None = None

    def stamp(self):
        """Press the seal: it lands a little large and faint, then settles."""
        self.seal_t = 0.0
        t0 = time.monotonic()
        if self._stamp_timer is None:
            self._stamp_timer = QTimer(self, interval=16)
            self._stamp_timer.timeout.connect(lambda: self._stamp_tick(t0))
        else:
            self._stamp_timer.timeout.disconnect()
            self._stamp_timer.timeout.connect(lambda: self._stamp_tick(t0))
        self._stamp_timer.start()

    def _stamp_tick(self, t0):
        self.seal_t = min(1.0, (time.monotonic() - t0) / 0.26)
        self.update()
        if self.seal_t >= 1.0:
            self._stamp_timer.stop()

    def paintEvent(self, e):
        super().paintEvent(e)
        if self.mark is None and self.glyph is None and self.seal is None:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        if self.mark is not None and self.height() > 8:
            h = max(10, min(self.height() - 8, int(self.fontMetrics().height() * 3.2)))
            px = art.brush_pixmap(12, h, self.mark, self.seed, self.devicePixelRatioF(), vertical=True, width=4.2)
            p.drawPixmap(QPointF(self.mark_x - 6, 4), px)
        if self.glyph is not None:
            ch, col, f = self.glyph
            p.setFont(f)
            p.setPen(col)
            fm = p.fontMetrics()
            p.drawText(QPointF(1, fm.ascent() - fm.descent() * 0.2 + 1), ch)
        if self.seal is not None:
            t = self.seal_t
            ease = 1 - (1 - t) ** 3
            scale = 1.35 - 0.35 * ease
            p.save()
            sz = self.seal.deviceIndependentSize()
            cx, cy = 2 + sz.width() / 2, 3 + sz.height() / 2
            p.translate(cx, cy)
            p.rotate(-3 - 4 * (1 - ease))
            p.scale(scale, scale)
            p.setOpacity(0.25 + 0.75 * ease)
            p.drawPixmap(QPointF(-sz.width() / 2, -sz.height() / 2), self.seal)
            p.restore()
        p.end()


class Enso(QWidget):
    """Status mark. Listening: a still circle whose centre swells with the microphone. Writing: the circle draws
    itself, stroke after stroke. Paused: hollow and faint."""

    def __init__(self, size: int = 18):
        super().__init__()
        self.setFixedSize(size, size)
        self.color = QColor("#999")
        self.level = 0.0
        self.angle = 0.0          # kept for compatibility (not used by the drawing animation)
        self.spinning = False     # True while an answer is being written
        self.hollow = False
        self.sweep = 1.0
        self._t0 = time.monotonic()

    def tick(self):
        if self.spinning:
            cyc = (time.monotonic() - self._t0) % 1.6
            self.sweep = min(1.0, cyc / 1.05)                     # draw for 1.05 s, rest 0.55 s, again
            self.sweep = 1 - (1 - self.sweep) ** 2.2
        else:
            self.sweep = 1.0
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        art.enso(p, QRectF(self.rect()), self.color, sweep=self.sweep, level=self.level if not self.hollow else -1,
                 hollow=self.hollow, seed=7)
        p.end()


class ZenView(QWidget):
    """The empty state: a large ensō breathing slowly — four seconds in, six out. For the minute before the first
    question, when nerves are loudest."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.color = QColor("#888")
        self.setFixedHeight(170)
        self._t0 = time.monotonic()
        self._timer = QTimer(self, interval=40, timeout=self.update)

    def showEvent(self, e):
        self._timer.start()
        super().showEvent(e)

    def hideEvent(self, e):
        self._timer.stop()
        super().hideEvent(e)

    def breath(self) -> float:
        """0 → 1 over the 4 s inhale, 1 → 0 over the 6 s exhale (eased)."""
        t = (time.monotonic() - self._t0) % 10.0
        x = t / 4.0 if t < 4.0 else 1.0 - (t - 4.0) / 6.0
        return 0.5 - 0.5 * math.cos(math.pi * max(0.0, min(1.0, x)))

    def paintEvent(self, _):
        b = self.breath()
        side = max(24.0, min(self.height() - 16, 132)) * (0.93 + 0.07 * b)
        r = QRectF((self.width() - side) / 2, (self.height() - side) / 2, side, side)
        c = QColor(self.color)
        c.setAlphaF(0.22 + 0.2 * b)
        p = QPainter(self)
        art.enso(p, r, c, sweep=1.0, level=-1, seed=12, weight=0.9)
        p.end()


# ============================================================================ the window

class Overlay(QWidget):
    def __init__(self, cfg, sink, controller, model_name: str, level_fn=None, demo: bool = False,
                 facts_text: str = "", data_warning: str = "", state_path: Path | None = None,
                 waiting_text: str = "Waiting for the interviewer's first question…"):
        super().__init__(None)
        self.state = JsonState(state_path, {"zoom": 1.0, "collapsed": {"alt": True, "deep": False}})
        self.cfg, self.ui, self.sink, self.ctl = cfg, cfg.ui, sink, controller
        self.T = TH.resolve(self.state.get("theme") or getattr(self.ui, "theme", "auto"))
        self.level_fn = level_fn
        self.cards: list[Card] = []
        self.view = -1          # index into cards; -1 → follow latest
        self.show_say = self.state.get("show_say", self.ui.show_say)
        self.show_flow = self.state.get("show_flow", getattr(self.ui, "show_flow", True))
        self.zoom = float(self.state.get("zoom", 1.0))
        self.collapsed = {b: bool(self.state.get("collapsed", {}).get(b, b == "alt")) for b in BLOCKS}
        self.help_open = False
        self._fonts: list[tuple[QWidget, int, dict]] = []   # widget, base px, font kwargs (for zoom)
        self.paused = False
        self.click_through = False
        self.focus = False
        self.facts_open = False
        self.facts_text = facts_text
        self.data_warning = data_warning
        self.waiting_text = waiting_text
        self.clarify_text = ""
        self.hover = False
        self._state = "listening"
        self._paper_px: QPixmap | None = None
        self._paper_key = None
        self._stamped: set = set()          # cards whose seal has already been pressed
        self._drag: QPoint | None = None
        self.fs = lambda px: max(9, int(px * self.ui.font_scale * self.zoom))
        self._save_timer = QTimer(self, singleShot=True, interval=400, timeout=self._save_state)

        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
                            | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_MacAlwaysShowToolWindow)
        self.setAttribute(Qt.WidgetAttribute.WA_Hover)
        if not demo:
            self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setWindowOpacity(self.ui.opacity)
        self.resize(self.ui.width, self.ui.height)
        self._build(model_name, demo)
        self._wire()
        if not self._restore_geometry():
            self._place()
        if self.state.get("focus", getattr(self.ui, "focus_default", False)):
            self.focus = True
        self._style()
        self._apply_fonts()
        self._render()

    # ------------------------------------------------------------------ building blocks
    def _label(self, px, *, serif=False, weight=400, italic=False, sel=True, wrap=True, ink=False,
               seed=0, role: str = "") -> QLabel:
        lb = InkLabel(seed) if ink else QLabel()
        lb.setWordWrap(wrap)
        lb.setTextFormat(Qt.TextFormat.RichText)
        kw = {"serif": serif, "weight": weight, "italic": italic, "role": role}
        lb.setFont(TH.font(self.fs(px), **kw))
        self._fonts.append((lb, px, kw))
        if sel:
            lb.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        return lb

    def _text_button(self, px, on_click, weight=500) -> QPushButton:
        """A header you can click (SAY / MODEL VERSION / DEEP): collapses or expands its section."""
        b = QPushButton()
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setFlat(True)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        kw = {"weight": weight}
        b.setFont(TH.font(self.fs(px), **kw))
        self._fonts.append((b, px, kw))
        b.clicked.connect(on_click)
        return b

    def _glyph(self, text, tip, on_click, checkable=False) -> QPushButton:
        b = QPushButton(text)
        b.setToolTip(tip)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setCheckable(checkable)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setFixedSize(24, 22)
        b.setFont(TH.font(14, weight=400))
        b.clicked.connect(on_click)
        return b

    def _build(self, model_name, demo):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 16, 10)
        root.setSpacing(0)

        # ── header: ensō in the gutter · state · model ........ ‹ 2 / 5 ›  latency   − + ◎ ◐ ?
        hdr = QHBoxLayout()
        hdr.setSpacing(0)
        self.enso = Enso(18)
        self.state_lb = self._label(12, weight=500, sel=False, wrap=False)
        self.model_lb = self._label(11, sel=False, wrap=False)
        self.model_lb.setText(esc(_short_model(model_name)))
        self.model_lb.setToolTip(model_name)
        self.lat_lb = self._label(11, sel=False, wrap=False)
        self.nav_lb = self._label(11, sel=False, wrap=False)
        self.prev_btn = self._glyph("‹", f"Previous question ({_pretty(self.cfg.hotkeys.prev)})",
                                    lambda: self.on_hotkey("prev"))
        self.next_btn = self._glyph("›", f"Next question ({_pretty(self.cfg.hotkeys.next)})",
                                    lambda: self.on_hotkey("next"))
        hdr.addWidget(self.enso)
        hdr.addSpacing(GUTTER - 18)
        hdr.addWidget(self.state_lb)
        hdr.addSpacing(8)
        hdr.addWidget(self.model_lb)
        hdr.addStretch(1)
        for w in (self.prev_btn, self.nav_lb, self.next_btn):
            hdr.addWidget(w)
        hdr.addSpacing(8)
        hdr.addWidget(self.lat_lb)
        hdr.addSpacing(8)
        self.zoom_out_btn = self._glyph("−", f"Smaller text ({_zoom_key('-')})",
                                        lambda: self.set_zoom(self.zoom - ZOOM_STEP))
        self.zoom_in_btn = self._glyph("+", f"Larger text ({_zoom_key('=')})",
                                       lambda: self.set_zoom(self.zoom + ZOOM_STEP))
        self.focus_btn = self._glyph("◎", f"Focus: only KEY + 思路 + SAY, larger ({_pretty(self.cfg.hotkeys.focus)})",
                                     lambda: self.on_hotkey("focus"), checkable=True)
        self.theme_btn = self._glyph("◐", "Ink / paper appearance", self.toggle_theme)
        self.help_btn = self._glyph("?", "Shortcuts", self.toggle_help, checkable=True)
        self.controls = (self.prev_btn, self.next_btn, self.zoom_out_btn, self.zoom_in_btn, self.focus_btn,
                         self.theme_btn, self.help_btn)
        for b in (self.zoom_out_btn, self.zoom_in_btn, self.focus_btn, self.theme_btn, self.help_btn):
            hdr.addWidget(b)
        root.addLayout(hdr)
        root.addSpacing(10)

        self.warn_lb = self._label(12, weight=500, ink=True, seed=11)
        self.warn_lb.setText(_warn(self.data_warning))
        self.warn_lb.setVisible(bool(self.data_warning))
        root.addWidget(self.warn_lb)

        # ── what they're saying (quiet)
        self.tr_lb = self._label(12)
        self.tr_lb.setAlignment(Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft)
        root.addWidget(self.tr_lb)
        root.addSpacing(12)
        rule = QHBoxLayout()
        rule.setContentsMargins(GUTTER, 0, 0, 0)
        self.hline = QFrame()
        self.hline.setFixedHeight(1)
        rule.addWidget(self.hline)
        root.addLayout(rule)
        root.addSpacing(14)

        # ── the answer: one column, marks in the gutter
        body = QWidget()
        body.setObjectName("body")
        col = QVBoxLayout(body)
        col.setContentsMargins(0, 0, 10, 14)
        col.setSpacing(11)
        self.zen = ZenView()
        self.facts_lb = self._label(13, ink=True, seed=3)
        self.clarify_lb = self._label(17, role="serif", italic=True, ink=True, seed=5)
        self.q_lb = self._label(15, weight=500, ink=True, seed=2)
        self.zh_lb = self._label(14, role="kai")
        self.bridge_lb = self._label(16, role="serif", italic=True, ink=True, seed=9)
        self.prep_lb = self._label(12, ink=True, seed=13)
        self.key_lb = self._label(21, role="serif", weight=600, ink=True, seed=1)
        self.flow_hdr = self._text_button(10, lambda: self.on_hotkey("toggle_flow"))
        self.flow_lb = self._label(15, role="serif")
        self.pts_lb = self._label(14)
        self.say_hdr = self._text_button(10, lambda: self.on_hotkey("toggle_say"))
        self.say_lb = self._label(15, role="serif")
        self.err_lb = self._label(12)
        self.block_hdr: dict[str, QPushButton] = {}
        self.block_lb: dict[str, QLabel] = {}
        for i, b in enumerate(BLOCKS):
            self.block_hdr[b] = self._text_button(10, lambda _=False, b=b: self.toggle_block(b))
            self.block_lb[b] = self._label(13, ink=True, seed=21 + i)
        self.help_lb = self._label(12, sel=False, ink=True, seed=17)
        self.help_lb.setText(self._help_html())
        self.help_lb.setVisible(False)
        for w in (self.help_lb, self.facts_lb, self.clarify_lb, self.zen, self.q_lb, self.zh_lb, self.bridge_lb,
                  self.prep_lb, self.key_lb, self.flow_hdr, self.flow_lb, self.pts_lb, self.say_hdr, self.say_lb,
                  self.err_lb, *[w for b in BLOCKS for w in (self.block_hdr[b], self.block_lb[b])]):
            col.addWidget(w)
        col.addStretch(1)
        self.body = body
        self.scroll = QScrollArea()
        self.scroll.setWidget(body)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        root.addWidget(self.scroll, 1)

        # ── footer
        hk = self.cfg.hotkeys
        self.footer = self._label(10.5, sel=False)
        self._footer_keys = [(_pretty(hk.force_answer), "answer now"), (_pretty(hk.clarify), "ask to repeat"),
                             ("?", "all keys")]
        foot = QHBoxLayout()
        foot.setContentsMargins(GUTTER, 8, 0, 0)
        foot.addWidget(self.footer, 1)
        self.grip = QSizeGrip(self)
        self.grip.setFixedSize(14, 14)
        foot.addWidget(self.grip, 0, Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignRight)
        self.input = None
        self.ask_btn = None
        if demo:
            row = QHBoxLayout()
            row.setContentsMargins(GUTTER, 8, 0, 2)
            row.setSpacing(12)
            self.input = QLineEdit()
            self.input.setPlaceholderText("Type what the interviewer says, then Enter")
            self.input.setFont(TH.font(13))
            # English-only box: bypass the system input method so a Chinese IME can't swallow Enter
            self.input.setAttribute(Qt.WidgetAttribute.WA_InputMethodEnabled, False)
            self.input.returnPressed.connect(self._submit_demo)
            self.ask_btn = QPushButton("Ask")
            self.ask_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            self.ask_btn.setFont(TH.font(13, weight=600))
            self.ask_btn.clicked.connect(self._submit_demo)
            row.addWidget(self.input, 1)
            row.addWidget(self.ask_btn)
            root.addLayout(row)
        root.addLayout(foot)

    # ------------------------------------------------------------------ look
    def _style(self):
        """(Re)apply every colour from the current theme. Called at start and when the theme is switched."""
        T = self.T
        g = f"padding:0 0 0 {GUTTER}px;"
        self._style_controls()
        head = (f"QPushButton{{color:{T.faint}; background:transparent; border:none; text-align:left; "
                f"padding:2px 0 0 {GUTTER}px; letter-spacing:2px;}} QPushButton:hover{{color:{T.text};}}")
        self.say_hdr.setStyleSheet(head)
        self.flow_hdr.setStyleSheet(head)
        self.flow_lb.setStyleSheet(f"color:{T.text}; background:transparent;")
        for b in BLOCKS:
            self.block_hdr[b].setStyleSheet(head.replace(T.faint, getattr(T, b), 1))
        for w in (self.state_lb, self.model_lb, self.lat_lb, self.nav_lb):
            w.setStyleSheet(f"color:{T.faint}; background:transparent;")
        self.footer.setStyleSheet(f"color:{T.faint}; background:transparent;")
        sp = "&nbsp;" * 5
        self.footer.setText(sp.join(f"<span style='color:{T.muted}'>{esc(k)}</span>&nbsp;&nbsp;{esc(d)}"
                                    for k, d in self._footer_keys))
        self.tr_lb.setStyleSheet(f"color:{T.muted}; background:transparent; {g}")
        self.hline.setStyleSheet(f"background:{T.hair};")
        self.q_lb.setStyleSheet(f"color:{T.strong}; background:transparent; {g}")
        self.q_lb.glyph = ("“", T.qcolor(T.faint), TH.font(34, role="serif"))
        self.zh_lb.setStyleSheet(f"color:{T.zh}; background:transparent; {g}")
        self.pts_lb.setStyleSheet(f"color:{T.text}; background:transparent;")
        self.err_lb.setStyleSheet(f"color:{T.err}; background:transparent; {g}")
        panel = f"background:{T.rgba(T.surface, 0.78)}; border-radius:10px; padding:12px 14px 12px {GUTTER}px;"
        self.warn_lb.setStyleSheet(f"color:{T.err}; background:{T.rgba(T.err, 0.09)}; border-radius:10px;"
                                   f"padding:9px 14px 9px {GUTTER}px;")
        self.warn_lb.mark = T.qcolor(T.err)
        self.key_lb.mark = T.qcolor(T.accent)
        self.key_lb.setStyleSheet(f"color:{T.strong}; background:transparent; padding:1px 0 3px {GUTTER}px;")
        self.bridge_lb.mark = T.qcolor(T.bridge)
        self.bridge_lb.setStyleSheet(f"color:{T.bridge}; background:transparent; {g}")
        self.clarify_lb.mark = T.qcolor(T.bridge)
        self.clarify_lb.setStyleSheet(f"color:{T.bridge}; background:transparent; {g}")
        self.prep_lb.setStyleSheet(f"color:{T.text}; background:transparent; {g}")
        self.facts_lb.mark = T.qcolor(T.accent)
        self.facts_lb.setStyleSheet(f"color:{T.text}; {panel}")
        self.help_lb.mark = T.qcolor(T.zh)
        self.help_lb.setStyleSheet(f"color:{T.text}; {panel}")
        self.help_lb.setText(self._help_html())
        for b in BLOCKS:
            self.block_lb[b].mark = T.qcolor(getattr(T, b), 150)
            self.block_lb[b].setStyleSheet(f"color:{T.text}; background:transparent; {g}")
        self.say_lb.setStyleSheet(f"color:{T.say}; background:transparent; {g}")
        self.zen.color = QColor(T.strong)
        self.body.setStyleSheet("QWidget#body{background:transparent;}")
        self.scroll.setStyleSheet(
            f"QScrollArea{{background:transparent;}} QScrollBar:vertical{{width:5px; background:transparent;"
            f"margin:2px 0;}} QScrollBar::handle:vertical{{background:{T.rgba(T.text, 0.14)}; border-radius:2px;"
            f"min-height:30px;}} QScrollBar::handle:vertical:hover{{background:{T.rgba(T.text, 0.3)};}}"
            f"QScrollBar::add-line, QScrollBar::sub-line{{height:0;}}"
            f"QScrollBar::add-page, QScrollBar::sub-page{{background:transparent;}}")
        self.scroll.viewport().setStyleSheet("background:transparent;")
        self.grip.setStyleSheet("background:transparent;")
        if self.input is not None:
            self.input.setStyleSheet(
                f"QLineEdit{{color:{T.strong}; background:transparent; border:none; border-bottom:1px solid "
                f"{T.hair}; padding:6px 2px;}} QLineEdit:focus{{border-bottom:1px solid {T.accent};}}")
            pal = self.input.palette()
            pal.setColor(pal.ColorRole.PlaceholderText, QColor(T.faint))
            self.input.setPalette(pal)
            self.ask_btn.setStyleSheet(
                f"QPushButton{{color:{T.accent}; background:transparent; border:1px solid {T.rgba(T.accent, 0.5)};"
                f"border-radius:14px; padding:5px 18px;}} QPushButton:hover{{background:{T.rgba(T.accent, 0.12)};}}")
        self._seal_px = art.seal_pixmap("備", 18, 18, QColor(art.SHU[T.name]), seed=8, dpr=self.devicePixelRatioF())
        self._set_state(self._state)
        self.update()

    def toggle_theme(self):
        self.T = TH.WASHI if self.T.dark else TH.SUMI
        self.state.set("theme", self.T.name)
        self._save_timer.start()
        self._style()
        self._render()

    def enterEvent(self, e):
        self.hover = True
        self._style_controls()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.hover = False
        self._style_controls()
        super().leaveEvent(e)

    def _style_controls(self):
        """Header controls are faint until the pointer is over the window: present, but not asking for attention."""
        T = self.T
        c = T.muted if self.hover else T.faint
        css = (f"QPushButton{{color:{c}; background:transparent; border:none; border-radius:6px; padding:0;}}"
               f"QPushButton:hover{{color:{T.strong}; background:{T.rgba(T.text, 0.07)};}}"
               f"QPushButton:checked{{color:{T.accent}; background:{T.rgba(T.accent, 0.12)};}}"
               f"QPushButton:disabled{{color:{T.rgba(T.faint, 0.35)};}}")
        for b in self.controls:
            b.setStyleSheet(css)

    def _place(self):
        scr = QApplication.primaryScreen().availableGeometry()
        m = 24
        x = scr.right() - self.width() - m if "right" in self.ui.position else scr.left() + m
        y = scr.top() + m if "top" in self.ui.position else scr.bottom() - self.height() - m
        self.move(x, y)

    def _wire(self):
        s = self.sink
        s.transcript.connect(self.on_transcript)
        s.question.connect(self.on_question)
        s.prepared.connect(self.on_prepared)
        s.layer.connect(self.on_layer)
        s.done.connect(self.on_done)
        s.status.connect(self.on_status)
        s.error.connect(self.on_error)
        s.hotkey.connect(self.on_hotkey)
        if hasattr(s, "warning"):
            s.warning.connect(self.show_warning)
        for action in ACTIONS:
            combo = getattr(self.cfg.hotkeys, action, "")
            if combo:  # in-window fallback when global hotkeys lack permission
                QShortcut(QKeySequence(pynput_to_qt(combo)), self, activated=lambda a=action: self.on_hotkey(a))
        for seq, fn in (("Ctrl+=", lambda: self.set_zoom(self.zoom + ZOOM_STEP)),
                        ("Ctrl++", lambda: self.set_zoom(self.zoom + ZOOM_STEP)),
                        ("Ctrl+-", lambda: self.set_zoom(self.zoom - ZOOM_STEP)),
                        ("Ctrl+0", lambda: self.set_zoom(1.0)),
                        ("Ctrl+/", self.toggle_help)):
            QShortcut(QKeySequence(seq), self, activated=fn)
        self.meter_timer = QTimer(self, interval=40, timeout=self._tick_meter)
        self.meter_timer.start()

    # ------------------------------------------------------------ paint & drag
    def paintEvent(self, _):
        """The sheet: paper (or ink stone) with its fibres and vignette, clipped to a soft rounded rectangle."""
        T = self.T
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        path = QPainterPath()
        r = QRectF(0.5, 0.5, self.width() - 1, self.height() - 1)
        path.addRoundedRect(r, RADIUS, RADIUS)
        p.setClipPath(path)
        px = self._paper()
        p.setOpacity(T.bg_alpha / 255)
        p.drawPixmap(self.rect(), px)
        p.setOpacity(1.0)
        p.setClipping(False)
        p.setPen(QPen(T.qcolor(T.hair), 1))
        p.drawPath(path)
        # a hairline of light along the top edge — the sheet has a thickness
        hl = QColor(255, 255, 255, 22 if T.dark else 90)
        p.setPen(QPen(hl, 1))
        p.drawLine(QPointF(RADIUS, 1.5), QPointF(self.width() - RADIUS, 1.5))

    def _paper(self) -> QPixmap:
        """Paper for the current size — regenerated once resizing settles (a scaled copy stands in meanwhile)."""
        size = (self.width(), self.height(), self.T.name, round(self.devicePixelRatioF(), 2))
        if getattr(self, "_paper_key", None) == size and self._paper_px is not None:
            return self._paper_px
        if getattr(self, "_paper_px", None) is not None and getattr(self, "_resizing", False):
            return self._paper_px
        self._paper_px = art.paper(self.width(), self.height(), self.T.dark, QColor(self.T.bg),
                                   self.devicePixelRatioF(), seed=17)
        self._paper_key = size
        return self._paper_px

    def showEvent(self, e):
        super().showEvent(e)
        wh = self.windowHandle()
        if wh is not None and not getattr(self, "_screen_hooked", False):
            self._screen_hooked = True   # dragged to a display with another scale → re-cut seal and paper
            wh.screenChanged.connect(lambda _s: self._style())
        if not getattr(self, "_faded_in", False):
            self._faded_in = True
            self.setWindowOpacity(0.0)
            a = QPropertyAnimation(self, b"windowOpacity", self)
            a.setDuration(320)
            a.setStartValue(0.0)
            a.setEndValue(float(self.ui.opacity))
            a.setEasingCurve(QEasingCurve.Type.OutCubic)
            a.start()
            self._fade_anim = a

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, _):
        self._drag = None
        self._save_timer.start()

    def moveEvent(self, e):
        super().moveEvent(e)
        self._save_timer.start()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._resizing = True
        if not hasattr(self, "_resize_done"):
            self._resize_done = QTimer(self, singleShot=True, interval=180)
            self._resize_done.timeout.connect(self._after_resize)
        self._resize_done.start()
        self._save_timer.start()

    def _after_resize(self):
        self._resizing = False
        if not self.cards:
            self._render()
        self.update()

    def closeEvent(self, e):
        self._save_state()
        super().closeEvent(e)

    # ------------------------------------------------------- remembered state
    def _save_state(self):
        g = self.geometry()
        self.state.set("geometry", [g.x(), g.y(), g.width(), g.height()])
        self.state.set("zoom", round(self.zoom, 2))
        self.state.set("show_say", self.show_say)
        self.state.set("show_flow", self.show_flow)
        self.state.set("focus", self.focus)
        self.state.set("collapsed", dict(self.collapsed))
        self.state.save()

    def _restore_geometry(self) -> bool:
        g = self.state.get("geometry")
        if not (isinstance(g, list) and len(g) == 4):
            return False
        rect = QRect(*[int(v) for v in g])
        # only if the saved spot is still on a connected screen (external monitor may be gone)
        for scr in QApplication.screens():
            if scr.availableGeometry().intersects(rect):
                self.setGeometry(rect)
                return True
        return False

    # ------------------------------------------------------------ view options
    def set_zoom(self, z: float):
        self.zoom = max(ZOOM_MIN, min(ZOOM_MAX, round(z, 2)))
        self._apply_fonts()
        self._save_timer.start()

    def toggle_block(self, b: str):
        self.collapsed[b] = not self.collapsed[b]
        self._render()
        self._save_timer.start()

    def toggle_help(self):
        self.help_open = not self.help_open
        self.help_btn.setChecked(self.help_open)
        self.help_lb.setVisible(self.help_open)
        if self.help_open:
            self.scroll.verticalScrollBar().setValue(0)

    def _help_html(self) -> str:
        T = self.T
        hk = self.cfg.hotkeys
        rows = [(hk.force_answer, "answer now — nothing detected yet"), (hk.clarify, "“could you say that again?”"),
                (hk.focus, "focus: only KEY + 思路 + SAY, larger"), (hk.facts, "facts — numbers, dates, names"),
                (getattr(hk, "toggle_flow", ""), "show / hide 思路 — your line of thought in Chinese"),
                (hk.toggle_say, "show / hide SAY — hide it to speak in your own words"), (hk.prev, "previous question"), (hk.next, "next question"),
                (hk.pause, "pause listening"), (hk.toggle_visible, "hide / show this window"),
                (hk.click_through, "let clicks pass through to the meeting")]
        rows = [(_pretty(k), d) for k, d in rows if k]
        rows += [(_zoom_key("all"), "text size (or − + above)"), ("◐", "ink / paper appearance"),
                 ("▸ header", "click to open / close that section")]
        cells = "".join(f"<tr><td style='color:{T.accent}; padding:3px 18px 3px 0; white-space:nowrap'>{esc(k)}"
                        f"</td><td style='color:{T.text}; padding:3px 0'>{esc(d)}</td></tr>" for k, d in rows)
        return (f"<div style='color:{T.muted}; letter-spacing:1.5px; font-size:small'>SHORTCUTS</div>"
                f"<table cellspacing=0 cellpadding=0 style='margin-top:6px'>{cells}</table>")

    def _apply_fonts(self):
        """Zoom × font_scale for every text widget; focus mode enlarges the lines you read aloud."""
        big = {self.key_lb, self.say_lb, self.bridge_lb, self.clarify_lb, self.flow_lb}
        k_focus = self.ui.focus_font_scale if self.focus else 1.0
        for w, px, kw in self._fonts:
            w.setFont(TH.font(self.fs(px * (k_focus if w in big else 1.0)), **kw))
        self.tr_lb.setMaximumHeight(int(self.fs(12) * 1.45 * 3) + 4)
        for w in (self.tr_lb, self.hline):
            w.setVisible(not self.focus)
        self.focus_btn.setChecked(self.focus)

    # --------------------------------------------------------------- handlers
    def _card(self, qid) -> Card | None:
        for c in reversed(self.cards):
            if c.qid == qid:
                return c
        return None

    def on_transcript(self, final_text: str, interim: str):
        T = self.T
        tail = (final_text[-220:] if final_text else "")
        html_ = esc(tail)
        if interim:
            html_ += f" <span style='color:{T.faint}'>{esc(interim[-160:])}</span>"
        self.tr_lb.setText(html_)

    def on_question(self, q):
        self.clarify_text = ""
        old = self._card(q.merged_from) if q.merged_from else None
        prov = self._card(q.id) if self.cards and self.cards[-1].provisional else None
        if prov is not None and prov.qid == q.id:  # provisional card becomes the real one, answer already up
            prov.provisional = False
            prov.question = q.text
            prov.forced = q.forced
            prov.from_statement = q.from_statement
            card = prov
        else:
            self.cards = [c for c in self.cards if not c.provisional]
            card = Card(q.id, q.text, forced=q.forced, from_statement=q.from_statement)
            if old is not None:  # follow-up merged into the same question: keep old text, dimmed, until replaced
                card.prepared, card.zh, card.key, card.flow, card.points, card.say = (
                    old.prepared, old.zh, old.key, old.flow, old.points, old.say)
                card.stale = {k for k in ("key", "zh", "flow", "points", "say") if getattr(old, k)}
                self.cards[self.cards.index(old)] = card
            else:
                self.cards.append(card)
        self.view = -1
        self._set_state("thinking")
        self.scroll.verticalScrollBar().setValue(0)
        self._render()

    def on_prepared(self, qid, match, live):
        if live:
            if self.cards and self.cards[-1].qid == qid and not self.cards[-1].provisional:
                return  # the real question for this id is already on screen
            if not match.locked:  # only a hint: show it in the transcript line, don't build a card
                self.tr_lb.setText(self.tr_lb.text() + f"<br><span style='color:{self.T.prep}'>likely → "
                                                       f"{esc(match.question)}</span>")
                return
            self.cards = [c for c in self.cards if not c.provisional]
            card = Card(qid, match.question, provisional=True, prepared=match)
            L = parse_layers(match.answer)
            card.key, card.zh, card.flow, card.points, card.say = L["key"], L["zh"], L["flow"], L["points"], L["say"]
            self.cards.append(card)
            self.view = -1
            self.scroll.verticalScrollBar().setValue(0)
            self._render()
            return
        c = self._card(qid)
        if c:
            c.prepared = match
            self._render_if_current(c)

    def on_layer(self, qid, layer, text):
        if layer == "clarify":
            self.clarify_text = text
            self._render()
            QTimer.singleShot(12000, self._clear_clarify)
            return
        c = self._card(qid)
        if c is None:
            return
        if "_" in layer and layer.split("_", 1)[0] in BLOCKS:
            b, sub = layer.split("_", 1)
            c.blocks[b][sub] = text
        else:
            # each layer keeps its old (dimmed) text until ITS new text arrives — nothing ever goes blank
            c.stale.discard(layer)
            setattr(c, layer, text)
        self._render_if_current(c)

    def _clear_clarify(self):
        self.clarify_text = ""
        self._render()

    def on_done(self, qid, metrics):
        c = self._card(qid)
        if c:
            c.metrics = metrics
            self._render_if_current(c)
        self._set_state("paused" if self.paused else "listening")

    def on_status(self, text):
        self.model_lb.setToolTip(text)
        self.model_lb.setText(esc(text if len(text) <= 34 else text[:33] + "…"))
        QTimer.singleShot(4000, lambda: self.model_lb.setText(esc(_short_model(self.ctl.model_name))))

    def show_warning(self, text: str):
        """A persistent banner (e.g. microphone blocked). Replaces the previous warning text."""
        self.data_warning = text
        self.warn_lb.setText(_warn(text))
        self.warn_lb.setVisible(bool(text))

    def on_error(self, text):
        if self.cards:
            self.cards[-1].error = text
            self._render()
        self._set_state("error")

    def on_hotkey(self, action):
        if action == "force_answer":
            self.ctl.force_answer()
        elif action == "toggle_visible":
            self.setVisible(not self.isVisible())
        elif action == "toggle_say":
            self.show_say = not self.show_say
            self._render()
            self._save_timer.start()
        elif action == "toggle_flow":
            self.show_flow = not self.show_flow
            self._render()
            self._save_timer.start()
        elif action == "prev" and self.cards:
            cur = self.view if self.view >= 0 else len(self.cards) - 1
            self.view = max(0, cur - 1)
            self._render()
        elif action == "next" and self.cards:
            cur = self.view if self.view >= 0 else len(self.cards) - 1
            self.view = -1 if cur + 1 >= len(self.cards) - 1 else cur + 1
            self._render()
        elif action == "click_through":
            self.click_through = not self.click_through
            self.setWindowFlag(Qt.WindowType.WindowTransparentForInput, self.click_through)
            self.show()
        elif action == "pause":
            self.paused = not self.paused
            self.ctl.set_paused(self.paused)
            self._set_state("paused" if self.paused else "listening")
        elif action == "focus":
            self.focus = not self.focus
            self._apply_fonts()
            self._render()
            self._save_timer.start()
        elif action == "facts":
            self.facts_open = not self.facts_open
            self._render()
        elif action == "clarify":
            self.ctl.clarify()

    def _submit_demo(self):
        text = self.input.text().strip()
        if text:
            self.input.clear()
            # echo on the UI thread right away, so it's obvious the input was received even if the engine isn't
            self.tr_lb.setText(f"<span style='color:{self.T.faint}'>sent —</span> {esc(text)}")
            self.ctl.inject_text(text)

    # -------------------------------------------------------------- rendering
    def _set_state(self, st):
        T = self.T
        self._state = st
        color = {"listening": T.prep, "thinking": T.accent, "paused": T.faint, "error": T.err}[st]
        if st == "thinking" and not self.enso.spinning:
            self.enso._t0 = time.monotonic()
        self.enso.color = QColor(color)
        self.enso.spinning = st == "thinking"
        self.enso.hollow = st == "paused"
        self.enso.update()
        words = {"listening": "listening", "thinking": "writing", "paused": "paused", "error": "problem"}
        self.state_lb.setText(words[st])
        self.state_lb.setStyleSheet(f"color:{color if st != 'listening' else T.muted}; background:transparent;")

    def _tick_meter(self):
        lvl = 0.0
        if self.level_fn:
            try:
                lvl = min(1.0, float(self.level_fn()) * 6)
            except Exception:
                lvl = 0.0
        # ease: rise quickly, fall slowly — a breathing ink dot rather than a twitchy bar
        self.enso.level = max(lvl, self.enso.level * 0.82)
        self.enso.tick()

    def _current(self) -> Card | None:
        if not self.cards:
            return None
        return self.cards[self.view] if self.view >= 0 else self.cards[-1]

    def _render_if_current(self, c: Card):
        if self._current() is c:
            self._render()

    def _facts_html(self) -> str:
        """Cheat sheet: UPPERCASE lines become quiet section labels, everything else is a fact line."""
        T = self.T
        text = self.facts_text or "No cheatsheet.md / profile.md in your knowledge folder."
        out = []
        for ln in text.splitlines():
            s = ln.strip()
            if not s:
                continue
            head = s.rstrip(":").replace(" ", "").replace("→", "").replace("—", "")
            if head.isupper() and len(s) <= 32:
                out.append(f"<div style='color:{T.muted}; font-size:small; letter-spacing:1px; margin-top:8px'>"
                           f"{esc(s)}</div>")
            else:
                out.append(f"<div style='color:{T.text}; margin-top:2px'>{esc(s)}</div>")
        return "".join(out)

    def _flow_html(self, flow: str, color: str, small: bool = False) -> str:
        """思路: numerals hang in the gutter; the thought in Chinese (serif), then — quieter, in sans — the English
        words to say it with."""
        T = self.T
        k = self.ui.focus_font_scale if (self.focus and not small) else 1.0
        en_px = self.fs(12.5 * k) if not small else self.fs(11.5)
        gut = GUTTER if not small else 20
        rows = []
        for i, step in enumerate(x for x in flow.split("\n") if x.strip()):
            zh, en = split_step(step)
            num = NUMERALS[i] if i < len(NUMERALS) else str(i + 1)
            sans = TH.css_family("sans", en_px)
            en_html = (f"&nbsp;&nbsp;<span style='color:{T.muted}; font-family:{sans};"
                       f" font-size:{en_px}px'>{esc(en)}</span>" if en else "")
            rows.append(f"<tr><td width={gut + 3} valign='top' style='color:{T.accent}; padding:0 0 9px 0'>{num}</td>"
                        f"<td style='color:{color}; padding:0 0 9px 0'>{esc(zh)}{en_html}</td></tr>")
        return f"<table cellspacing=0 cellpadding=0 width='100%'>{''.join(rows)}</table>" if rows else ""

    def _points_html(self, points: str, color: str, gut: int = GUTTER) -> str:
        T = self.T
        rows = []
        for x in points.split("\n"):
            if not x:
                continue
            c, dot, txt = color, "–", esc(x)
            if x.startswith("⌨"):
                mono = TH.css_family("mono")
                txt = f"<span style='font-family:{mono}; font-size:small'>" \
                      f"{esc(x[1:].strip())}</span>"
                dot = "⌨"
            elif x.startswith("⚠"):
                c, dot, txt = T.err, "⚠", esc(x[1:].strip())
            elif x.startswith("💡"):
                c, dot, txt = T.muted, "·", esc(x[1:].strip())
            rows.append(f"<tr><td width={gut + 3} style='color:{T.faint}; padding:0 0 7px 2px' valign='top'>{dot}</td>"
                        f"<td style='color:{c}; padding:0 0 7px 0'>{txt}</td></tr>")
        return f"<table cellspacing=0 cellpadding=0 width='100%'>{''.join(rows)}</table>" if rows else ""

    def _render(self):
        T = self.T
        c = self._current()
        n = len(self.cards)
        idx = (self.view if self.view >= 0 else n - 1) + 1
        self.nav_lb.setText(f"{idx} / {n}" + (f" <span style='color:{T.accent}'>· earlier</span>"
                                              if self.view >= 0 else "") if n else "")
        for w in (self.prev_btn, self.next_btn, self.nav_lb):
            w.setVisible(n > 1)
        self.prev_btn.setEnabled(n > 1 and idx > 1)
        self.next_btn.setEnabled(n > 1 and self.view >= 0)
        self.help_lb.setVisible(self.help_open)
        hide_all = [self.zh_lb, self.bridge_lb, self.prep_lb, self.key_lb, self.flow_hdr, self.flow_lb,
                    self.pts_lb, self.say_lb, self.say_hdr,
                    self.err_lb, *self.block_hdr.values(), *self.block_lb.values()]
        self._show(self.clarify_lb, bool(self.clarify_text),
                   f"<span style='font-style:normal; font-size:small; color:{T.muted}; letter-spacing:1px'>"
                   f"say now</span><br>“{esc(self.clarify_text)}”")
        self.zen.setVisible(c is None and not self.facts_open and not self.help_open)
        if c is None:   # the breathing ensō takes about half the free space, never so much that the text hides
            self.zen.setFixedHeight(max(70, min(190, int(self.scroll.viewport().height() * 0.62))))
        if self.facts_open:
            self._show(self.facts_lb, True, f"<div style='color:{T.accent}; letter-spacing:1.5px; "
                                            f"font-size:small'>FACTS</div>" + self._facts_html())
            self.q_lb.setVisible(False)
            for w in hide_all:
                w.setVisible(False)
            return
        self.facts_lb.setVisible(False)
        self.q_lb.setVisible(True)
        if c is None:
            self.q_lb.glyph = None
            self.q_lb.setText(f"<div align='center' style='color:{T.muted}; font-weight:normal'>"
                              f"{esc(self.waiting_text)}</div>")
            for w in hide_all:
                w.setVisible(False)
            self.lat_lb.setText("")
            return
        tags = []
        if c.provisional:
            tags.append("still listening — likely this question")
        if c.forced:
            tags.append("answered on request")
        if c.stale:
            tags.append("follow-up · updating")
        if c.from_statement:
            tags.append("a statement — may not be a question")
        if c.prepared is not None and getattr(c.prepared, "unconfirmed", False):
            tags.append("prepared match unconfirmed — compare the model version")
        tag = (f"<div style='color:{T.muted}; font-weight:normal; font-size:small; margin-top:3px'>"
               f"{' · '.join(esc(t) for t in tags)}</div>") if tags else ""
        self.q_lb.glyph = ("“", T.qcolor(T.faint), TH.font(self.fs(34), role="serif"))
        self.q_lb.setText(f"{esc(c.question)}{tag}")
        focus = self.focus
        col_key = T.stale if "key" in c.stale else T.strong
        col_txt = T.stale if "points" in c.stale else T.text
        col_say = T.stale if "say" in c.stale else T.say
        self._show(self.zh_lb, c.zh and self.ui.show_zh and not focus, esc(c.zh))
        self._show(self.bridge_lb, bool(c.bridge) and not c.key,
                   f"<span style='font-style:normal; font-size:small; color:{T.muted}; letter-spacing:1px'>"
                   f"say now</span><br>“{esc(c.bridge)}”")
        p = c.prepared
        if p is not None and getattr(p, "locked", False):
            # your own answer: a vermilion seal is pressed into the gutter
            self.prep_lb.mark = None
            self.prep_lb.seal = self._seal_px
            self.prep_lb.setStyleSheet(f"color:{T.text}; background:transparent; padding:2px 0 2px {GUTTER}px;")
            self._show(self.prep_lb, not focus,
                       f"<span style='color:{T.prep}'>your prepared answer</span>"
                       f"<span style='color:{T.faint}'>&nbsp;&nbsp;·&nbsp;&nbsp;{p.score:.2f}</span>")
            self.prep_lb.setToolTip(f"matched your prepared question: {p.question}")
            if c.qid not in self._stamped and not focus:
                self._stamped.add(c.qid)
                if self.isVisible():
                    self.prep_lb.stamp()
        elif p is not None:
            self.prep_lb.seal = None
            self.prep_lb.mark = T.qcolor(T.prep)
            self.prep_lb.setStyleSheet(f"color:{T.text}; background:{T.rgba(T.prep, 0.07)}; border-radius:10px;"
                                       f"padding:10px 14px 10px {GUTTER}px;")
            self._show(self.prep_lb, not focus,
                       f"<div style='color:{T.prep}'>possibly your prepared answer "
                       f"<span style='color:{T.faint}'>· {p.score:.2f} · {esc(_clip(p.question, 60))}</span></div>"
                       f"<div style='margin-top:5px'>{_prepared_html(p.answer, T)}</div>")
        else:
            self.prep_lb.seal = None
            self._show(self.prep_lb, False, "")
        self.key_lb.setStyleSheet(f"color:{col_key}; background:transparent; padding:1px 0 3px {GUTTER}px;")
        self.key_lb.mark = T.qcolor(T.stale if "key" in c.stale else T.accent) if c.key else None
        self._show(self.key_lb, True, esc(c.key) if c.key else f"<span style='color:{T.faint}'>…</span>")
        col_flow = T.stale if "flow" in c.stale else T.text
        self._show(self.flow_hdr, bool(c.flow) and not focus,
                   "▾ 思路" if self.show_flow else "▸ 思路   hidden — click or " + _pretty(self.cfg.hotkeys.toggle_flow))
        self._show(self.flow_lb, bool(c.flow) and self.show_flow, self._flow_html(c.flow, col_flow))
        self._show(self.pts_lb, bool(c.points) and not focus, self._points_html(c.points, col_txt))
        self._show(self.say_hdr, bool(c.say) and not focus,
                   "▾ SAY" if self.show_say else "▸ SAY   hidden — click or " + _pretty(self.cfg.hotkeys.toggle_say))
        self.say_lb.setStyleSheet(f"color:{col_say}; background:transparent; padding:0 0 0 {GUTTER}px;")
        self._show(self.say_lb, bool(c.say) and self.show_say,
                   f"<div style='line-height:140%'>{esc(c.say)}</div>")
        self._show(self.err_lb, bool(c.error), esc(c.error))
        for b in BLOCKS:
            blk = c.blocks[b]
            has = any(blk.get(k) for k in ("key", "points", "say", "error"))
            state = f"✓ {blk['done']}" if blk.get("done") else ("error" if blk.get("error") else "writing…")
            arrow = "▸" if self.collapsed[b] else "▾"
            self._show(self.block_hdr[b], has and not focus, f"{arrow} {BLOCK_TITLE[b]}   {state}")
            if has and not focus and not self.collapsed[b]:
                parts = []
                if blk.get("key"):
                    parts.append(f"<div style='color:{T.strong}; font-weight:600'>{esc(blk['key'])}</div>")
                if blk.get("flow") and self.show_flow:
                    parts.append(self._flow_html(blk["flow"], T.text, small=True))
                if blk.get("points"):
                    parts.append(self._points_html(blk["points"], T.text, gut=20))
                if blk.get("say") and self.show_say:
                    parts.append(f"<div style='color:{T.say}; line-height:145%'>{esc(blk['say'])}</div>")
                if blk.get("error"):
                    parts.append(f"<div style='color:{T.err}'>{esc(blk['error'])}</div>")
                self._show(self.block_lb[b], True, "".join(parts))
            else:
                self._show(self.block_lb[b], False, "")
        m = c.metrics
        if m:
            self.lat_lb.setText(f"KEY {m['speech_end_to_key']:.1f}s · {m['speech_end_to_done']:.1f}s")
        elif p is not None and getattr(p, "locked", False) and not c.provisional:
            self.lat_lb.setText("prepared · instant")
        else:
            self.lat_lb.setText("")

    def _show(self, w: QLabel, visible, text):
        """Show / hide a layer. A layer that APPEARS soaks in like ink (220 ms); streaming updates to a layer that is
        already visible never animate."""
        appearing = bool(visible) and w.isHidden()
        w.setVisible(bool(visible))
        if visible and text is not None:
            w.setText(text)
        if appearing and self.isVisible() and w.graphicsEffect() is None:
            self._ink_in(w)

    @staticmethod
    def _ink_in(w: QWidget, ms: int = 220):
        eff = QGraphicsOpacityEffect(w)
        eff.setOpacity(0.0)
        w.setGraphicsEffect(eff)
        a = QPropertyAnimation(eff, b"opacity", w)
        a.setDuration(ms)
        a.setStartValue(0.0)
        a.setEndValue(1.0)
        a.setEasingCurve(QEasingCurve.Type.OutCubic)
        a.finished.connect(lambda: w.setGraphicsEffect(None))   # crisp text again once it has arrived
        a.start()
        w._ink_anim = a


def _prepared_html(answer: str, T=None, max_points: int = 3) -> str:
    """Hint card (medium confidence): KEY + first bullets of the prepared answer."""
    T = T or TH.SUMI
    L = parse_layers(answer)
    out = []
    if L["key"]:
        out.append(f"<div style='color:{T.strong}; font-weight:600'>{esc(L['key'])}</div>")
    if L["flow"]:
        out += [f"<div style='color:{T.text}'>{NUMERALS[i] if i < len(NUMERALS) else i + 1}&nbsp; {esc(split_step(x)[0])}"
                f"<span style='color:{T.muted}'>&nbsp; {esc(split_step(x)[1])}</span></div>"
                for i, x in enumerate(y for y in L["flow"].split("\n") if y)][:4]
    else:
        out += [f"<div style='color:{T.text}'>– {esc(x)}</div>" for x in L["points"].split("\n") if x][:max_points]
    if not out:
        out = [f"<div>{esc(ln)}</div>" for ln in answer.splitlines() if ln.strip()][:4]
    return "".join(out)


def _warn(text: str) -> str:
    text = text or ""
    return esc(text) if text[:1] and not text[:1].isalnum() else "⚠ " + esc(text)


def _clip(s: str, n: int) -> str:
    s = s or ""
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"


def _short_model(name: str) -> str:
    """claude-haiku-4-5-20251001 → haiku 4.5 ; 'mock + claude-sonnet-5' → mock + sonnet 5"""
    import re

    def one(m: str) -> str:
        m = m.strip()
        mm = re.match(r"claude-([a-z]+)-(\d+)(?:-(\d))?(?:-\d{8})?$", m)
        return f"{mm.group(1)} {mm.group(2)}{'.' + mm.group(3) if mm.group(3) else ''}" if mm else m
    return " + ".join(one(x) for x in (name or "").split("+"))


def _zoom_key(which: str) -> str:
    from ..oscompat import IS_WIN
    m = "Ctrl " if IS_WIN else "⌘"
    return {"-": m + "-", "=": m + "=", "all": f"{m}=  {m}-  {m}0"}[which]


def _pretty(combo: str) -> str:
    from ..oscompat import pretty_hotkey
    return pretty_hotkey(combo)
