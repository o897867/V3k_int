"""Global hotkeys via pynput (macOS: grant Accessibility + Input Monitoring to your terminal / Python)."""
from __future__ import annotations

import logging

log = logging.getLogger(__name__)

ACTIONS = ("force_answer", "toggle_visible", "toggle_say", "toggle_flow", "prev", "next", "click_through", "pause",
           "focus", "facts", "clarify")


def mac_accessibility_trusted() -> bool | None:
    """True/False on macOS, None elsewhere or if it can't be determined."""
    import sys
    if sys.platform != "darwin":
        return None
    for mod in ("HIServices", "ApplicationServices"):
        try:
            return bool(__import__(mod, fromlist=["AXIsProcessTrusted"]).AXIsProcessTrusted())
        except Exception:
            continue
    return None


def start_global_hotkeys(hk_cfg, emit) -> object | None:
    """emit(action_name) is called from the listener thread. Returns the listener (or None)."""
    if not hk_cfg.enabled:
        return None
    if mac_accessibility_trusted() is False:
        # An untrusted pynput listener receives nothing and its event tap can interfere with text input
        # methods (seen as 'IMKCFRunLoopWakeUpReliable' errors). Don't start it; in-window shortcuts still work.
        log.warning("Global hotkeys OFF: grant Accessibility (and Input Monitoring) to your terminal app in "
                    "System Settings → Privacy & Security, then restart it. Shortcuts still work while the "
                    "overlay is focused.")
        return None
    try:
        from pynput import keyboard
    except Exception as e:  # pragma: no cover - platform dependent
        log.warning("pynput unavailable (%s); only in-window shortcuts will work", e)
        return None
    mapping = {}
    for action in ACTIONS:
        combo = getattr(hk_cfg, action, None)
        if combo:
            mapping[combo] = (lambda a=action: emit(a))
    try:
        listener = keyboard.GlobalHotKeys(mapping)
        listener.daemon = True
        listener.start()
        return listener
    except Exception as e:  # pragma: no cover
        log.warning("global hotkeys failed (%s). On macOS: System Settings → Privacy & Security → "
                    "Accessibility / Input Monitoring → enable your terminal app. On Windows: another app may "
                    "already own one of these key combinations — change it under hotkeys: in config.yaml.", e)
        return None


def pynput_to_qt(combo: str) -> str:
    """'<cmd>+<shift>+<space>' → 'Ctrl+Shift+Space' (Qt maps Ctrl→⌘ on macOS); Windows: Ctrl is Ctrl."""
    from ..oscompat import pynput_to_qt as conv
    return conv(combo)
