"""Launcher window — what opens when you double-click `Interview Copilot.command` or run `python run.py`.

  一 Files   drop resume / JD / cover letter / analysis / question bank / a folder / a zip anywhere on the window;
             see what's loaded; generate prepared answers + cheat sheet
  二 Keys    instant format check; "Test keys online" calls the providers' free endpoints
  三 Run     speech recognition, answer model, mode — each with one line saying what the choice means
  details    health check / generation / key test output (appears when there is something to show)
  Start      closes the launcher and opens the overlay with these choices

One calm column on paper (washi) or ink (sumi) — same visual language as the overlay (theme.py).
Choices are remembered in .state/launcher.json, the appearance in .state/ui.json (shared with the overlay);
config.yaml is never rewritten.
"""
from __future__ import annotations

import contextlib
import copy
import importlib.util
import io
import traceback
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

from PyQt6.QtCore import QEventLoop, Qt, QThread, QUrl, pyqtSignal
from PyQt6.QtGui import QColor, QDesktopServices, QPainter
from PyQt6.QtWidgets import (QButtonGroup, QCheckBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QInputDialog,
                             QLabel, QPlainTextEdit, QPushButton, QScrollArea, QSizePolicy, QVBoxLayout, QWidget)

from ..importer import ROLE_LABELS, import_paths
from ..knowledge import load_knowledge
from ..oscompat import IS_WIN, local_asr_installed, meeting_audio_hint
from . import art
from . import theme as TH
from .win_window import set_app_id, tint_titlebar
from .state import JsonState
from .widgets import InkPage, InkTab, LeaderLabel, SealButton

HAIKU = "claude-haiku-4-5-20251001"
SONNET = "claude-sonnet-5-5"
ANSWER_PRESETS = {
    "haiku": ("Haiku — fastest", {"model": HAIKU, "deep_model": ""}),
    "hybrid": ("Haiku first + Sonnet underneath", {"model": HAIKU, "deep_model": SONNET}),
    "sonnet": ("Sonnet only — better, slower", {"model": SONNET, "deep_model": ""}),
}
ASR_CHOICES = {
    "local": "Local Whisper (no key, offline)",
    "deepgram": "Deepgram (fastest, cloud)",
    "openai_realtime": "OpenAI realtime (context-aware)",
}
MODES = {
    "live": "Live interview (meeting audio)",
    "mic": "Mic test — ask the questions out loud yourself",
    "practice": "Practice — type the questions",
    "ui_test": "UI test — no keys, fake answers",
}
SHORT = {  # segmented-control labels; the line under each control says what the choice means
    "asr": {"local": "Local Whisper", "deepgram": "Deepgram", "openai_realtime": "OpenAI realtime"},
    "answers": {"haiku": "Haiku", "hybrid": "Haiku + Sonnet", "sonnet": "Sonnet"},
    "mode": {"live": "Interview", "mic": "Mic test", "practice": "Practice", "ui_test": "UI test"},
}
HINTS = {
    "asr": {"local": "Whisper on this Mac — no key, audio never leaves the computer.",
            "deepgram": "Cloud, fastest: live words ~0.3 s, question ready ~0.4 s after they stop.",
            "openai_realtime": "Cloud, context-aware recognition (gpt-live-transcribe)."},
    "answers": {"haiku": "Fastest — first words about a second after the question.",
                "hybrid": "Haiku answers first; Sonnet writes a deeper version underneath.",
                "sonnet": "Better reasoning, one or two seconds slower."},
}
SECTION_NUM = {"files": "一", "keys": "二", "run": "三"}
ROW_LABELS = {"resume": "Resume", "job_description": "Job description", "cover_letter": "Cover letter",
              "my_analysis": "Your analysis", "profile": "Profile · salary, notice, visa", "qa": "Your answers · qa.md",
              "qa_bank": "Question bank", "qa_generated": "Generated answers", "cheatsheet": "Cheat sheet"}

FILE_ROWS = [("resume", True), ("job_description", True), ("cover_letter", False), ("my_analysis", False),
             ("profile", False), ("qa", False), ("qa_bank", False), ("qa_generated", False), ("cheatsheet", False)]



@dataclass
class LaunchChoice:
    mode: str = "live"
    asr: str = "local"
    answers: str = "haiku"
    record: bool = False


def apply_choice(cfg, choice: LaunchChoice):
    """Return (cfg copy with overrides, demo: bool, mock_llm: bool). The original cfg is untouched."""
    c = copy.deepcopy(cfg)
    c.asr.provider = choice.asr
    preset = ANSWER_PRESETS.get(choice.answers, ANSWER_PRESETS["haiku"])[1]
    c.llm.model = preset["model"]
    c.llm.deep_model = preset["deep_model"]
    c.audio.record = bool(choice.record) and choice.mode in ("live", "mic")
    if choice.mode == "mic":
        c.audio.device = c.audio.mic_device
    demo = choice.mode in ("practice", "ui_test")
    mock = choice.mode == "ui_test"
    if mock:
        c.llm.provider = "mock"
    return c, demo, mock


def default_cloud_asr(env_path: Path | None = None) -> str:
    """Deepgram if its key is there (fastest), else OpenAI realtime if an OpenAI key is there, else Deepgram."""
    try:
        from ..keycheck import quick_status
        st = quick_status(env_path) if env_path else {}
    except Exception:
        st = {}
    if st.get("deepgram", ("—",))[0] == "✓":
        return "deepgram"
    if st.get("openai", ("—",))[0] == "✓":
        return "openai_realtime"
    return "deepgram"


def _asr_available(asr: str) -> str | None:
    """None if usable, else a reason."""
    if asr == "local":
        if importlib.util.find_spec("mlx_whisper") or importlib.util.find_spec("faster_whisper"):
            return None
        return ("Local Whisper isn't installed — use Deepgram or OpenAI (cloud)" if IS_WIN
                else "Local Whisper isn't installed — run: pip install mlx-whisper")
    return None


class _Stream(io.TextIOBase):
    def __init__(self, emit: Callable[[str], None]):
        self.emit, self.buf = emit, ""

    def write(self, s):
        self.buf += s
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            self.emit(line)
        return len(s)

    def flush(self):
        if self.buf:
            self.emit(self.buf)
            self.buf = ""


class Worker(QThread):
    """Runs a blocking job off the UI thread; everything it prints streams into the launcher log."""
    line = pyqtSignal(str)
    done = pyqtSignal(object)

    def __init__(self, fn: Callable[[], object], parent=None):
        super().__init__(parent)
        self.fn = fn

    def run(self):
        out = _Stream(self.line.emit)
        result = None
        try:
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
                result = self.fn()
        except SystemExit as e:
            result = e.code
        except Exception as e:
            self.line.emit(f"❌ {e.__class__.__name__}: {e}")
            self.line.emit(traceback.format_exc(limit=3))
            result = e
        out.flush()
        self.done.emit(result)


class Launcher(QWidget):
    started = pyqtSignal(object)
    closed = pyqtSignal()

    def __init__(self, cfg, cfg_path: str | None, state_path: Path | None = None,
                 ask_role: Callable[[Path, list[str]], str | None] | None = None):
        super().__init__()
        self.cfg, self.cfg_path = cfg, cfg_path
        self.env_path = Path(cfg.base_dir) / ".env"
        self.state = JsonState(state_path, asdict(LaunchChoice()))
        self.choice: LaunchChoice | None = None
        self.worker: Worker | None = None
        self._busy = False   # True from job start until its completion handler has run
        self._ask_role = ask_role or self._ask_role_dialog
        self.setWindowTitle("Interview Copilot")
        self.setAcceptDrops(True)
        from PyQt6.QtGui import QGuiApplication
        scr = QGuiApplication.primaryScreen()
        avail = scr.availableGeometry().height() if scr else 900
        self.resize(720, max(560, min(860, avail - 60)))
        self.ui_state = JsonState(Path(state_path).parent / "ui.json" if state_path else None, {})
        self.theme_name = self.ui_state.get("theme") or getattr(cfg.ui, "theme", "auto") or "auto"
        self.T = TH.resolve(self.theme_name)
        self.setFont(TH.font(13))
        self._build()
        self._style()
        self.refresh()

    # ------------------------------------------------------------------ layout
    def _section(self, key: str, title: str, v: QVBoxLayout) -> None:
        """一 FILES ───────  — the numeral hangs in the left margin, like a chapter mark."""
        row = QHBoxLayout()
        row.setSpacing(0)
        num = QLabel(SECTION_NUM[key])
        num.setObjectName("secnum")
        num.setFont(TH.font(19, role="serif"))
        num.setFixedWidth(30)
        lb = QLabel(title)
        lb.setObjectName("section")
        lb.setFont(TH.font(11, weight=600))
        rule = QFrame()
        rule.setObjectName("rule")
        rule.setFixedHeight(1)
        rule.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        row.addSpacing(-30)
        row.addWidget(num)
        row.addWidget(lb)
        row.addSpacing(14)
        row.addWidget(rule, 1, Qt.AlignmentFlag.AlignVCenter)
        v.addSpacing(34)
        v.addLayout(row)
        v.addSpacing(14)

    def _ghost(self, text: str, tip: str = "") -> QPushButton:
        b = QPushButton(text)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setToolTip(tip)
        b.setFocusPolicy(Qt.FocusPolicy.TabFocus)
        return b

    def _segmented(self, key: str, options: dict, current: str | None, small: bool = False
                   ) -> tuple[QHBoxLayout, QButtonGroup]:
        """Choices as words; the chosen one carries a brush underline (InkTab)."""
        row = QHBoxLayout()
        row.setSpacing(2)
        grp = QButtonGroup(self)
        grp.setExclusive(True)
        for opt, text in options.items():
            b = InkTab(text, lambda: self.T, small=small)
            b.setProperty("opt", opt)
            b.setObjectName("tab")
            grp.addButton(b)
            row.addWidget(b)
            if current == opt:
                b.setChecked(True)
        if grp.checkedButton() is None:
            grp.buttons()[0].setChecked(True)
        grp.buttonToggled.connect(lambda *_: [b.update() for b in grp.buttons()])
        row.addStretch(1)
        return row, grp

    def _options(self, key: str) -> tuple[dict, str | None]:
        """Segmented options + current choice. On Windows without a local recogniser, Local Whisper isn't offered
        and the default is the cloud recogniser you have a key for (Deepgram, else OpenAI)."""
        opts = dict(SHORT[key])
        cur = self.state.get(key)
        if key == "asr" and IS_WIN and not local_asr_installed():
            opts.pop("local", None)
            if cur not in opts:
                cur = default_cloud_asr(self.env_path)
        return opts, cur

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        page = InkPage(lambda: self.T, header_h=176)
        page.setObjectName("page")
        root = QVBoxLayout(page)
        root.setContentsMargins(52, 40, 44, 24)
        root.setSpacing(0)
        self.scroll = QScrollArea()
        self.scroll.setWidget(page)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(self.scroll, 1)

        # title + seal + appearance
        top = QHBoxLayout()
        tcol = QVBoxLayout()
        tcol.setSpacing(4)
        trow = QHBoxLayout()
        trow.setSpacing(12)
        title = QLabel("Interview Copilot")
        title.setObjectName("title")
        title.setFont(TH.font(30, role="serif", weight=500))
        self.logo = QLabel()
        self.logo.setObjectName("logo")
        self.logo.setToolTip("从容 — composure")
        trow.addWidget(title)
        trow.addWidget(self.logo, 0, Qt.AlignmentFlag.AlignTop)
        trow.addStretch(1)
        tag = QLabel("Prepare once. In the room, glance — don't read.")
        tag.setObjectName("tagline")
        tag.setFont(TH.font(14.5, role="serif", italic=True))
        tcol.addLayout(trow)
        tcol.addWidget(tag)
        top.addLayout(tcol, 1)
        arow, self.theme_group = self._segmented("theme", {"auto": "Auto", "sumi": "墨", "washi": "紙"},
                                                 self.theme_name, small=True)
        for b in self.theme_group.buttons():
            b.setToolTip(TH.LABELS[b.property("opt")])
        self.theme_group.buttonToggled.connect(self._on_theme)
        top.addLayout(arow)
        top.setAlignment(arow, Qt.AlignmentFlag.AlignTop)
        root.addLayout(top)
        root.addSpacing(26)

        # 一 files
        self._section("files", "FILES", root)
        self.drop_lb = QLabel("Drop your files anywhere on this window — resume, JD, cover letter, analysis, "
                              "question bank + answers, or a whole folder / zip.")
        self.drop_lb.setObjectName("drop")
        self.drop_lb.setWordWrap(True)
        self.drop_lb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(self.drop_lb)
        root.addSpacing(12)
        grid = QGridLayout()
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(7)
        self.file_rows: dict[str, QLabel] = {}
        self.file_names: dict[str, QLabel] = {}
        for i, (role, _req) in enumerate(FILE_ROWS):
            name = LeaderLabel(ROW_LABELS.get(role, ROLE_LABELS[role]), lambda: self.T)
            name.setObjectName("rowname")
            name.setToolTip(ROLE_LABELS[role])
            st = QLabel()
            st.setWordWrap(True)
            st.setTextFormat(Qt.TextFormat.RichText)
            grid.addWidget(name, i, 0, Qt.AlignmentFlag.AlignTop)
            grid.addWidget(st, i, 1)
            self.file_rows[role] = st
            self.file_names[role] = name
        # optional files you haven't added are folded into one quiet line instead of a row each
        self.optional_lb = QLabel()
        self.optional_lb.setObjectName("hint")
        self.optional_lb.setWordWrap(True)
        grid.addWidget(self.optional_lb, len(FILE_ROWS), 0, 1, 2)
        grid.setColumnStretch(1, 1)
        grid.setColumnMinimumWidth(0, 190)
        root.addLayout(grid)
        root.addSpacing(14)
        row = QHBoxLayout()
        row.setSpacing(8)
        self.add_btn = self._ghost("Add files…")
        self.add_btn.clicked.connect(self._add_files)
        self.open_btn = self._ghost("Open folder")
        self.open_btn.clicked.connect(self._open_folder)
        self.tpl_btn = self._ghost("Templates",
                                   "The ideal shapes for your analysis and prepared answers (analysis / qa "
                                   "templates). Copy one into your knowledge folder as analysis.md or qa.md and "
                                   "fill in the [brackets].")
        self.tpl_btn.clicked.connect(self._open_templates)
        self.prepare_btn = self._ghost("Generate answers",
                                       "Predicts likely questions from your JD + resume and writes answers and a "
                                       "cheat sheet. Uses Sonnet once (a few cents). Review qa.generated.md after.")
        self.prepare_btn.clicked.connect(self._run_prepare)
        self.enrich_btn = self._ghost("Improve matching",
                                      "Adds 4 spoken ways of asking each bank question, plus a short KEY and "
                                      "talking points, so more questions lock instantly — and marks answers that "
                                      "never say what your work changed. ≈US$0.30, 1–2 min. Only changed answers "
                                      "are redone next time.")
        self.enrich_btn.clicked.connect(self._run_enrich)
        for b in (self.add_btn, self.open_btn, self.tpl_btn):
            row.addWidget(b)
        row.addStretch(1)
        row.addWidget(self.enrich_btn)
        row.addWidget(self.prepare_btn)
        root.addLayout(row)

        # 二 keys
        self._section("keys", "KEYS  ·  .env", root)
        grid = QGridLayout()
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(7)
        self.key_rows: dict[str, QLabel] = {}
        for i, (name, label) in enumerate((("anthropic", "Anthropic — answers"), ("openai", "OpenAI — optional"),
                                           ("deepgram", "Deepgram — optional"))):
            n = LeaderLabel(label, lambda: self.T)
            n.setObjectName("rowname")
            st = QLabel()
            st.setWordWrap(True)
            st.setTextFormat(Qt.TextFormat.RichText)
            grid.addWidget(n, i, 0, Qt.AlignmentFlag.AlignTop)
            grid.addWidget(st, i, 1)
            self.key_rows[name] = st
        grid.setColumnStretch(1, 1)
        grid.setColumnMinimumWidth(0, 190)
        root.addLayout(grid)
        root.addSpacing(12)
        row = QHBoxLayout()
        self.keys_btn = self._ghost("Test keys online", "Calls each provider's free endpoint; nothing is billed.")
        self.keys_btn.clicked.connect(self._test_keys)
        self.edit_keys_btn = self._ghost("Edit keys…", "Opens .env in a text editor. Paste each key after the = sign, "
                                                      "save, and come back — this window re-checks them.")
        self.edit_keys_btn.clicked.connect(self._edit_keys)
        row.addWidget(self.edit_keys_btn)
        row.addWidget(self.keys_btn)
        row.addStretch(1)
        root.addLayout(row)

        # 三 run
        self._section("run", "RUN", root)
        self.groups: dict[str, QButtonGroup] = {}
        self.hint_lb: dict[str, QLabel] = {}
        grid = QGridLayout()
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(4)
        grid.setColumnMinimumWidth(0, 90)
        r = 0
        for key, label in (("mode", "Mode"), ("asr", "Speech"), ("answers", "Answers")):
            lb = QLabel(label)
            lb.setObjectName("rowname")
            opts, cur = self._options(key)
            seg, grp = self._segmented(key, opts, cur)
            grp.buttonToggled.connect(lambda *_: self.refresh(keys=False, files=False))
            self.groups[key] = grp
            hint = QLabel()
            hint.setObjectName("hint")
            hint.setWordWrap(True)
            self.hint_lb[key] = hint
            grid.addWidget(lb, r, 0, Qt.AlignmentFlag.AlignVCenter)
            grid.addLayout(seg, r, 1)
            grid.addWidget(hint, r + 1, 1)
            grid.setRowMinimumHeight(r + 2, 12)
            r += 3
        grid.setColumnStretch(1, 1)
        root.addLayout(grid)
        self.mode_hint = self.hint_lb["mode"]
        self.record_cb = QCheckBox("Save the audio, to score recognition accuracy afterwards")
        self.record_cb.setToolTip("Writes sessions/<session>.wav for `python -m copilot.evaluate`. "
                                  "Test calls only — not for a real interview.")
        self.record_cb.setChecked(bool(self.state.get("record", False)))
        self.record_cb.toggled.connect(lambda *_: self.refresh(keys=False, files=False))
        rrow = QHBoxLayout()
        rrow.addSpacing(116)
        rrow.addWidget(self.record_cb, 1)
        root.addLayout(rrow)

        # details (log)
        root.addSpacing(22)
        self.log = QPlainTextEdit()
        self.log.setObjectName("log")
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(120)
        self.log.setFont(TH.font(11, mono=True))
        self.log.setPlaceholderText("Health check, key tests and answer generation print here.")
        self.log.setVisible(False)
        root.addWidget(self.log, 1)
        root.addStretch(1)

        # bottom bar — always visible, outside the scroll area
        bar = QWidget()
        bar.setObjectName("bar")
        row = QHBoxLayout(bar)
        row.setContentsMargins(52, 14, 44, 18)
        row.setSpacing(16)
        self.check_btn = self._ghost("Health check", "Audio, keys, knowledge, hotkeys and the 1.5 s budget.")
        self.check_btn.clicked.connect(self._run_preflight)
        self.status_lb = QLabel()
        self.status_lb.setObjectName("status")
        self.status_lb.setWordWrap(True)
        self.start_btn = SealButton("Start", lambda: self.T)
        self.start_btn.setObjectName("primary")
        self.start_btn.setDefault(True)
        self.start_btn.clicked.connect(self._start)
        row.addWidget(self.check_btn)
        row.addWidget(self.status_lb, 1)
        row.addWidget(self.start_btn)
        outer.addWidget(bar)
        self.rule_bar = QFrame(bar)
        self.rule_bar.setObjectName("rule")
        self.rule_bar.setFixedHeight(1)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self, "rule_bar"):
            self.rule_bar.setGeometry(52, 0, max(0, self.width() - 96), 1)

    # ------------------------------------------------------------------ look
    def _style(self):
        T = self.T
        self.setStyleSheet(f"""
            QWidget {{ color:{T.text}; }}
            QWidget#page, QWidget#bar {{ background:transparent; }}
            QScrollArea {{ background:transparent; }}
            QScrollArea > QWidget > QWidget {{ background:transparent; }}
            QScrollBar:vertical {{ width:6px; background:transparent; margin:4px 2px; }}
            QScrollBar::handle:vertical {{ background:{T.rgba(T.text, 0.18)}; border-radius:3px; min-height:30px; }}
            QScrollBar::add-line, QScrollBar::sub-line {{ height:0; }}
            QScrollBar::add-page, QScrollBar::sub-page {{ background:transparent; }}
            QLabel {{ background:transparent; }}
            QLabel#title {{ color:{T.strong}; }}
            QLabel#tagline {{ color:{T.muted}; }}
            QLabel#secnum {{ color:{T.accent}; }}
            QLabel#logo {{ padding-top:6px; }}
            QLabel#section {{ color:{T.muted}; letter-spacing:2px; }}
            QFrame#rule {{ background:{T.hair}; border:none; }}
            QLabel#rowname {{ color:{T.muted}; }}
            QLabel#hint {{ color:{T.muted}; font-size:12px; padding:2px 0 0 2px; }}
            QLabel#status {{ color:{T.muted}; font-size:12px; }}
            QPushButton {{ color:{T.text}; background:transparent; border:1px solid {T.hair};
                           border-radius:15px; padding:6px 17px; }}
            QPushButton:hover {{ border-color:{T.muted}; color:{T.strong}; }}
            QPushButton:focus {{ border-color:{T.accent}; }}
            QPushButton:disabled {{ color:{T.rgba(T.faint, 0.6)}; border-color:{T.rgba(T.hair, 0.6)}; }}
            QCheckBox {{ color:{T.muted}; spacing:8px; font-size:12px; background:transparent; }}
            QCheckBox:disabled {{ color:{T.rgba(T.faint, 0.6)}; }}
            QCheckBox::indicator {{ width:13px; height:13px; border:1px solid {T.muted}; border-radius:3px;
                                    background:transparent; }}
            QCheckBox::indicator:checked {{ background:{T.accent}; border-color:{T.accent}; }}
            QPlainTextEdit#log {{ background:{T.rgba(T.surface, 0.7)}; color:{T.muted}; border:none;
                                  border-radius:8px; padding:8px 10px; selection-background-color:{T.hair}; }}
            QToolTip {{ color:{T.text}; background:{T.surface}; border:1px solid {T.hair}; padding:5px 8px; }}
        """)
        self._drop_style(False)
        self.logo.setPixmap(art.seal_pixmap("从容", 22, 38, QColor(art.SHU[T.name]), seed=6,
                                            dpr=self.devicePixelRatioF()))
        for grp in (*getattr(self, "groups", {}).values(), self.theme_group):
            for b in grp.buttons():
                b.update()
        if self.isVisible():
            tint_titlebar(self, T)
        self.update()

    def showEvent(self, e):
        super().showEvent(e)
        tint_titlebar(self, self.T)   # Windows: the caption takes the page's colour
        wh = self.windowHandle()
        if wh is not None and not getattr(self, "_screen_hooked", False):
            self._screen_hooked = True   # moved to a display with another scale → re-cut the seal
            wh.screenChanged.connect(lambda _s: self._style())

    def _on_theme(self, button, checked):
        if not checked:
            return
        self.theme_name = button.property("opt")
        self.T = TH.resolve(self.theme_name)
        self.ui_state.set("theme", None if self.theme_name == "auto" else self.theme_name)
        self.ui_state.save()
        self._style()
        self.refresh(keys=False, files=True)

    def paintEvent(self, _):
        T = self.T
        p = QPainter(self)
        p.drawPixmap(0, 0, art.paper(self.width(), self.height(), T.dark, QColor(T.bg), self.devicePixelRatioF(),
                                     seed=23))
        p.end()

    def _drop_style(self, hot: bool):
        T = self.T
        c = T.accent if hot else T.hair
        self.drop_lb.setStyleSheet(f"QLabel#drop {{ border:1px dashed {c}; border-radius:10px; padding:18px 24px;"
                                   f"color:{T.accent if hot else T.muted}; font-size:12px;"
                                   f"background:{T.rgba(T.accent, 0.06) if hot else 'transparent'}; }}")

    # ------------------------------------------------------------------ state
    def current_choice(self) -> LaunchChoice:
        def opt(k):
            b = self.groups[k].checkedButton()
            return b.property("opt") if b else None
        return LaunchChoice(mode=opt("mode"), asr=opt("asr"), answers=opt("answers"),
                            record=self.record_cb.isChecked())

    def set_choice(self, **kw):
        if "record" in kw:
            self.record_cb.setChecked(bool(kw.pop("record")))
        for k, v in kw.items():
            for b in self.groups[k].buttons():
                if b.property("opt") == v:
                    b.setChecked(True)

    def _dot_line(self, state: str, text: str) -> str:
        """● ok (moss) · ◐ needs attention (ochre) · ● missing / wrong (bengara) · ○ optional, not added."""
        T = self.T
        dot, c, tc = {"ok": ("●", T.prep, T.text), "warn": ("●", T.accent, T.text), "bad": ("●", T.err, T.err),
                      "none": ("○", T.faint, T.muted)}[state]
        return f"<span style='color:{c}'>{dot}</span>&nbsp;&nbsp;<span style='color:{tc}'>{text}</span>"

    def _render_files(self):
        T = self.T
        kb = self.kb
        absent: list[str] = []
        kdir = Path(kb.directory)
        for role, required in FILE_ROWS:
            lb = self.file_rows[role]
            if role in ("qa", "qa_generated", "qa_bank"):
                src = {"qa_generated": "qa.generated.md", "qa_bank": "qa.bank.md"}.get(role, "qa.md")
                ents = [e for e in kb.qa.entries if e.source == src]
                n = len(ents)
                ok = n > 0
                text = f"{n} prepared answers" if ok else {
                    "qa_generated": "none — use “Generate answers”",
                    "qa_bank": "none — drop your question bank + reference answers documents",
                }.get(role, "none (optional)")
                if role == "qa_bank" and ok:
                    todo = sum(1 for e in ents if "⚠ 待填" in e.answer)
                    text += (f" · <span style='color:{T.accent}'>{todo} still have [placeholders]</span>" if todo
                             else "")
                if role == "qa_generated" and kb.qa_dropped:
                    text += f" (+{kb.qa_dropped} skipped: you have your own answer)"
            else:
                txt = kb.get(role)
                files = [f.name for f in kdir.glob(Path(self.cfg.knowledge.files.get(role, role)).stem + ".*")
                         if not f.name.startswith(".")] if kdir.exists() else []
                ok = bool(txt)
                text = (f"{files[0] if files else role} · {len(txt.split())} words" if ok
                        else ("MISSING — drop it here" if required else "not added (optional)"))
            example = any(f.startswith(("resume", "jd", "qa", "cover", "analysis", "profile", "cheat"))
                          for f in kb.example_files) and kb.is_example
            state = "bad" if (required and not ok) or (ok and example) else ("ok" if ok else "none")
            if state == "ok" and role == "qa_bank" and "placeholders" in text:
                state = "warn"
            lb.setProperty("ok", ok and not example)
            lb.setText(self._dot_line(state, text))
            folded = state == "none" and not required
            lb.setVisible(not folded)
            self.file_names[role].setVisible(not folded)
            if folded:
                absent.append(ROW_LABELS.get(role, role).split(" · ")[0])
        self.optional_lb.setText(f"<span style='color:{T.faint}'>○</span>&nbsp;&nbsp;Optional, not added: "
                                 + " · ".join(absent) if absent else "")
        self.optional_lb.setVisible(bool(absent))
        if kb.is_example:
            self.drop_lb.setText("⚠ FICTIONAL EXAMPLE data is loaded — drop YOUR files here (or change knowledge.dir)")

    def _render_keys(self):
        for name, lb in self.key_rows.items():
            icon, msg = self.key_status.get(name, ("—", "not set"))
            state = {"✓": "ok", "✅": "ok", "❌": "bad"}.get(icon, "none")
            lb.setText(self._dot_line(state, msg))

    def blocking_reasons(self) -> list[str]:
        ch = self.current_choice()
        reasons = []
        if ch.mode == "ui_test":
            return reasons
        if self.kb.is_example:
            reasons.append("fictional example data is loaded — add your own files")
        missing = self.kb.missing_core()
        if missing and ch.mode == "live":
            reasons.append("missing " + " and ".join(ROLE_LABELS[m].lower() for m in missing))
        if self.key_status.get("anthropic", ("—",))[0] != "✓":
            reasons.append("Anthropic key " + ("not set" if self.key_status.get("anthropic", ("—",))[0] == "—"
                                               else "has a problem"))
        if ch.mode in ("live", "mic"):
            need = {"deepgram": "deepgram", "openai_realtime": "openai"}.get(ch.asr)
            if need and self.key_status.get(need, ("—",))[0] != "✓":
                reasons.append(f"{ASR_CHOICES[ch.asr].split(' (')[0]} needs a working {need.title()} key")
            why = _asr_available(ch.asr)
            if why:
                reasons.append(why)
        return reasons

    def _render_readiness(self):
        ch = self.current_choice()
        self.record_cb.setEnabled(ch.mode in ("live", "mic"))
        for k in ("asr", "answers"):
            self.hint_lb[k].setText(HINTS[k].get(getattr(ch, k), ""))
        self.mode_hint.setText({
            "live": meeting_audio_hint(),
            "mic": "Listens to your microphone — ask questions aloud, as an interviewer would. Wear headphones if "
                   "a video is playing; " + ("Windows" if IS_WIN else "macOS") + " may ask for microphone permission "
                   "the first time.",
            "practice": "No audio — type or paste the interviewer's question into the overlay.",
            "ui_test": "No keys needed — fake answers, to try the layout and shortcuts.",
        }.get(ch.mode, ""))
        reasons = self.blocking_reasons()
        busy = self._busy
        self.start_btn.setEnabled(not reasons and not busy)
        if reasons:
            self.status_lb.setText(f"<span style='color:{self.T.err}'>Not yet — " + "; ".join(reasons) + "</span>")
        else:
            self.status_lb.setText(f"<span style='color:{self.T.prep}'>● Ready.</span>&nbsp; "
                                   f"<span style='color:{self.T.muted}'>A health check first is worth the minute."
                                   f"</span>")
        can_prepare = not self.kb.is_example and not self.kb.missing_core() and \
            self.key_status.get("anthropic", ("—",))[0] == "✓"
        self.prepare_btn.setEnabled(can_prepare and not busy)
        has_bank = any(e.source == "qa.bank.md" for e in self.kb.qa.entries)
        self.enrich_btn.setVisible(has_bank)
        self.enrich_btn.setEnabled(has_bank and not busy and self.key_status.get("anthropic", ("—",))[0] == "✓")
        for b in (self.check_btn, self.keys_btn, self.edit_keys_btn):
            b.setEnabled(not busy)

    # ------------------------------------------------------------------ files
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._drop_style(True)

    def dragLeaveEvent(self, e):
        self._drop_style(False)

    def dropEvent(self, e):
        self._drop_style(False)
        paths = [Path(u.toLocalFile()) for u in e.mimeData().urls() if u.isLocalFile()]
        self.import_files(paths)

    def import_files(self, paths: list[Path]):
        if not paths:
            return
        res = import_paths(self.cfg, paths, ask=self._ask_role)
        self._log("── import")
        for r in res:
            self._log(f"{'✅' if r.ok else '·'} {r.source.name}: {r.message}")
        self.refresh(keys=False)

    def _ask_role_dialog(self, path: Path, roles: list[str]) -> str | None:
        labels = [ROLE_LABELS[r] for r in roles] + ["Skip this file"]
        item, ok = QInputDialog.getItem(self, "What is this file?", f"{path.name}", labels, 0, False)
        if not ok or item == "Skip this file":
            return None
        return roles[labels.index(item)]

    def _add_files(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Add your files", str(Path.home()),
                                                "Documents (*.md *.txt *.pdf *.docx *.zip)")
        self.import_files([Path(f) for f in files])

    def _open_templates(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(self.cfg.base_dir) / "templates")))

    def _open_folder(self):
        kdir = self.cfg.path(self.cfg.knowledge.dir)
        kdir.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(kdir)))

    # ------------------------------------------------------------------ jobs
    def _log(self, line: str):
        self.log.setVisible(True)
        self.log.appendPlainText(line)

    def _run(self, title: str, fn: Callable[[], object], after: Callable[[object], None] | None = None):
        if self._busy:
            return
        self._busy = True
        self._log(f"── {title}")
        self.worker = Worker(fn, self)
        self.worker.line.connect(self._log)

        def finished(result):
            try:
                if after:
                    after(result)
            finally:
                self._busy = False
                self.worker = None
                self.refresh()
        self.worker.done.connect(finished)
        self.worker.start()
        self._render_readiness()

    def _run_preflight(self):
        from ..preflight import run_preflight
        cfg, _, _ = apply_choice(self.cfg, self.current_choice())
        self._run("health check", lambda: run_preflight(cfg))

    def _run_prepare(self):
        from .. import prepare
        args = ["--config", self.cfg_path] if self.cfg_path else []
        self._run("generating prepared answers (≈1–2 min)", lambda: prepare.main(args))

    def _run_enrich(self):
        from ..knowledge import bank
        args = (["--config", self.cfg_path] if self.cfg_path else []) + ["enrich"]

        def job():
            rc = bank.main(args)
            bank.main((["--config", self.cfg_path] if self.cfg_path else []) + ["check"])
            return rc
        self._run("adding spoken phrasings to your question bank (≈1–2 min)", job)

    def _edit_keys(self):
        """Open .env in Notepad (Windows) / TextEdit (macOS), creating it from the template first if needed."""
        import shutil
        import subprocess
        import sys
        env = self.env_path
        if not env.exists():
            tpl = env.parent / ".env.example"
            if tpl.exists():
                shutil.copyfile(tpl, env)
            else:
                env.write_text("ANTHROPIC_API_KEY=\nDEEPGRAM_API_KEY=\nOPENAI_API_KEY=\n", encoding="utf-8")
        try:
            if sys.platform == "win32":
                subprocess.Popen(["notepad.exe", str(env)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-e", str(env)])
            else:
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(env)))
        except Exception as e:
            self._log(f"❌ couldn't open {env}: {e}")
        self._watch_env = True

    def changeEvent(self, e):
        """Coming back to this window after editing .env → re-check the keys."""
        from PyQt6.QtCore import QEvent
        if e.type() == QEvent.Type.ActivationChange and self.isActiveWindow() and getattr(self, "_watch_env", False):
            self.refresh(keys=True, files=False)
        super().changeEvent(e)

    def _test_keys(self):
        from ..keycheck import full_check

        def job():
            res = full_check(self.env_path)
            for name, items in res.items():
                print(f"{name}:")
                for s, m in items:
                    print(f"   {s} {m}")
            return res

        def after(res):
            if isinstance(res, dict):
                # promote online results into the key rows
                for name, items in res.items():
                    if any(s == "❌" for s, _ in items):
                        self.key_status[name] = ("❌", next(m for s, m in items if s == "❌"))
                    elif any(s == "✅" for s, _ in items):
                        self.key_status[name] = ("✓", "works (tested online)")
        self._run("testing keys online", job, after)

    # ------------------------------------------------------------------ start / close
    def _start(self):
        if self.blocking_reasons():
            return
        self.choice = self.current_choice()
        for k, v in asdict(self.choice).items():
            self.state.set(k, v)
        self.state.save()
        self.started.emit(self.choice)
        # the page lifts away (a short fade) and the overlay takes its place
        from PyQt6.QtCore import QEasingCurve, QPropertyAnimation
        a = QPropertyAnimation(self, b"windowOpacity", self)
        a.setDuration(200)
        a.setStartValue(1.0)
        a.setEndValue(0.0)
        a.setEasingCurve(QEasingCurve.Type.InCubic)
        a.finished.connect(self.close)
        a.start()
        self._fade_out = a

    def closeEvent(self, e):
        if self.worker is not None and self.worker.isRunning():
            self.worker.wait(2000)
        self.closed.emit()
        super().closeEvent(e)

    def refresh(self, keys: bool = True, files: bool = True):
        """Reload files and key status. Online key results survive as long as the key itself is unchanged."""
        if files:
            self.kb = load_knowledge(self.cfg)
            self._render_files()
        if keys:
            from ..keycheck import quick_status
            fresh = quick_status(self.env_path)
            old = getattr(self, "key_status", {})
            self.key_status = {n: (old[n] if n in old and old[n][1] in ("works (tested online)",) and
                                   fresh[n][0] == "✓" else fresh[n]) for n in fresh}
            self._render_keys()
        self._render_readiness()


def set_app_icon() -> None:
    """The ensō + 面 seal mark as the Dock / taskbar icon, and our type as the application's default font."""
    from PyQt6.QtGui import QIcon
    from PyQt6.QtWidgets import QApplication
    set_app_id()   # Windows: our icon in the taskbar, not Python's
    app = QApplication.instance()
    if app is not None:
        app.setFont(TH.font(13))   # dialogs and style-sheeted labels inherit our stack, not the system default
    if app is not None and app.windowIcon().isNull():
        icon = QIcon()
        for s in (16, 20, 24, 32, 40, 48, 64, 128, 256, 512):   # small sizes drawn natively, not shrunk
            icon.addPixmap(art.app_icon_pixmap(s))
        app.setWindowIcon(icon)


def run_launcher(cfg, cfg_path: str | None, state_path: Path | None) -> LaunchChoice | None:
    set_app_icon()
    w = Launcher(cfg, cfg_path, state_path)
    loop = QEventLoop()
    w.closed.connect(loop.quit)
    w.show()
    w.raise_()
    w.activateWindow()
    loop.exec()
    return w.choice
