"""Windows niceties (ctypes only, every call is best-effort and silent elsewhere).

  · app id        the taskbar shows the ensō icon and groups our windows, instead of Python's icon
  · title bar     the launcher's caption is tinted to its own paper — washi or sumi — so the window reads as one
                  sheet, not a page glued under a white Windows bar (Windows 11; Windows 10 gets dark/light only)
  · corners       Windows 11 rounds the launcher like the rest of the system
"""
from __future__ import annotations

import logging
import sys

log = logging.getLogger(__name__)

APP_ID = "InterviewCopilot.Overlay"

# DwmSetWindowAttribute ids
_DARK_OLD, _DARK = 19, 20          # DWMWA_USE_IMMERSIVE_DARK_MODE (19 before Windows 10 20H1)
_CORNER = 33                       # DWMWA_WINDOW_CORNER_PREFERENCE
_BORDER, _CAPTION, _TEXT = 34, 35, 36
_ROUND = 2                         # DWMWCP_ROUND


def colorref(hex_color: str) -> int:
    """'#f3efe5' → 0x00e5eff3 (COLORREF is 0x00BBGGRR)."""
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return (b << 16) | (g << 8) | r


def set_app_id() -> None:
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception as e:  # pragma: no cover - Windows only
        log.info("app id skipped: %s", e)


def _set(hwnd: int, attr: int, value: int) -> bool:
    import ctypes
    from ctypes import wintypes
    v = ctypes.c_int(value)
    fn = ctypes.windll.dwmapi.DwmSetWindowAttribute
    fn.argtypes = [wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
    return fn(hwnd, attr, ctypes.byref(v), ctypes.sizeof(v)) == 0


def titlebar_attrs(theme) -> list[tuple[int, int]]:
    """What we ask DWM for, for a theme — separated so it can be tested anywhere."""
    return [
        (_DARK, 1 if theme.dark else 0),
        (_CAPTION, colorref(theme.bg)),
        (_TEXT, colorref(theme.muted)),
        (_BORDER, colorref(theme.hair)),
        (_CORNER, _ROUND),
    ]


def tint_titlebar(widget, theme) -> None:
    if sys.platform != "win32":
        return
    try:  # pragma: no cover - Windows only
        hwnd = int(widget.winId())
        for attr, value in titlebar_attrs(theme):
            ok = _set(hwnd, attr, value)
            if attr == _DARK and not ok:
                _set(hwnd, _DARK_OLD, value)
    except Exception as e:  # pragma: no cover
        log.info("title bar tint skipped: %s", e)
