"""Import your files into the knowledge folder — used by the launcher's drag-and-drop and by

    python -m copilot.importer ~/Downloads/resume.pdf ~/Downloads/jd.docx ~/old-copilot/knowledge

Each file is classified (resume / job description / cover letter / analysis / profile / prepared answers /
generated answers / cheat sheet) by name, then by content, and copied to the name the copilot reads.
Any existing file of the same kind — whatever its extension — is moved to knowledge/.backup/<time>/ first,
so an old resume.md can never shadow a newly dropped resume.pdf. Folders and .zip files are expanded.
Files from the bundled FICTIONAL example are refused.
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

from .knowledge import bank
from .knowledge.loader import EXAMPLE_SENTINEL, read_any

DOC_EXT = {".md", ".txt", ".pdf", ".docx", ".markdown"}
TEXT_EXT = {".md", ".txt", ".markdown"}
QA_ROLES = ("qa", "qa_generated")

# role → human label (launcher shows these)
ROLE_LABELS = {
    "resume": "Resume / CV",
    "job_description": "Job description",
    "cover_letter": "Cover letter",
    "my_analysis": "My analysis of the role",
    "profile": "Profile (salary, notice, visa…)",
    "cheatsheet": "Cheat sheet",
    "qa": "My prepared answers (qa.md)",
    "qa_generated": "Generated answers (qa.generated.md)",
    "qa_bank": "Question bank + reference answers (qa.bank.md)",
}

# filename keywords, checked in this order (more specific first)
_NAME_RULES = [
    ("qa_generated", r"qa[._ -]?generated|generated[._ -]?qa"),
    ("cheatsheet", r"cheat|速查"),
    ("qa", r"(^|[^a-z])qa([^a-z]|$)|q&a|prepared|answers|问答|面试题"),
    ("cover_letter", r"cover|求职信"),
    ("resume", r"resume|(^|[^a-z])cv([^a-z]|$)|简历|履历"),
    ("job_description", r"(^|[^a-z])jd([^a-z]|$)|job|description|position|posting|vacancy|职位|岗位"),
    ("my_analysis", r"analysis|analyse|analyze|gap|prep|notes|分析"),
    ("profile", r"profile|salary|notice|visa|个人信息"),
]


@dataclass
class ImportResult:
    source: Path
    role: str | None
    dest: Path | None
    message: str

    @property
    def ok(self) -> bool:
        return self.dest is not None


def target_for(cfg, role: str, src: Path) -> Path:
    kdir = cfg.path(cfg.knowledge.dir)
    if role in QA_ROLES:  # loader reads these exact names
        names = list(cfg.knowledge.qa_files) or ["qa.md", "qa.generated.md"]
        name = next((n for n in names if ("generated" in n) == (role == "qa_generated")), names[0])
        return kdir / name
    configured = cfg.knowledge.files.get(role) or f"{role}.md"
    return kdir / (Path(configured).stem + src.suffix.lower())


def classify(path: Path) -> str | None:
    name = path.name.lower()
    for role, pat in _NAME_RULES:
        if re.search(pat, name):
            return role
    try:
        text = read_any(path)[:6000]
    except Exception:
        return None
    low = text.lower()
    if re.search(r"(?mi)^##\s*q:", text):
        return "qa"
    if re.search(r"(?m)^(timeline|numbers|ask them)\s*$", low):
        return "cheatsheet"
    if "dear" in low[:400] and re.search(r"sincerely|kind regards|best regards|yours faithfully", low):
        return "cover_letter"
    if sum(k in low for k in ("responsibilities", "requirements", "about you", "what you'll do",
                              "what you will do", "key selection criteria", "about the role")) >= 2:
        return "job_description"
    if sum(k in low for k in ("experience", "education", "skills")) >= 2:
        return "resume"
    if re.search(r"notice period|work rights|salary expectation", low):
        return "profile"
    return None


def _expand(paths: list[Path], tmp: Path) -> list[Path]:
    out: list[Path] = []
    for p in paths:
        p = Path(p).expanduser()
        if p.is_dir():
            for f in sorted(p.rglob("*")):
                rel = f.relative_to(p).parts
                if f.is_file() and not any(part.startswith(".") or part in ("sessions", "__pycache__")
                                           for part in rel):
                    out.append(f)
        elif p.suffix.lower() == ".zip" and p.is_file():
            dest = tmp / p.stem
            with zipfile.ZipFile(p) as z:
                z.extractall(dest)
            out += _expand([dest], tmp)
        elif p.is_file():
            out.append(p)
    return out


def import_paths(cfg, paths: list, ask: Callable[[Path, list[str]], str | None] | None = None,
                 now: datetime | None = None) -> list[ImportResult]:
    """Import files/folders/zips. `ask(path, roles)` is called for files that can't be classified
    (return a role or None to skip)."""
    kdir = cfg.path(cfg.knowledge.dir)
    kdir.mkdir(parents=True, exist_ok=True)
    backup = kdir / ".backup" / (now or datetime.now()).strftime("%Y%m%d-%H%M%S")
    results: list[ImportResult] = []
    claimed: dict[str, Path] = {}
    bank_docs: dict[str, Path] = {}
    with tempfile.TemporaryDirectory() as t:
        for src in _expand([Path(p) for p in paths], Path(t)):
            if src.suffix.lower() not in DOC_EXT:
                results.append(ImportResult(src, None, None, "skipped (not md / txt / pdf / docx)"))
                continue
            if src.name.lower() in ("readme.md",) or src.name.startswith("~$"):
                results.append(ImportResult(src, None, None, "skipped"))
                continue
            try:
                if EXAMPLE_SENTINEL in read_any(src)[:4000]:
                    results.append(ImportResult(src, None, None, "refused: this is the FICTIONAL example data"))
                    continue
            except Exception as e:
                results.append(ImportResult(src, None, None, f"unreadable: {e}"))
                continue
            # an ID-keyed question bank / reference-answer document (O1, R3, D6 …) is converted, not copied —
            # checked before the filename rules, which would otherwise treat "answers.md" as a raw qa.md
            try:
                kind = bank.detect(read_any(src))
            except Exception:
                kind = None
            if kind:
                if kind in bank_docs:
                    results.append(ImportResult(src, "qa_bank", None, f"skipped: already importing "
                                                                      f"{bank_docs[kind].name} as the {kind}"))
                else:
                    bank_docs[kind] = src
                    results.append(ImportResult(src, "qa_bank", kdir / bank.SRC_DIR,
                                                f"{'question bank' if kind == 'questions' else 'reference answers'}"
                                                f" → converting"))
                continue
            role = classify(src)
            if role is None and ask is not None:
                role = ask(src, list(ROLE_LABELS))
            if role is None:
                results.append(ImportResult(src, None, None, "not recognised — skipped (rename it, e.g. resume.pdf)"))
                continue
            if role in QA_ROLES and src.suffix.lower() not in TEXT_EXT:
                results.append(ImportResult(src, role, None, "prepared answers must be a .md or .txt file"))
                continue
            if role in claimed:
                results.append(ImportResult(src, role, None, f"skipped: already importing {claimed[role].name} "
                                                             f"as {ROLE_LABELS[role]}"))
                continue
            dest = target_for(cfg, role, src)
            if src.resolve() == dest.resolve():
                results.append(ImportResult(src, role, dest, "already in place"))
                claimed[role] = src
                continue
            # move away every existing file of the same kind so the new one is the one that gets read
            stem = dest.name if role in QA_ROLES else dest.stem
            olds = [dest] if role in QA_ROLES else [f for f in kdir.glob(stem + ".*")
                                                    if f.suffix.lower() in DOC_EXT and f.stem == stem]
            moved = []
            for old in olds:
                if old.exists():
                    backup.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(old), str(backup / old.name))
                    moved.append(old.name)
            shutil.copy2(src, dest)
            claimed[role] = src
            note = f" (previous {', '.join(moved)} → .backup/{backup.name})" if moved else ""
            results.append(ImportResult(src, role, dest, f"{ROLE_LABELS[role]} → {dest.name}{note}"))
        if bank_docs:   # still inside the temp dir: sources may come from an expanded zip
            try:
                br = bank.build(kdir, bank_docs.get("questions"), bank_docs.get("answers"))
                results.append(ImportResult(Path(bank.BANK_FILE), "qa_bank", br.path if br.entries else None,
                                            br.summary() if br.entries else
                                            "no answers yet — drop the reference-answer document too"))
            except Exception as e:
                results.append(ImportResult(Path(bank.BANK_FILE), "qa_bank", None, f"conversion failed: {e}"))
    return results


def main(argv=None) -> int:
    from .config import load_config

    ap = argparse.ArgumentParser(description="Import your files into the knowledge folder")
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--config", default="config.yaml" if Path("config.yaml").exists() else None)
    a = ap.parse_args(argv)
    cfg = load_config(a.config)

    def ask(path, roles):
        print(f"\nCan't tell what {path.name} is:")
        for i, r in enumerate(roles, 1):
            print(f"  {i}. {ROLE_LABELS[r]}")
        ans = input("number (Enter = skip): ").strip()
        return roles[int(ans) - 1] if ans.isdigit() and 1 <= int(ans) <= len(roles) else None

    res = import_paths(cfg, a.paths, ask=ask if sys.stdin.isatty() else None)
    for r in res:
        print(f"{'✅' if r.ok else '·'} {r.source.name}: {r.message}")
    return 0 if any(r.ok for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
