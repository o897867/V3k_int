"""Tier-1 'instant' answers: your prepared Q&A bank, matched lexically in < 5 ms.

Markdown format (qa.md, and qa.generated.md written by `python -m copilot.prepare`):

    ## Q: Tell me about yourself
    ALT: Walk me through your background; Introduce yourself
    KEY: Data analyst bridging compliance, ops and analytics at a regulated broker
    - point one
    - point two
    SAY: I'm a data analyst at ...

Matching = blend of token TF-IDF cosine and character-trigram cosine over the question and
each ALT phrasing (max over phrasings). Trigrams make it robust to ASR spelling damage
("Power BI" → "power bee", "yourself" → "your self"). Runs in well under a millisecond per
phrasing, on every interim transcript too, so a prepared answer can appear *before* the
interviewer has finished the sentence.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass, field

_STOP = set("""a an the and or but if of to in on at for with by from as is are was were be been being do does did
have has had i you your yours me my we our us they them their it its this that these those there here what which who
whom whose can could would should will shall may might must so just about into than then too very also please
okay ok well um uh like kind sort maybe really right yeah sure great thanks thank bit little quick briefly
brief start begin first perhaps want wanted love hear know maybe now next let go ahead""".split())

_SYN = {"yourself": "background", "self": "background", "introduce": "background", "walk": "background",
        "resume": "background", "cv": "background", "thru": "through", "overview": "background", "weakness": "weakness", "weaknesses": "weakness", "strength": "strength",
        "strengths": "strength", "conflict": "conflict", "disagreement": "conflict", "disagree": "conflict",
        "challenge": "challenge", "challenging": "challenge", "difficult": "challenge", "hardest": "challenge",
        "why": "why", "motivate": "motivation", "motivates": "motivation", "salary": "salary",
        "compensation": "salary", "expectations": "salary", "stakeholders": "stakeholder",
        "failure": "failure", "failed": "failure", "mistake": "failure", "proud": "achievement",
        "achievement": "achievement", "accomplishment": "achievement"}


def tokenize(text: str) -> list[str]:
    toks = []
    for w in re.findall(r"[a-z0-9+#]+", text.lower()):
        if w in _STOP or len(w) < 2:
            continue
        w = _SYN.get(w, w)
        for suf in ("ing", "ed", "es", "s"):
            if len(w) > 4 and w.endswith(suf):
                w = w[: -len(suf)]
                break
        toks.append(w)
    return toks


def trigram_vec(text: str) -> dict[str, float]:
    t = re.sub(r"[^a-z0-9 ]+", " ", text.lower())
    t = " " + re.sub(r"\s+", " ", t).strip() + " "
    t = " ".join(w for w in t.split() if w not in _STOP)
    t = f" {t} "
    c = Counter(t[i:i + 3] for i in range(len(t) - 2))
    norm = math.sqrt(sum(v * v for v in c.values())) or 1.0
    return {g: v / norm for g, v in c.items()}


@dataclass
class QAEntry:
    question: str
    answer: str
    alts: list[str] = field(default_factory=list)
    source: str = ""
    meta: dict = field(default_factory=dict)   # ID / TAGS / FOLLOW-UP / NOTE lines — context, never shown as answer


# optional lines in a prepared answer that describe it rather than being part of it (templates/qa.template.md)
_META = {"ID": "id", "TAGS": "tags", "TAG": "tags", "标签": "tags", "FOLLOW-UP": "followups", "FOLLOWUP": "followups",
         "追问": "followups", "NOTE": "notes", "NOTES": "notes", "备注": "notes"}
_META_RE = re.compile(r"^\s*(ID|TAGS?|标签|FOLLOW-?UP|追问|NOTES?|备注)\s*[:：]\s*(.*)$", re.I)


class QABank:
    # cosine rewards overall similarity; coverage rewards the prepared phrasing being fully contained in what
    # was said (interviewers pad questions with filler); trigrams survive ASR spelling damage.
    TOKEN_WEIGHT = 0.45
    COVERAGE_WEIGHT = 0.30
    TRIGRAM_WEIGHT = 0.25

    def __init__(self):
        self.entries: list[QAEntry] = []
        self._vecs: list[tuple[int, dict[str, float]]] = []
        self._tri: list[dict[str, float]] = []
        self._idf: dict[str, float] = {}

    def load_markdown(self, text: str, source: str = "") -> None:
        text = re.sub(r"<!--.*?-->", "", text, flags=re.S)   # comments (ids, provenance) are not answer text
        blocks = re.split(r"(?m)^##\s*Q:\s*", text)
        for b in blocks[1:]:
            lines = b.strip("\n").splitlines()
            if not lines:
                continue
            q = lines[0].strip()
            alts, body = [], []
            meta: dict = {}
            for ln in lines[1:]:
                m = _META_RE.match(ln)
                if ln.strip().upper().startswith("ALT:"):
                    alts += [a.strip() for a in ln.split(":", 1)[1].split(";") if a.strip()]
                elif m:
                    k = _META[m.group(1).upper() if m.group(1).isascii() else m.group(1)]
                    if k in ("followups", "notes"):
                        meta.setdefault(k, []).append(m.group(2).strip())
                    else:
                        meta[k] = m.group(2).strip()
                else:
                    body.append(ln)
            ans = "\n".join(body).strip()
            if q.startswith("["):      # the template's blank skeleton — not a question yet
                continue
            if q and ans:
                self.entries.append(QAEntry(q, ans, alts, source, meta))

    def build(self) -> None:
        phrasings = [(i, p) for i, e in enumerate(self.entries) for p in [e.question, *e.alts]]
        n = max(1, len(phrasings))
        df = Counter()
        toks = [(i, tokenize(p)) for i, p in phrasings]
        for _, t in toks:
            df.update(set(t))
        self._idf = {w: math.log((n + 1) / (c + 0.5)) + 1 for w, c in df.items()}
        self._vecs = [(i, self._vec(t)) for i, t in toks if t]
        self._tri = [trigram_vec(p) for (i, p), (_, t) in zip(phrasings, toks) if t]

    def _vec(self, toks: list[str]) -> dict[str, float]:
        tf = Counter(toks)
        v = {w: (1 + math.log(c)) * self._idf.get(w, math.log(len(self._vecs) + 2) + 1) for w, c in tf.items()}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {w: x / norm for w, x in v.items()}

    def match(self, text: str) -> tuple[QAEntry, float] | None:
        if not self._vecs:
            return None
        toks = tokenize(text)
        if not toks:
            return None
        q = self._vec(toks)
        qt = trigram_vec(text)
        best_i, best = -1, 0.0
        qset = set(toks)
        for (i, v), tv in zip(self._vecs, self._tri):
            s_tok = sum(x * v.get(w, 0.0) for w, x in q.items())
            s_tri = sum(x * tv.get(g, 0.0) for g, x in qt.items())
            tot = sum(v.values())
            cov = sum(x for w, x in v.items() if w in qset) / tot if tot else 0.0
            s = self.TOKEN_WEIGHT * s_tok + self.COVERAGE_WEIGHT * cov + self.TRIGRAM_WEIGHT * s_tri
            if s > best:
                best_i, best = i, s
        return (self.entries[best_i], best) if best_i >= 0 else None

    def as_prompt_text(self, max_chars: int = 140000) -> str:
        """All prepared answers for the system prompt (cached, so size is nearly free). ~140k chars ≈ 35k tokens."""
        out, used = [], 0
        for e in self.entries:
            extra = "".join(f"FOLLOW-UP (prepared): {f}\n" for f in e.meta.get("followups", [])) + \
                "".join(f"NOTE (private, not to say): {n}\n" for n in e.meta.get("notes", []))
            block = f"Q: {e.question}\n{e.answer}\n{extra}"
            if used + len(block) > max_chars:
                import logging
                logging.getLogger(__name__).warning(
                    "prepared answers exceed %d chars — %d of %d go into the model prompt (all still match "
                    "instantly)", max_chars, len(out), len(self.entries))
                break
            out.append(block)
            used += len(block)
        return "\n".join(out)
