"""Prompt construction. The static part (rules + all documents) is one cacheable block;
the per-question part is tiny, which keeps time-to-first-token low."""
from __future__ import annotations

RULES = """You are a real-time interview copilot. A live job interview is happening in English.
The interviewer has just asked something. You write what {name} (the candidate) should say, in first person.
{name} will glance at your output mid-conversation, so speed and scannability matter more than polish.

OUTPUT FORMAT — exactly these sections, in this order, nothing before or after:
KEY: <the core answer in at most 14 words — the one thing to say first>
{zh_line}{flow_block}- <talking point, max 14 words, with a concrete fact from the resume/analysis>
- <talking point>
- <talking point>
SAY: <a natural spoken answer, {say_words} words, first person, {variant} English{say_hint}>

RULES
- Ground every claim in the documents below (resume, cover letter, my_analysis, prepared answers).
  Never invent employers, titles, dates, numbers or tools. If there is no evidence, answer honestly
  and pivot to the closest real experience or to how {name} would learn it quickly.
- Behavioural questions ("tell me about a time…"): SAY follows STAR — situation, task, action, result — briefly.
{impact_rule}- Technical questions (SQL, Python, statistics, BI, system design): KEY gives the correct concept; points give
  the precise steps / syntax / trade-offs; SAY explains it as a spoken answer — and if {name} has used it for
  real, ends with one line on where, and what it changed.
- "Do you have any questions for us?": give 3 sharp questions tailored to the JD instead of talking points.
- Salary / notice period / visa / availability: use only what the profile says; otherwise suggest a polite deferral.
- If the transcript is ambiguous or garbled (speech recognition errors), infer the most likely question
  from context. If it is small talk, keep KEY friendly and short.
- Prepared answers are {name}'s own words: when a question is covered by one, reuse its facts and wording.
  Text in [square brackets] — there or in any document — is an unfilled placeholder: never say it or guess what
  goes in it; leave that claim out. Lines starting with 💡 or ⚠ and ZH notes are {name}'s private prep notes, not things to say.
{spoken_rule}{flow_rule}- Tie answers back to what the job description emphasises. Style: {style}.
- No markdown headings, no bold, no preamble, no closing remarks."""

ZH_LINE = "ZH: <一句中文：面试官在问什么、想考察什么（≤25字）>\n"
FLOW_BLOCK = ("FLOW:\n"
              "> <中文：第一步说什么、为什么（≤16字）> | <the 2–6 English words {name} needs for this step>\n"
              "> <第二步> | <English words>\n"
              "> <…{flow_steps} steps in total, in the order of the spoken answer>\n")
SPOKEN_RULE = """- SPOKEN, PLAIN ENGLISH — everything is said out loud by someone under pressure, often not in their first
  language. Write the way a confident person TALKS, not writes:
  · short sentences (mostly under 15 words), one idea each; no semicolons, no long clauses, no lists inside a sentence
  · everyday words and contractions (I'm, I'd, it's, didn't); active voice; "I" for my own work
  · no buzzwords: used (not utilised/leveraged), led (not spearheaded), helped (not facilitated), made sure
    (not ensured), about (not approximately)
  · a technical term only when the question needs it — then one plain sentence saying what it means
  · natural spoken links: "So…", "What I did was…", "The main thing was…", "In the end…", "That's why…"
  · KEY and talking points in the same plain words — something you could say straight away
"""

FLOW_RULE = """- FLOW is {name}'s line of thought in Chinese, so {name} can answer freely in their own English instead of
  reading SAY aloud: one step per line, in speaking order (e.g. 结论 → 例子 → 结果 → 联系岗位), ≤16 Chinese
  characters each, then " | " and the exact English words that step needs — technical terms, names, numbers,
  a verb phrase. The steps must match SAY. For STAR answers: 情境 / 任务 / 行动 / 结果.{flow_impact}
"""
FLOW_IMPACT = """ For work {name} did:
  问题 → 做法（用了什么）→ 影响（对整个系统 / 下游）→ 联系岗位 — the 影响 step is never left out."""

# 技术 → 做了什么 → 对整体系统带来了什么影响: the "so what" is what separates a senior answer from a list of tools.
IMPACT_RULE = """- SAY WHY IT MATTERED. Whenever {name} talks about something they built, fixed, automated or ran, never stop at
  "I used X to do Y". Give three beats: (1) the problem, one line → (2) what {name} did and with what — tools only
  where they matter → (3) what that changed for the WHOLE system: who or what downstream was affected (other
  teams, users, reports, pipelines, decisions, risk, cost, speed, reliability, scale), ideally as before → after.
  Use numbers only from the documents. With no number, name the concrete change instead ("ops stopped fixing it
  by hand", "compliance got the report before the market opened") — never invent a figure.
- For those questions KEY leads with the impact ("Cut the daily report from 2 hours to 10 minutes by …"),
  and one talking point starts with "Impact:". STAR's R is this system-level result, not "and it worked".
"""


def build_system_blocks(cfg, kb, say_words: str | None = None) -> list[dict]:
    plain = getattr(cfg.llm, "spoken", "plain") != "polished"
    impact = getattr(cfg.llm, "impact", True)
    rules = RULES.format(
        name=cfg.candidate.name,
        variant=cfg.candidate.english_variant,
        style=cfg.candidate.answer_style,
        zh_line=ZH_LINE if cfg.ui.show_zh else "",
        flow_block=FLOW_BLOCK.format(name=cfg.candidate.name, flow_steps=cfg.llm.flow_steps) if cfg.llm.flow else "",
        flow_rule=FLOW_RULE.format(name=cfg.candidate.name,
                                   flow_impact=FLOW_IMPACT.format(name=cfg.candidate.name) if impact else "")
        if cfg.llm.flow else "",
        impact_rule=IMPACT_RULE.format(name=cfg.candidate.name) if impact else "",
        spoken_rule=SPOKEN_RULE if plain else "",
        say_hint=" — short sentences, everyday words, easy to say aloud" if plain else "",
        say_words=say_words or cfg.llm.say_words,
    )
    docs = []
    for name in ("job_description", "resume", "cover_letter", "my_analysis", "profile"):
        text = kb.get(name)
        if text:
            docs.append(f"<{name}>\n{text}\n</{name}>")
    qa = kb.qa.as_prompt_text()
    if qa:
        docs.append(f"<prepared_answers>\n{qa}\n</prepared_answers>")
    knowledge = "KNOWLEDGE BASE\n\n" + ("\n\n".join(docs) if docs else "(no documents loaded)")
    return [
        {"type": "text", "text": rules},
        {"type": "text", "text": knowledge, "cache_control": {"type": "ephemeral"}},
    ]


def build_user_message(question: str, recent_transcript: str, history: list[tuple[str, str]],
                       prepared_hint: str | None) -> str:
    parts = []
    if history:
        h = "\n".join(f"- Q: {q}\n  A (key): {a}" for q, a in history)
        parts.append(f"Earlier in this interview:\n{h}")
    if recent_transcript and recent_transcript.strip() != question.strip():
        parts.append(f"Interviewer's recent words (context, may contain ASR errors):\n\"{recent_transcript}\"")
    if prepared_hint:
        parts.append(f"The candidate prepared this answer for a similar question — stay consistent with it:\n{prepared_hint}")
    parts.append(f"INTERVIEWER JUST ASKED:\n\"{question}\"")
    return "\n\n".join(parts)


def build_flow_message(cfg, question: str, answer: str) -> str:
    """Ask for the 思路 of a prepared answer only (used once per answer, then cached)."""
    return (f"Write ONLY the FLOW section for the prepared answer below — no KEY, no points, no SAY.\n"
            f"It is {cfg.candidate.name}'s own answer: follow its order exactly and add no facts. Leave out any "
            f"[bracketed placeholder] claims.\n"
            f"FLOW:\n> <中文（≤16字）> | <2–6 plain English words for this step>\n({cfg.llm.flow_steps} lines)\n\n"
            f"PREPARED QUESTION: {question}\nPREPARED ANSWER:\n{answer[:3000]}")
