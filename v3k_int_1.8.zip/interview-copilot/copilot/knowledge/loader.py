"""Load the user's knowledge base: JD, resume, cover letter, own analysis, profile, Q&A bank.

Everything is small (a few thousand tokens), so instead of RAG we put *all* of it
in the system prompt and let prompt caching make it free after the first call.
That is both faster (no retrieval hop) and better (the model sees everything).
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

from .qa_bank import QABank

log = logging.getLogger(__name__)


def read_any(path: Path) -> str:
    suf = path.suffix.lower()
    if suf in (".md", ".txt", ".markdown", ""):
        return path.read_text(encoding="utf-8", errors="ignore")
    if suf == ".pdf":
        from pypdf import PdfReader
        return "\n".join((p.extract_text() or "") for p in PdfReader(str(path)).pages)
    if suf == ".docx":
        import docx  # python-docx
        return "\n".join(p.text for p in docx.Document(str(path)).paragraphs)
    raise ValueError(f"unsupported file type: {path}")


def _clean(text: str) -> str:
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)   # template guidance / notes to self stay out of the prompt
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


EXAMPLE_SENTINEL = "(EXAMPLE)"


@dataclass
class KnowledgeBase:
    docs: dict[str, str] = field(default_factory=dict)  # logical name → text
    qa: QABank = field(default_factory=QABank)
    directory: str = ""
    example_marker: bool = False                          # folder contains the `.example` marker
    qa_dropped: int = 0                                   # generated answers shadowed by your own
    example_files: list = field(default_factory=list)     # files still containing the (EXAMPLE) sentinel

    @property
    def is_example(self) -> bool:
        """True when any of the loaded knowledge is the bundled FICTIONAL example (not the user's own data)."""
        return self.example_marker or bool(self.example_files)

    def missing_core(self) -> list[str]:
        return [n for n in ("resume", "job_description") if not self.get(n)]

    def data_warning(self) -> str:
        """One line for the overlay/terminal when the loaded data can't be trusted for a real interview."""
        if self.is_example:
            files = ", ".join(self.example_files) or "all files"
            return f"FICTIONAL EXAMPLE DATA loaded ({files}) — answers are NOT about you. Put your files in ./knowledge"
        missing = self.missing_core()
        if missing:
            return f"No {' / '.join(missing)} loaded from {self.directory} — answers are not grounded in your background"
        return ""

    def get(self, name: str) -> str:
        return self.docs.get(name, "")

    def summary(self) -> str:
        parts = [f"{k}: {len(v.split())} words" for k, v in self.docs.items()]
        parts.append(f"prepared answers: {len(self.qa.entries)}")
        return " | ".join(parts)

    def keyterms(self, limit: int = 40) -> list[str]:
        """Terms worth boosting in ASR: tools / acronyms / proper nouns from the JD + resume."""
        text = self.get("job_description") + "\n" + self.get("resume")
        cands: dict[str, int] = {}
        pat = r"\b(?:[A-Z][a-zA-Z0-9+#.]*[A-Z0-9+#][a-zA-Z0-9+#]*|[A-Z]{2,}[0-9]*|[A-Z][a-z]+(?: [A-Z][a-z]+)+)\b"
        for m in re.finditer(pat, text):
            t = m.group(0).strip(".")
            if 2 <= len(t) <= 30 and t.lower() not in _COMMON_CAPS:
                cands[t] = cands.get(t, 0) + 1
        for t in _TECH_LEXICON:
            if re.search(r"(?<![A-Za-z])" + re.escape(t) + r"(?![A-Za-z])", text, re.I):
                cands[t] = cands.get(t, 0) + 3
        return [t for t, _ in sorted(cands.items(), key=lambda kv: -kv[1])][:limit]


_COMMON_CAPS = {"the", "and", "you", "we", "our", "about", "role", "job", "description", "experience",
                "responsibilities", "requirements", "skills", "key", "your", "what", "who", "this", "i",
                "summary", "education", "work", "the role", "about you", "about us", "cover letter"}
_TECH_LEXICON = ["SQL", "Python", "Power BI", "Tableau", "Excel", "DAX", "Snowflake", "dbt", "Airflow", "Spark",
                 "Databricks", "AWS", "Azure", "GCP", "BigQuery", "Redshift", "pandas", "Looker", "ETL", "ELT",
                 "A/B testing", "KPI", "stakeholder", "Agile", "Jira", "Git", "Docker", "Kubernetes", "LLM",
                 "machine learning", "regression", "SSIS", "SSRS", "PostgreSQL", "MySQL", "ASIC", "AML", "KYC"]


def qa_file_order(kdir: Path, configured: list) -> list[Path]:
    """Your own answers first (qa.md, then any other qa.*.md such as qa.bank.md), AI-generated ones last.
    On equal match scores the earlier entry wins, so your wording beats a generated duplicate."""
    names = list(dict.fromkeys(configured))
    if kdir.exists():
        names += sorted(f.name for f in kdir.glob("qa*.md") if f.name not in names)
    files = [kdir / n for n in names if (kdir / n).is_file()]
    return sorted(files, key=lambda f: (f.name != "qa.md", "generated" in f.name))


def _load_without_duplicates(bank: QABank, text: str, source: str, threshold: float = 0.85) -> int:
    """Load generated answers, skipping questions you already have your own answer for."""
    if not bank.entries:
        bank.load_markdown(text, source=source)
        return 0
    bank.build()
    tmp = QABank()
    tmp.load_markdown(text, source=source)
    dropped = 0
    for e in tmp.entries:
        m = bank.match(e.question)
        if m and m[1] >= threshold:
            dropped += 1
            continue
        bank.entries.append(e)
    if dropped:
        log.info("%s: %d answers skipped — you have your own answer to the same question", source, dropped)
    return dropped


def load_knowledge(cfg) -> KnowledgeBase:
    kdir = cfg.path(cfg.knowledge.dir)
    kb = KnowledgeBase(directory=str(kdir), example_marker=(kdir / ".example").exists())
    for name, fname in cfg.knowledge.files.items():
        if not fname:
            continue
        p = kdir / fname
        if not p.exists():
            # accept any extension with the same stem (resume.pdf instead of resume.md, …)
            alts = sorted(kdir.glob(Path(fname).stem + ".*")) if kdir.exists() else []
            alts = [a for a in alts if a.suffix.lower() in (".md", ".txt", ".pdf", ".docx")]
            if not alts:
                log.info("knowledge file missing: %s", p)
                continue
            p = alts[0]
        try:
            kb.docs[name] = _clean(read_any(p))
            if EXAMPLE_SENTINEL in kb.docs[name]:
                kb.example_files.append(p.name)
        except Exception as e:  # keep going; a missing cover letter shouldn't stop the interview
            log.warning("could not read %s: %s", p, e)
    for p in qa_file_order(kdir, cfg.knowledge.qa_files):
        text = p.read_text(encoding="utf-8")
        if EXAMPLE_SENTINEL in text:
            kb.example_files.append(p.name)
        if "generated" in p.name:
            kb.qa_dropped += _load_without_duplicates(kb.qa, text, p.name)
        else:
            kb.qa.load_markdown(text, source=p.name)
    kb.qa.build()
    return kb
