"""Import a question bank + reference-answer document pair (ID-keyed) as prepared answers.

Recognised shapes (Markdown, e.g. exported from a doc):

  question bank     - **O1 ★★★** Tell us a bit about yourself and how you got into data analytics.
                        - 听什么：两分钟内落到 Power BI 报表和数据质量…
                        - 追问：Which of the 12 KPIs was hardest to define?
  reference answers **O1 · Tell us about yourself.**
                    I'm a data analyst with three years in …            (paragraphs, lists, ```code```)
                    *要点：控制在 90 秒…*

Either file alone works; together they are joined by ID (O1, R3, D6 …). The result is written to
knowledge/qa.bank.md in the normal prepared-answer format, so every question in it gets the instant (< 1.5 s)
tier and the whole bank also goes into the model's cached prompt for follow-ups.

    python -m copilot.bank build  questions.md answers.md    # convert (the launcher does this on drop)
    python -m copilot.bank check                              # which questions would lock, which collide
    python -m copilot.bank enrich                             # optional, ~US$0.30: AI adds spoken ALT phrasings,
                                                              # a ≤14-word KEY and 3 talking points per answer
Nothing is uploaded or trained: the model reads the bank from the prompt on each call (prompt-cached).
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import html
import json
import re
import shutil
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

ID = r"[A-Z]{1,3}\d{1,3}[a-z]?"
_Q_LINE = re.compile(rf"^\s*[-*]\s+\*\*(?P<id>{ID})\s*(?P<stars>★*)\s*(?P<lvl>(?:\\?\[[^\]]*\\?\])?)\s*\*\*\s*(?P<q>.+)$")
_A_HEAD = re.compile(rf"^\*\*(?P<id>{ID})\s*[·:.\-—]\s*(?P<title>.+?)\*\*\s*$")
_SUB = re.compile(r"^\s{2,}[-*]\s+(?P<k>[^：:]{1,8})[：:]\s*(?P<v>.+)$")
BANK_FILE = "qa.bank.md"
SRC_DIR = "bank"          # knowledge/bank/: copies of the source documents + enrichment cache
ENRICH_FILE = "enrich.json"
ENRICH_VERSION = 2        # 2 = impact-first KEY, "Impact:" point, 影响 step, missing-impact note (v1.8)


def unescape(s: str) -> str:
    s = html.unescape(s)
    return re.sub(r"\\([\[\]_*#`()<>|\-.!+{}~])", r"\1", s)


def strip_md(s: str) -> str:
    s = re.sub(r"\*\*(.+?)\*\*", r"\1", s)
    s = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?!\w)", r"\1", s)
    s = re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)", r"\1", s)
    s = s.replace("`", "")
    return s.strip()


@dataclass
class BankQ:
    id: str
    question: str
    stars: int = 0
    level: str = ""
    listen: str = ""                 # 听什么 — what the interviewer is listening for
    followups: list[str] = field(default_factory=list)
    extra: list[str] = field(default_factory=list)   # 参考 / 背景 notes


@dataclass
class BankA:
    id: str
    title: str
    prose: list[str] = field(default_factory=list)   # paragraphs (lists flattened to "• …")
    code: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)   # *要点：…*


def count_ids(text: str) -> tuple[int, int]:
    lines = text.splitlines()
    return (sum(1 for ln in lines if _Q_LINE.match(ln)), sum(1 for ln in lines if _A_HEAD.match(ln.strip())))


def detect(text: str) -> str | None:
    """'questions', 'answers', or None."""
    q, a = count_ids(text)
    if max(q, a) < 5:
        return None
    return "answers" if a >= q else "questions"


def parse_questions(text: str) -> dict[str, BankQ]:
    out: dict[str, BankQ] = {}
    cur: BankQ | None = None
    for ln in text.splitlines():
        m = _Q_LINE.match(ln)
        if m:
            q = strip_md(unescape(m.group("q")))
            lvl = unescape(m.group("lvl")).strip("[] ")
            cur = out.setdefault(m.group("id"), BankQ(m.group("id"), q, len(m.group("stars")), lvl))
            continue
        if cur is None:
            continue
        s = _SUB.match(ln)
        if s:
            k, v = s.group("k").strip(), strip_md(unescape(s.group("v")))
            if k in ("听什么", "考察", "Listening for", "Looking for"):
                cur.listen = v
            elif k in ("追问", "Follow-up", "Follow-ups"):
                cur.followups += [x.strip() for x in re.split(r"(?<=\?)\s+", v) if x.strip()]
            else:
                cur.extra.append(f"{k}：{v}")
        elif ln.strip().startswith("#") or (ln.strip() and not ln.startswith(" ")):
            cur = None
    return out


def parse_answers(text: str) -> dict[str, BankA]:
    out: dict[str, BankA] = {}
    cur: BankA | None = None
    para: list[str] = []
    code: list[str] | None = None

    def flush():
        if cur is not None and para:
            p = " ".join(x.strip() for x in para).strip()
            if p:
                cur.prose.append(p)
        para.clear()

    for raw in text.splitlines():
        ln = raw.rstrip()
        if code is not None:                       # inside ``` … ```
            if ln.strip().startswith("```"):
                if cur is not None and code:
                    cur.code.append("\n".join(code).strip("\n"))
                code = None
            else:
                code.append(ln)
            continue
        m = _A_HEAD.match(ln.strip())
        if m:
            flush()
            cur = out.setdefault(m.group("id"), BankA(m.group("id"), strip_md(unescape(m.group("title")))))
            continue
        if re.match(r"^#{1,6}\s", ln):             # a section heading ends the current answer
            flush()
            cur = None
            continue
        if cur is None:
            continue
        s = ln.strip()
        if s.startswith("```"):
            flush()
            code = []
            continue
        if not s:
            flush()
            continue
        nm = re.match(r"^\*(要点|Note|Tip|注意)[：:](.+)\*$", s)
        if nm:
            flush()
            cur.notes.append(strip_md(unescape(nm.group(2))))
            continue
        if re.match(r"^([-*]|\d+[.)])\s+", s):     # list item → its own line
            flush()
            para.append("• " + strip_md(unescape(re.sub(r"^([-*]|\d+[.)])\s+", "", s))))
            flush()
            continue
        para.append(strip_md(unescape(s)))
    flush()
    return out


# ---------------------------------------------------------------- placeholders like [a real example]

_BRACKET = re.compile(r"\[([^\[\]]{1,200})\]")


def placeholders(prose: str) -> list[str]:
    """Unfilled template text in an answer: [the real causes …], [X], [CRM name], ___ .
    Code-like brackets (Site[Name], Contacts[Status]) are not placeholders."""
    found = []
    for m in _BRACKET.finditer(prose):
        inner = m.group(1).strip()
        before = prose[m.start() - 1] if m.start() else " "
        if before.isalnum() or before in "'\")(,":   # Table[Column], CALCULATE([Measure], …)
            continue
        if " " in inner or inner in ("X", "Y", "…", "...", "N") or "_" * 3 in inner:
            found.append(inner)
    if "___" in _BRACKET.sub("", prose):
        found.append("___")
    return found


# ---------------------------------------------------------------- conversion

@dataclass
class Entry:
    id: str
    question: str
    alts: list[str]
    key: str
    zh: str
    points: list[str]
    say: str
    stars: int = 0
    todo: list[str] = field(default_factory=list)
    flow: list[str] = field(default_factory=list)     # 思路: "中文 | English words" per step

    def fingerprint(self) -> str:
        return hashlib.sha1((self.question + "\n" + self.say).encode()).hexdigest()[:12]


_PREFIX = re.compile(r"^(live|whiteboard|follow[- ]?up|scenario|case)\s*:\s*", re.I)


def _clean_q(q: str) -> str:
    q = _PREFIX.sub("", q.strip())
    return q[:1].upper() + q[1:]


def sub_questions(q: str) -> list[str]:
    """A compound bank question ("Why this role, and why community health after …? What happens at the end?")
    is rarely asked in one breath. Each sentence / clause becomes its own phrasing, so asking just one part
    still locks. Clauses with fewer than 3 content words are too generic to lock on and are skipped."""
    from .qa_bank import tokenize
    parts = [p.strip(" ,;:") for p in re.split(r"(?<=[?.!])\s+|:\s+", q) if p.strip()]
    subs = []
    for p in parts:
        if len(parts) > 1:
            subs.append(p)
        # "X, and why Y" → "why Y"
        subs += [c.strip() for c in re.split(r",\s*(?:and|or)\s+(?=(?:why|how|what|when|where|which|who)\b)", p)[1:]]
    return [x for x in dict.fromkeys(subs) if len(tokenize(x)) >= 3 and x.rstrip("?.") != q.rstrip("?.")]


def _first_words(text: str, n: int = 16) -> str:
    allsents = [x for x in re.split(r"(?<=[.!?])\s+", text.strip()) if x]
    sents = [x for x in allsents if not placeholders(x)] or [_BRACKET.sub("…", x) for x in allsents[:1]] or [text]
    key = sents[0]
    if len(key.split()) < 5 and len(sents) > 1:
        key = f"{key} {sents[1]}"
    words = key.split()
    return " ".join(words[:n]) + ("…" if len(words) > n else "")


def _one_line_code(code: str) -> list[str]:
    parts = [p for p in re.split(r"\n\s*\n", code) if p.strip()]
    return ["⌨ " + re.sub(r"\s+", " ", p).replace("( ", "(").replace(" )", ")").strip() for p in parts]


def merge(qs: dict[str, BankQ], ans: dict[str, BankA], enrich: dict | None = None) -> list[Entry]:
    enrich = enrich or {}
    ids = list(dict.fromkeys([*ans.keys(), *qs.keys()]))   # answer-document order, then questions without answers
    out = []
    for i in ids:
        q, a = qs.get(i), ans.get(i)
        if a is None or not a.prose and not a.code:
            continue                    # a question without an answer can't be an instant answer
        question = _clean_q(q.question if q else a.title)
        alts = []
        title = _clean_q(a.title)
        if q and title and title.rstrip("?.").lower() != question.rstrip("?.").lower():
            alts.append(title)
        alts += [x for x in sub_questions(question) if x.lower() not in {a.lower() for a in alts}]
        say = " ".join(p.replace("• ", "") if p.startswith("• ") else p for p in a.prose).strip()
        todo = placeholders(say)
        e = Entry(i, question, alts, _first_words(say), (q.listen if q else "") or
                  (a.notes[0] if a.notes else ""), [], say, q.stars if q else 0, todo)
        for c in a.code:
            e.points += _one_line_code(c)
        if q and q.listen and a.notes:
            e.points.append("💡 " + a.notes[0])
        ex = enrich.get(i)
        if ex and ex.get("fp") == e.fingerprint():
            e.alts += [x for x in ex.get("alts", []) if x and x.lower() not in {y.lower() for y in e.alts}]
            e.key = ex.get("key") or e.key
            e.points = [*ex.get("points", []), *e.points]
            e.flow = [str(x) for x in ex.get("flow", []) if str(x).strip()]
            if ex.get("impact"):
                e.points.append("💡 补一句影响 / add the impact: " + str(ex["impact"]))
        if todo:
            e.points.insert(0, "⚠ 待填 / fill in: " + "; ".join(f"[{t[:40]}]" for t in todo[:3]))
        out.append(e)
    return out


def to_markdown(entries: list[Entry], sources: list[str]) -> str:
    head = [f"<!-- Generated by `python -m copilot.bank build` from {', '.join(sources)} on "
            f"{datetime.now():%Y-%m-%d %H:%M}. Don't edit here — edit the source document and drop it in again "
            f"(your edits there are the single source of truth). -->", ""]
    body = []
    for e in entries:
        body.append(f"## Q: {e.question}")
        if e.alts:
            body.append("ALT: " + "; ".join(a.replace(";", ",") for a in e.alts))
        body.append(f"KEY: {e.key}")
        if e.zh:
            body.append(f"ZH: {e.zh}")
        if e.flow:
            body.append("FLOW:")
            body += [f"> {x}" for x in e.flow]
        body += [f"- {p}" for p in e.points]
        body.append(f"SAY: {e.say}")
        body.append(f"<!-- id: {e.id}{' · ' + '★' * e.stars if e.stars else ''} -->")
        body.append("")
    return "\n".join(head + body)


@dataclass
class BuildResult:
    path: Path
    entries: list[Entry]
    questions_only: list[str]        # ids in the bank without an answer
    sources: list[str]

    @property
    def todo(self) -> list[Entry]:
        return [e for e in self.entries if e.todo]

    def summary(self) -> str:
        s = f"{len(self.entries)} prepared answers → {self.path.name}"
        if self.questions_only:
            s += f"; {len(self.questions_only)} questions have no answer yet ({', '.join(self.questions_only[:6])}…)"
        if self.todo:
            s += (f"; ⚠ {len(self.todo)} still contain [placeholders] to fill in: "
                  + ", ".join(e.id for e in self.todo[:12]) + ("…" if len(self.todo) > 12 else ""))
        return s


def load_enrich(kdir: Path) -> dict:
    p = kdir / SRC_DIR / ENRICH_FILE
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def build(kdir: Path, questions: Path | None = None, answers: Path | None = None) -> BuildResult:
    """Convert (new or previously stored) sources into knowledge/qa.bank.md. New sources are copied into
    knowledge/bank/ first (the old copy is backed up), so dropping only an updated answers file later still
    pairs it with the question bank you dropped before."""
    from .loader import read_any
    src = kdir / SRC_DIR
    src.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    for kind, p in (("questions", questions), ("answers", answers)):
        if p is None:
            continue
        dest = src / f"{kind}{Path(p).suffix.lower() or '.md'}"
        for old in src.glob(f"{kind}.*"):
            if Path(p).resolve() != old.resolve():
                bdir = kdir / ".backup" / stamp
                bdir.mkdir(parents=True, exist_ok=True)
                shutil.move(str(old), str(bdir / f"bank-{old.name}"))
        if Path(p).resolve() != dest.resolve():
            shutil.copy2(p, dest)
    qf = next(iter(sorted(src.glob("questions.*"))), None)
    af = next(iter(sorted(src.glob("answers.*"))), None)
    qs = parse_questions(read_any(qf)) if qf else {}
    ans = parse_answers(read_any(af)) if af else {}
    entries = merge(qs, ans, load_enrich(kdir))
    out = kdir / BANK_FILE
    names = [f.name for f in (qf, af) if f]
    if entries:
        if out.exists():
            bdir = kdir / ".backup" / stamp
            bdir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(out, bdir / out.name)
        out.write_text(to_markdown(entries, names), encoding="utf-8")
    return BuildResult(out, entries, [i for i in qs if i not in ans], names)


# ---------------------------------------------------------------- self-check: lock rate + collisions

def check(kb, threshold: float) -> dict:
    """For every prepared entry, does each of its phrasings lock onto itself? Which phrasings lock onto a
    DIFFERENT entry (a wrong answer shown instantly — the worst failure)?"""
    ok, weak, wrong = 0, [], []
    for e in kb.qa.entries:
        for p in [e.question, *e.alts]:
            m = kb.qa.match(p)
            if m and m[0] is e and m[1] >= threshold:
                ok += 1
            elif m and m[0] is not e and m[1] >= threshold:
                wrong.append((p, e.question, m[0].question, m[1]))
            else:
                weak.append((p, e.question, m[1] if m else 0.0))
    return {"ok": ok, "weak": weak, "wrong": wrong}


# ---------------------------------------------------------------- impact audit

_WORK = re.compile(r"\b(?:I|we)\s+(?:\w+\s+)?(?:built|designed|developed|created|automated|migrated|implemented|"
                   r"rebuilt|wrote|set up|introduced|led|owned|delivered|launched|refactored|optimi[sz]ed|"
                   r"moved|replaced|redesigned|streamlined|used)\b", re.I)
_EFFECT = re.compile(r"\d+(?:\.\d+)?\s*(?:%|x\b|×|times|hours?|hrs?|minutes?|mins?|days?|weeks?|seconds?|k\b)"
                     r"|→|\bfrom\s+\S+.{0,40}?\bto\b|\b(?:cut|reduc\w*|sav\w*|faster|fewer|increas\w*|improv\w*|"
                     r"so that|which meant|meaning|as a result|result\w*|impact\w*|enabl\w*|allow\w*|no longer|"
                     r"stopped|downstream|adopt\w*|unblock\w*|on time|halved|doubled|eliminat\w*|instead of|"
                     r"\d{1,2}\s*(?:am|pm)|every (?:day|morning|week))\b", re.I)


def lacks_impact(answer: str) -> bool:
    """A prepared answer that describes work ("I built / automated / used …") but never says what it changed.
    Heuristic — it's a reminder list, not a grade."""
    from ..llm.layered_parser import parse_layers
    say = parse_layers(answer).get("say") or answer
    return bool(_WORK.search(say)) and not _EFFECT.search(say)


# ---------------------------------------------------------------- optional AI enrichment

ENRICH_TASK = """Below are prepared interview answers, each with an ID. For EACH one return:
- "alts": 4 different ways a live interviewer might actually SAY this question out loud (natural spoken
  English, varied wording, some short like "Tell me about X", one with a filler like "So, how would you…").
  Keep the meaning identical; don't merge in follow-up questions.
- "key": the core of the answer in at most 14 plain, spoken words, taken from the answer (no new facts). If the
  answer is about work the candidate did and states what it changed (faster, fewer errors, a team unblocked…),
  lead with that effect: "Cut X from A to B by …".
- "points": 3 talking points, max 12 words each, in plain spoken English, taken from the answer (keep numbers and
  names exact). If the answer states an effect on the wider system, one point is "Impact: …".
- "flow": 3–4 steps of the answer's line of thought IN CHINESE, in speaking order, each "中文（≤16字） | the 2–6
  English words needed to say that step" — so the candidate can answer in their own words instead of reading it.
  For work answers: 问题 → 做法（用了什么）→ 影响 → 联系岗位, when the answer contains those parts.
- "impact": "" if the answer already says what the work changed for the wider system, or it isn't about work;
  otherwise ONE short Chinese note (≤30字) for the candidate on what effect is missing (e.g. "没说对下游报表的影响：
  提前了多久？谁受益？") — a reminder to fill in, never a made-up fact.
Keep any [square-bracket placeholder] text as-is; never fill it in or invent facts.
Reply with ONLY a JSON object: {"<ID>": {"alts": [...], "key": "...", "points": [...], "flow": [...],
"impact": "..."}, ...}

"""


def _enrich_prompt(batch: list[Entry]) -> str:
    return ENRICH_TASK + "\n\n".join(f"ID: {e.id}\nQUESTION: {e.question}\nANSWER: {e.say[:2500]}" for e in batch)


def _parse_json(text: str) -> dict:
    m = re.search(r"\{.*\}", text, re.S)
    return json.loads(m.group(0)) if m else {}


async def enrich(cfg, kdir: Path, call=None, batch_size: int = 10, log=print) -> int:
    """Fill knowledge/bank/enrich.json for entries whose text changed since the last run; rebuild qa.bank.md.
    `call(prompt) -> str` is injectable for tests; default uses the Anthropic API with cfg.llm.prepare_model."""
    res = build(kdir)
    cache = load_enrich(kdir)
    todo = [e for e in res.entries
            if cache.get(e.id, {}).get("fp") != e.fingerprint() or not cache.get(e.id, {}).get("flow")
            or cache.get(e.id, {}).get("v", 1) < ENRICH_VERSION]
    if not todo:
        log("nothing to do — every answer is already enriched")
        return 0
    if call is None:
        import anthropic
        client = anthropic.AsyncAnthropic()

        async def call(prompt: str) -> str:
            r = await client.messages.create(model=cfg.llm.prepare_model, max_tokens=8000,
                                             messages=[{"role": "user", "content": prompt}])
            return "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
    # the text we enrich is the plain one (without previous enrichment)
    plain = {e.id: e for e in merge(parse_questions(_read(kdir, "questions")), parse_answers(_read(kdir, "answers")))}
    batches = [todo[i:i + batch_size] for i in range(0, len(todo), batch_size)]
    sem = asyncio.Semaphore(4)
    done = 0

    async def one(b):
        nonlocal done
        async with sem:
            try:
                data = _parse_json(await call(_enrich_prompt([plain.get(e.id, e) for e in b])))
            except Exception as ex:
                log(f"  batch {b[0].id}…{b[-1].id} failed: {ex}")
                return
        for e in b:
            d = data.get(e.id)
            if isinstance(d, dict):
                cache[e.id] = {"fp": e.fingerprint(),
                               "alts": [str(x) for x in d.get("alts", [])][:6],
                               "key": str(d.get("key", ""))[:160],
                               "points": [str(x) for x in d.get("points", [])][:4],
                               "flow": [str(x) for x in d.get("flow", [])][:6],
                               "impact": str(d.get("impact", "") or "")[:80], "v": ENRICH_VERSION}
                done += 1
        log(f"  enriched {done}/{len(todo)}")
    await asyncio.gather(*(one(b) for b in batches))
    p = kdir / SRC_DIR / ENRICH_FILE
    p.write_text(json.dumps(cache, ensure_ascii=False, indent=1), encoding="utf-8")
    build(kdir)
    return done


def _read(kdir: Path, kind: str) -> str:
    from .loader import read_any
    f = next(iter(sorted((kdir / SRC_DIR).glob(f"{kind}.*"))), None)
    return read_any(f) if f else ""


# ---------------------------------------------------------------- CLI

def main(argv=None) -> int:
    from ..config import load_config, load_dotenv
    from .loader import load_knowledge, read_any

    ap = argparse.ArgumentParser(prog="python -m copilot.bank", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="config.yaml" if Path("config.yaml").exists() else None)
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="convert question bank / answers documents")
    b.add_argument("files", nargs="*", help="the question bank and/or reference answers (.md/.txt/.docx/.pdf)")
    sub.add_parser("check", help="which prepared questions lock instantly, and which collide")
    sub.add_parser("enrich", help="AI adds spoken ALT phrasings + KEY + points (needs ANTHROPIC_API_KEY)")
    a = ap.parse_args(argv)
    cfg = load_config(a.config)
    kdir = cfg.path(cfg.knowledge.dir)
    if a.cmd == "build":
        q = an = None
        for f in map(Path, a.files):
            kind = detect(read_any(f))
            if kind == "questions":
                q = f
            elif kind == "answers":
                an = f
            else:
                print(f"· {f.name}: not an ID-keyed question bank or answer document")
        res = build(kdir, q, an)
        print(("✅ " if res.entries else "❌ ") + res.summary())
        return 0 if res.entries else 1
    if a.cmd == "enrich":
        load_dotenv(Path(cfg.base_dir) / ".env")
        n = asyncio.run(enrich(cfg, kdir))
        print(f"✅ enriched {n} answers → {BANK_FILE}. Run `python -m copilot.bank check` to see the effect.")
        return 0
    kb = load_knowledge(cfg)
    r = check(kb, cfg.engine.instant_lock_threshold)
    total = r["ok"] + len(r["weak"]) + len(r["wrong"])
    print(f"{len(kb.qa.entries)} prepared answers, {total} phrasings: {r['ok']} lock onto the right answer, "
          f"{len(r['weak'])} too weak to lock, {len(r['wrong'])} lock onto a DIFFERENT answer")
    for p, own, other, s in r["wrong"][:20]:
        print(f"  ✗ “{p}” → {other!r} ({s:.2f}), should be {own!r}")
    for p, own, s in r["weak"][:20]:
        print(f"  · “{p}” ({s:.2f})")
    unfilled = [e for e in kb.qa.entries if placeholders(e.answer) and e.source != BANK_FILE]
    if unfilled:
        print(f"\n{len(unfilled)} answers still have [brackets] to fill in (they're never said aloud):")
        for e in unfilled[:40]:
            print(f"  ◦ {e.question[:90]}  ({e.source})")
    thin = [e for e in kb.qa.entries if lacks_impact(e.answer)]
    if thin:
        print(f"\n{len(thin)} answers talk about your work but never say what it changed for the whole system "
              "(技术 → 做了什么 → 影响). Add one sentence of impact to each (before → after, who downstream benefited):")
        for e in thin[:40]:
            tag = e.meta.get("id") or e.source
            print(f"  ◦ {e.question[:90]}" + (f"  [{tag}]" if tag else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
