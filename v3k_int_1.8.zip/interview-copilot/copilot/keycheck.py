#!/usr/bin/env python3
"""Check API keys on their own — no audio, no UI, no copilot code needed.

    python scripts/check_keys.py                 # every key found  (same as: python -m copilot.keycheck)
    python scripts/check_keys.py --only openai   # just one provider
    python scripts/check_keys.py --no-realtime   # skip the OpenAI realtime-transcription probe

For each provider it shows WHICH key the copilot will actually use (shell environment wins over .env —
a stale `export OPENAI_API_KEY=...` in ~/.zshrc silently overrides the one in .env), spots formatting
problems (quotes, spaces, placeholders), and calls a free endpoint:

  OpenAI     GET  /v1/models                        (+ realtime transcription session, as the copilot opens it)
  Anthropic  POST /v1/messages/count_tokens         (free)
  Deepgram   GET  /v1/projects                      (free)

Keys are never printed in full — only the first 7 and last 4 characters.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
import unicodedata
import urllib.error
import urllib.request
from pathlib import Path

PROVIDERS = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "deepgram": "DEEPGRAM_API_KEY",
}
REALTIME_URLS = [
    "wss://api.openai.com/v1/realtime?intent=transcription",
    "wss://api.openai.com/v1/realtime?model=gpt-live-transcribe",
]
OK, WARN, FAIL = "✅", "⚠️ ", "❌"


def tool_env_path() -> Path:
    """The .env the copilot actually loads: next to config.yaml if one is in the current folder, else ./.env."""
    return (Path("config.yaml").resolve().parent if Path("config.yaml").exists() else Path.cwd()) / ".env"


def hidden_chars(v: str) -> list[str]:
    out = []
    for i, ch in enumerate(v):
        if not (33 <= ord(ch) <= 126):
            name = unicodedata.name(ch, "control character")
            out.append(f"position {i + 1}: U+{ord(ch):04X} {name}")
    return out


def audit_env_file(path: Path) -> tuple[list[tuple[str, str]], dict[str, list[tuple[int, str]]]]:
    """File-level problems + every occurrence of every key (line number, raw value)."""
    notes: list[tuple[str, str]] = []
    occ: dict[str, list[tuple[int, str]]] = {}
    if not path.exists():
        near = [p.name for p in path.parent.glob(".env*") if p.name != ".env.example"]
        near += [p.name for p in path.parent.glob("env*")]
        notes.append((FAIL, f"{path} does not exist" + (f" — but found {', '.join(near)}. TextEdit often saves as "
                                                          f".env.txt / .env.rtf: rename it to exactly .env" if near else "")))
        return notes, occ
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        notes.append((WARN, "file starts with a UTF-8 BOM (the copilot now ignores it; older versions misread line 1)"))
    if raw.lstrip().startswith(b"{\\rtf"):
        notes.append((FAIL, "file is RICH TEXT (saved by TextEdit), not plain text — re-create it: in TextEdit use "
                            "Format → Make Plain Text, or `nano .env`"))
    if b"\r\n" in raw:
        notes.append((WARN, "Windows line endings (CRLF) — harmless for the copilot"))
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        notes.append((FAIL, "file is not UTF-8 text"))
        return notes, occ
    for n, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if s.startswith("export "):
            s = s[7:].strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, v = s.split("=", 1)
        occ.setdefault(k.strip(), []).append((n, v.strip()))
    return notes, occ


def mask(k: str) -> str:
    return f"{k[:7]}…{k[-4:]} (len {len(k)})" if len(k) > 12 else f"(len {len(k)})"


# what each provider's keys look like, and what other providers' keys look like (to catch keys in the wrong slot)


def read_dotenv(path: Path) -> dict[str, str]:
    """Raw values (after '=') so formatting problems stay visible; clean() applies the copilot's parsing."""
    out = {}
    if not path.exists():
        return out
    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        return out
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("export "):
            s = s[7:].strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, v = s.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def clean(raw: str) -> str:
    """Same rules as copilot.config.parse_env_value: quotes kept whole, unquoted values end at ' #'."""
    v = raw.strip()
    if v[:1] in ("'", '"'):
        end = v.find(v[0], 1)
        return v[1:end] if end != -1 else v[1:]
    m = re.search(r"\s#", v)
    return (v[:m.start()] if m else v).strip()


def resolve(var: str, dotenv: dict[str, str], provider: str = "") -> tuple[str, list[tuple[str, str]]]:
    """Return (effective key, notes). Mirrors the copilot: shell env first, then .env (setdefault)."""
    notes = []
    shell = os.environ.get(var)
    raw_file = dotenv.get(var)
    file_val = clean(raw_file) if raw_file is not None else None
    if raw_file is not None and raw_file.strip()[:1] in "\"'":
        notes.append((WARN, ".env value is wrapped in quotes (the copilot strips them, other tools may not)"))
    if raw_file is not None and re.search(r"\s#", raw_file) and raw_file.strip()[:1] not in "\"'":
        notes.append((WARN, "an inline '# comment' follows the key in .env — ignored now, but safer on its own line"))
    if shell is not None and file_val is not None and clean(shell) != file_val:
        notes.append((FAIL, f"shell environment has a DIFFERENT {var} ({mask(clean(shell))}) — it overrides .env "
                            f"({mask(file_val)}). Run `unset {var}` or remove the export from ~/.zshrc"))
    eff = clean(shell) if shell is not None else (file_val or "")
    src = "shell environment" if shell is not None else (".env" if file_val else "not set")
    if eff:
        notes.insert(0, ("  ", f"using {mask(eff)} from {src}"))
        hid = hidden_chars(eff)
        if hid:
            notes.append((FAIL, "key contains invisible / non-ASCII characters (typically from copying out of a web "
                                "page, chat app or TextEdit) — " + "; ".join(hid[:3])
                                + (f" (+{len(hid) - 3} more)" if len(hid) > 3 else "") + ". Re-type or re-copy it"))
        if "..." in eff or eff.endswith("…") or eff in ("sk-", "sk-ant-"):
            notes.append((FAIL, "looks like the placeholder from .env.example, not a real key"))
        # which provider does the key text itself look like? (prefix may sit behind leftover placeholder chars)
        looks = None
        for pre, who in (("sk-ant-", "anthropic"), ("sk-proj-", "openai"), ("sk-svcacct-", "openai"),
                         ("gsk_", "groq"), ("sk-", "openai")):
            i = eff.find(pre)
            if 0 <= i <= 3:
                looks = (who, pre, i)
                break
        if looks:
            who, pre, i = looks
            if who != provider and provider in ("openai", "anthropic"):
                nice = {"openai": "an OpenAI", "anthropic": "an Anthropic", "groq": "a Groq"}
                notes.append((FAIL, f"this is {nice.get(who, who)} key ({pre}…), not {nice.get(provider, provider)} "
                                    f"key — wrong line in .env"))
            elif i > 0:
                notes.append((FAIL, f"{i} extra character(s) '{eff[:i]}' BEFORE the key — delete them so the value "
                                    f"starts with {pre} (usually left over from the '{pre[:3]}...' placeholder)"))
        if provider == "anthropic" and eff.startswith("sk-ant-admin"):
            notes.append((FAIL, "this is an Anthropic ADMIN key — it can't call models. Create a normal API key "
                                "(starts with sk-ant-api03-)"))
    return eff, notes


def http(method: str, url: str, headers: dict, body: dict | None = None, timeout: float = 15):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={**headers, "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:  # DNS / proxy / TLS
        return None, f"{e.__class__.__name__}: {e}"


def err_message(body: str) -> str:
    try:
        j = json.loads(body)
        e = j.get("error", j)
        if isinstance(e, dict):
            return f"{e.get('type') or e.get('code') or ''}: {e.get('message') or e.get('err_msg') or ''}".strip(": ")
        return str(e)[:200]
    except Exception:
        return body[:200]


def check_openai(key: str) -> list[tuple[str, str]]:
    code, body = http("GET", "https://api.openai.com/v1/models", {"Authorization": f"Bearer {key}"})
    if code == 200:
        ids = {m.get("id") for m in json.loads(body).get("data", [])}
        wanted = [m for m in ("gpt-live-transcribe", "gpt-transcribe", "gpt-4o-transcribe", "gpt-4o-mini") if m in ids]
        return [(OK, f"key accepted (GET /v1/models → 200); relevant models visible: {', '.join(wanted) or 'none listed'}")]
    if code is None:
        return [(FAIL, f"could not reach api.openai.com — network/proxy problem, not the key: {body}")]
    hint = {401: "key invalid, revoked, or from a deleted project", 403: "key valid but not allowed (org/project/region)",
            429: "key valid but out of quota / rate-limited — check billing"}.get(code, "")
    return [(FAIL, f"HTTP {code} {err_message(body)}" + (f" → {hint}" if hint else ""))]


async def check_openai_realtime(key: str, model: str = "gpt-live-transcribe") -> list[tuple[str, str]]:
    try:
        import websockets
    except ImportError:
        return [(WARN, "realtime probe skipped: `pip install websockets`")]
    headers = {"Authorization": f"Bearer {key}"}
    update = {"type": "session.update", "session": {"type": "transcription", "audio": {"input": {
        "format": {"type": "audio/pcm", "rate": 24000}, "transcription": {"model": model, "language": "en"},
        "turn_detection": None}}}}
    out = []
    for url in REALTIME_URLS:
        try:
            try:
                ws = await asyncio.wait_for(websockets.connect(url, additional_headers=headers), 10)
            except TypeError:
                ws = await asyncio.wait_for(websockets.connect(url, extra_headers=headers), 10)
        except Exception as e:
            out.append((WARN, f"{url.split('?')[-1]}: handshake failed — {e.__class__.__name__}: {str(e)[:120]}"))
            continue
        try:
            await ws.send(json.dumps(update))
            while True:
                msg = json.loads(await asyncio.wait_for(ws.recv(), 8))
                t = msg.get("type", "")
                if t == "error":
                    out.append((FAIL, f"{url.split('?')[-1]}: server error — {err_message(json.dumps(msg))}"))
                    return out
                if t.endswith("session.updated"):
                    out.append((OK, f"realtime transcription session OK with {model} ({url.split('?')[-1]}) — "
                                    f"set asr.openai_realtime.url to {url} if it isn't already"))
                    return out
                # session.created etc. — keep reading
        except Exception as e:
            reason = getattr(getattr(e, "rcvd", None), "reason", "") or str(e)
            out.append((FAIL, f"{url.split('?')[-1]}: connection closed — {reason[:160]}"))
            return out
        finally:
            await ws.close()
    return out or [(FAIL, "realtime probe: no URL worked")]


def check_anthropic(key: str, model: str = "claude-haiku-4-5-20251001") -> list[tuple[str, str]]:
    code, body = http("POST", "https://api.anthropic.com/v1/messages/count_tokens",
                      {"x-api-key": key, "anthropic-version": "2023-06-01"},
                      {"model": model, "messages": [{"role": "user", "content": "ping"}]})
    if code == 200:
        return [(OK, f"key accepted (count_tokens with {model} → 200, free call)")]
    if code is None:
        return [(FAIL, f"could not reach api.anthropic.com — network/proxy problem: {body}")]
    hint = {401: "key invalid or revoked", 403: "key not allowed for this model/workspace",
            404: f"model {model} not available to this key", 429: "rate-limited / out of credit"}.get(code, "")
    return [(FAIL, f"HTTP {code} {err_message(body)}" + (f" → {hint}" if hint else ""))]


def check_deepgram(key: str) -> list[tuple[str, str]]:
    code, body = http("GET", "https://api.deepgram.com/v1/projects", {"Authorization": f"Token {key}"})
    if code == 200:
        return [(OK, "key accepted (GET /v1/projects → 200)")]
    if code is None:
        return [(FAIL, f"could not reach api.deepgram.com — network/proxy problem: {body}")]
    return [(FAIL, f"HTTP {code} {err_message(body)}" + (" → key invalid or revoked" if code in (401, 403) else ""))]


BLOCKING = ("invisible", "placeholder", "wrong line", "BEFORE the key", "ADMIN")


def quick_status(env_path: Path) -> dict[str, tuple[str, str]]:
    """Instant, offline: for each provider → (icon, one-line reason). Used by the launcher."""
    dotenv = read_dotenv(env_path)
    out = {}
    for name, var in PROVIDERS.items():
        key, notes = resolve(var, dotenv, name)
        if not key:
            out[name] = ("—", "not set")
            continue
        fails = [m for s, m in notes if s == FAIL]
        out[name] = (FAIL, fails[0]) if fails else ("✓", f"{mask(key)} — format OK, not tested yet")
    return out


def full_check(env_path: Path, names: list[str] | None = None, realtime: bool = True) -> dict[str, list]:
    """Network check (free endpoints). Returns provider → [(status, message)]."""
    dotenv = read_dotenv(env_path)
    out: dict[str, list] = {}
    for name, var in PROVIDERS.items():
        if names and name not in names:
            continue
        key, notes = resolve(var, dotenv, name)
        if not key:
            out[name] = [("—", "not set")]
            continue
        results = [n for n in notes if n[0] != "  "]
        if not any(s == FAIL for s, m in notes if any(w in m for w in BLOCKING)):
            if name == "openai":
                results += check_openai(key)
                if realtime and any(s == OK for s, _ in results):
                    results += asyncio.run(check_openai_realtime(key))
            elif name == "anthropic":
                results += check_anthropic(key)
            else:
                results += check_deepgram(key)
        out[name] = results
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", choices=list(PROVIDERS))
    ap.add_argument("--env", default=None, help="path to .env (default: the one the copilot loads)")
    ap.add_argument("--no-realtime", action="store_true")
    a = ap.parse_args(argv)

    env_path = Path(a.env) if a.env else tool_env_path()
    dotenv = read_dotenv(env_path)
    failed = False
    print(f".env the copilot loads: {env_path.resolve()} ({'found' if env_path.exists() else 'NOT FOUND'})")
    if Path("config.yaml").exists():
        print(f"  (because config.yaml is in {Path.cwd()} — run the copilot from this same folder)")
    file_notes, occ = audit_env_file(env_path)
    for s_, m_ in file_notes:
        print(f"   {s_} {m_}")
        failed |= s_ == FAIL
    for var in PROVIDERS.values():
        lines = occ.get(var, [])
        if len(lines) > 1:
            print(f"   {WARN} {var} appears {len(lines)} times (lines {', '.join(str(n) for n, _ in lines)}): "
                  f"the copilot uses the LAST one (line {lines[-1][0]}, {mask(clean(lines[-1][1]))}); versions before "
                  f"this fix used the FIRST (line {lines[0][0]}, {mask(clean(lines[0][1]))}). Delete the extra lines.")
    print()
    for name, var in PROVIDERS.items():
        if a.only and name != a.only:
            continue
        key, notes = resolve(var, dotenv, name)
        print(f"── {name} ({var})")
        if not key:
            print(f"   ·  not set — skipped{' (needed only if you use ' + name + ')' if name != 'anthropic' else ''}\n")
            continue
        results = list(notes)
        if not any(s == FAIL for s, _ in notes if any(w in _ for w in BLOCKING)):
            if name == "openai":
                results += check_openai(key)
                if not a.no_realtime and any(s == OK for s, _ in results):
                    results += asyncio.run(check_openai_realtime(key))
            elif name == "anthropic":
                results += check_anthropic(key)
            else:
                results += check_deepgram(key)
        for s, msg in results:
            print(f"   {s} {msg}")
        failed |= any(s == FAIL for s, _ in results)
        print()
    print("All checked keys work." if not failed else "Fix the ❌ lines above, then re-run.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
