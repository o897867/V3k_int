"""Windows: capture the meeting by recording what the speakers play (WASAPI loopback) — no virtual driver.

Uses PyAudioWPatch (a PyAudio build with WASAPI loopback, Windows wheels on PyPI). Teams / Meet / Zoom play the
interviewer's voice on your output device; its loopback twin delivers exactly that audio, whatever headset you use.

    audio.device: loopback          → the current default speakers / headset (what you normally want)
    audio.device: "Headphones"      → the loopback of an output device whose name contains that text

WASAPI delivers no packets while nothing is playing. The recognisers need time to keep moving to notice that the
interviewer has stopped, so silence is filled in with zeros for exactly as long as the gap lasted.
"""
from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path
from typing import AsyncIterator

import numpy as np

from .audio import WavTee, resample_to_16k_mono

log = logging.getLogger(__name__)
LOOPBACK_ALIASES = {"loopback", "speakers", "default", "default output", "system", "system audio", ""}


def _pa():
    try:
        import pyaudiowpatch as pyaudio
    except ImportError as e:  # pragma: no cover - only on a Windows install without the package
        raise RuntimeError("Windows meeting audio needs PyAudioWPatch — run install.bat again "
                           "(or: .venv\\Scripts\\pip install PyAudioWPatch)") from e
    return pyaudio


def list_loopback_devices() -> list[dict]:
    pyaudio = _pa()
    p = pyaudio.PyAudio()
    try:
        out = []
        for d in p.get_loopback_device_info_generator():
            out.append({"index": d["index"], "name": d["name"], "channels": int(d["maxInputChannels"]),
                        "rate": int(d["defaultSampleRate"])})
        return out
    finally:
        p.terminate()


def default_loopback(p) -> dict:
    """The loopback twin of the default WASAPI output device."""
    pyaudio = _pa()
    if hasattr(p, "get_default_wasapi_loopback"):
        try:
            return p.get_default_wasapi_loopback()
        except Exception:
            pass
    info = p.get_host_api_info_by_type(pyaudio.paWASAPI)
    spk = p.get_device_info_by_index(info["defaultOutputDevice"])
    if spk.get("isLoopbackDevice"):
        return spk
    for lb in p.get_loopback_device_info_generator():
        if spk["name"] in lb["name"]:
            return lb
    raise RuntimeError(f"No loopback device for your speakers ({spk['name']}). Is an audio output device enabled?")


def find_loopback(p, name: str) -> dict:
    if name.strip().lower() in LOOPBACK_ALIASES:
        return default_loopback(p)
    devs = list(p.get_loopback_device_info_generator())
    for d in devs:
        if name.lower() in d["name"].lower():
            return d
    names = ", ".join(d["name"] for d in devs) or "(none)"
    raise RuntimeError(f"No output device containing '{name}'. Available: {names}. Use audio.device: loopback "
                       "for your default speakers / headset.")


def is_loopback_name(name: str) -> bool:
    return (name or "").strip().lower() in LOOPBACK_ALIASES


class LoopbackCapture:
    """Same interface as AudioCapture: async chunks() of 16 kHz mono int16 bytes, .level, .paused."""

    def __init__(self, device: str = "loopback", block_ms: int = 50, target_rate: int = 16000,
                 record_path: Path | None = None, on_warning=None):
        self.device_name = device or "loopback"
        self.block_ms = block_ms
        self.target_rate = target_rate
        self.record_path = record_path
        self.on_warning = on_warning
        self.paused = False
        self.level = 0.0
        self.device_label = self.device_name
        self.is_mic = False
        self._stream = None
        self._pa = None

    async def chunks(self) -> AsyncIterator[bytes]:
        pyaudio = _pa()
        self._pa = p = pyaudio.PyAudio()
        dev = find_loopback(p, self.device_name)
        rate, ch = int(dev["defaultSampleRate"]), max(1, int(dev["maxInputChannels"]))
        self.device_label = dev["name"]
        log.info("audio input: [%d] %s (%d Hz, %d ch) — Windows loopback", dev["index"], dev["name"], rate, ch)
        loop = asyncio.get_running_loop()
        q: asyncio.Queue[bytes] = asyncio.Queue(maxsize=400)

        def cb(in_data, frame_count, time_info, status):  # PortAudio thread
            if not self.paused and in_data:
                x = np.frombuffer(in_data, dtype=np.int16).astype(np.float32) / 32768.0
                x = x.reshape(-1, ch) if ch > 1 and len(x) % ch == 0 else x
                pcm = resample_to_16k_mono(x, rate, self.target_rate)
                self.level = float(np.sqrt(np.mean((pcm.astype(np.float32) / 32768) ** 2))) if len(pcm) else 0.0
                data = pcm.tobytes()

                def put():
                    if q.full():
                        q.get_nowait()
                    q.put_nowait(data)
                loop.call_soon_threadsafe(put)
            return (None, pyaudio.paContinue)

        self._stream = p.open(format=pyaudio.paInt16, channels=ch, rate=rate, input=True,
                              input_device_index=dev["index"], frames_per_buffer=int(rate * self.block_ms / 1000),
                              stream_callback=cb)
        self._stream.start_stream()
        tee = WavTee(self.record_path, self.target_rate) if self.record_path else None
        block = int(self.target_rate * self.block_ms / 1000)
        try:
            async for data in _fill_silence(q, block, self.target_rate, self.block_ms):
                if tee:
                    tee.write(data)
                yield data
        finally:
            try:
                self._stream.stop_stream()
                self._stream.close()
            finally:
                p.terminate()
                if tee:
                    tee.close()


async def _fill_silence(q: asyncio.Queue, block: int, rate: int, block_ms: int) -> AsyncIterator[bytes]:
    """Yield real chunks as they arrive; when none arrive (nothing playing), yield zeros covering the gap."""
    last = time.monotonic()
    wait = block_ms / 1000 * 2
    while True:
        try:
            data = await asyncio.wait_for(q.get(), timeout=wait)
            last = time.monotonic()
            yield data
        except asyncio.TimeoutError:
            now = time.monotonic()
            n = int((now - last) * rate)
            last = now
            while n > 0:
                k = min(n, block)
                yield bytes(2 * k)
                n -= k
