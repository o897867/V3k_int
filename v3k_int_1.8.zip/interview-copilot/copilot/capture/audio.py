"""Capture layer: system audio → 16 kHz mono int16 chunks on an asyncio queue.

On macOS the meeting audio (Google Meet / Teams / Zoom) is routed into the
virtual device "BlackHole 2ch" via a Multi-Output Device, so we simply open
BlackHole as an *input* here. See README §2 for the one-time routing setup.
"""
from __future__ import annotations

import asyncio
import logging
import time
import wave
from pathlib import Path
from typing import AsyncIterator

import numpy as np

log = logging.getLogger(__name__)


def list_input_devices() -> list[dict]:
    import sounddevice as sd  # lazy: needs PortAudio

    out = []
    for i, d in enumerate(sd.query_devices()):
        if d["max_input_channels"] > 0:
            out.append({"index": i, "name": d["name"], "channels": d["max_input_channels"],
                        "rate": int(d["default_samplerate"])})
    return out


LOOPBACK_HINTS = ("blackhole", "loopback", "soundflower", "multi-output", "aggregate", "zoomaudio", "teams audio",
                  "background music", "virtual")
MIC_ALIASES = {"mic", "microphone", "default", "system default", "default microphone"}


def is_loopback(name: str) -> bool:
    n = name.lower()
    return any(h in n for h in LOOPBACK_HINTS)


def pick_microphone(devs: list[dict], default_index: int | None) -> dict | None:
    """The real microphone: macOS default input unless that's a loopback device, else the built-in /
    first real mic. Pure function (unit-tested)."""
    real = [d for d in devs if not is_loopback(d["name"])]
    if not real:
        return None
    for d in real:
        if d["index"] == default_index:
            return d
    for hint in ("macbook", "built-in", "microphone", "airpods", "headset", "usb"):
        for d in real:
            if hint in d["name"].lower():
                return d
    return real[0]


def _default_input_index() -> int | None:
    try:
        import sounddevice as sd
        idx = sd.default.device[0]
        return int(idx) if idx is not None and int(idx) >= 0 else None
    except Exception:
        return None


def find_device(name_substring: str) -> dict:
    devs = list_input_devices()
    if name_substring.strip().lower() in MIC_ALIASES:
        d = pick_microphone(devs, _default_input_index())
        if d:
            return d
        raise RuntimeError("No microphone found. Available inputs: "
                           + (", ".join(x["name"] for x in devs) or "(none)"))
    for d in devs:
        if name_substring.lower() in d["name"].lower():
            return d
    names = ", ".join(d["name"] for d in devs) or "(none)"
    raise RuntimeError(
        f"Input device containing '{name_substring}' not found. Available inputs: {names}. "
        "Install BlackHole (brew install blackhole-2ch) and see README §2."
    )


def resample_to_16k_mono(block: np.ndarray, src_rate: int, dst_rate: int = 16000) -> np.ndarray:
    """float32 [frames, ch] → int16 mono at dst_rate. Cheap, good enough for speech."""
    x = block.astype(np.float32)
    if x.ndim == 2:
        x = x.mean(axis=1)
    if src_rate != dst_rate:
        ratio = src_rate / dst_rate
        if abs(ratio - round(ratio)) < 1e-6 and ratio >= 1:
            k = int(round(ratio))
            n = (len(x) // k) * k
            x = x[:n].reshape(-1, k).mean(axis=1)  # box-filter decimation (acts as a low-pass)
        else:
            n_out = int(round(len(x) / ratio))
            if n_out <= 0:
                return np.zeros(0, dtype=np.int16)
            x = np.interp(np.linspace(0, len(x) - 1, n_out), np.arange(len(x)), x)
    return (np.clip(x, -1.0, 1.0) * 32767).astype(np.int16)


class MicWatch:
    """A real microphone never delivers exact digital silence. If it does for 3 s, macOS has denied
    microphone access to the app that launched us (Terminal / iTerm / Python). Also flags a very quiet mic."""

    DENIED_MAC = ("🎤 The microphone delivers pure silence — macOS is probably blocking it. System Settings → "
                  "Privacy & Security → Microphone → turn on Terminal (or the app you started this from), then "
                  "restart the copilot.")
    DENIED_WIN = ("🎤 The microphone delivers pure silence — Windows is probably blocking it. Settings → Privacy & "
                  "security → Microphone → turn on 'Let desktop apps access your microphone', then restart the "
                  "copilot.")
    QUIET_MAC = ("🎤 Your microphone is very quiet — move closer or raise Input volume in System Settings → Sound → "
                 "Input.")
    QUIET_WIN = ("🎤 Your microphone is very quiet — move closer or raise its volume in Settings → System → Sound → "
                 "Input.")

    @property
    def DENIED(self) -> str:
        from ..oscompat import IS_WIN
        return self.DENIED_WIN if IS_WIN else self.DENIED_MAC

    @property
    def QUIET(self) -> str:
        from ..oscompat import IS_WIN
        return self.QUIET_WIN if IS_WIN else self.QUIET_MAC

    def __init__(self, rate: int = 16000, zero_s: float = 3.0, quiet_s: float = 20.0):
        self.rate, self.zero_s, self.quiet_s = rate, zero_s, quiet_s
        self.zero_run = 0
        self.seen = 0
        self.peak = 0
        self.warned: set[str] = set()

    def feed(self, data: bytes) -> str | None:
        x = np.frombuffer(data, dtype=np.int16)
        self.seen += len(x)
        if len(x) and not x.any():
            self.zero_run += len(x)
        else:
            self.zero_run = 0
        if len(x):
            self.peak = max(self.peak, int(np.abs(x.astype(np.int32)).max()))
        if self.zero_run >= self.zero_s * self.rate and "denied" not in self.warned:
            self.warned.add("denied")
            return self.DENIED
        if (self.seen >= self.quiet_s * self.rate and self.peak < 1000 and self.peak > 0
                and "quiet" not in self.warned):
            self.warned.add("quiet")
            return self.QUIET
        return None


class WavTee:
    """Appends 16 kHz mono int16 chunks to a WAV file (for test recordings). Safe to close twice."""

    def __init__(self, path: Path, rate: int = 16000):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self._w = wave.open(str(path), "wb")
        self._w.setnchannels(1)
        self._w.setsampwidth(2)
        self._w.setframerate(rate)

    def write(self, data: bytes) -> None:
        if self._w is not None:
            self._w.writeframes(data)

    def close(self) -> None:
        if self._w is not None:
            self._w.close()
            self._w = None


class AudioCapture:
    """Opens an input device with sounddevice and yields 16 kHz int16 byte chunks.
    record_path: also save exactly what the recogniser hears to a WAV (test calls only — ask consent)."""

    def __init__(self, device: str, block_ms: int = 50, target_rate: int = 16000, record_path: Path | None = None,
                 on_warning=None):
        self.device_name = device
        self.on_warning = on_warning  # called (from the asyncio thread) with a user-facing problem
        self.device_label = device
        self.is_mic = False
        self.block_ms = block_ms
        self.target_rate = target_rate
        self.record_path = record_path
        self.paused = False
        self._stream = None
        self.level = 0.0  # last RMS (0..1), for the UI meter

    async def chunks(self) -> AsyncIterator[bytes]:
        import sounddevice as sd

        dev = find_device(self.device_name)
        rate = dev["rate"]
        self.device_label = dev["name"]
        self.is_mic = not is_loopback(dev["name"])
        log.info("audio input: [%d] %s (%d Hz)%s", dev["index"], dev["name"], rate,
                 " — microphone" if self.is_mic else "")
        loop = asyncio.get_running_loop()
        q: asyncio.Queue[bytes] = asyncio.Queue(maxsize=400)

        def cb(indata, frames, time_info, status):  # PortAudio thread
            if self.paused:
                return
            pcm = resample_to_16k_mono(indata, rate, self.target_rate)
            self.level = float(np.sqrt(np.mean((pcm.astype(np.float32) / 32768) ** 2))) if len(pcm) else 0.0
            data = pcm.tobytes()

            def put():
                if q.full():  # never block the audio thread; drop oldest
                    q.get_nowait()
                q.put_nowait(data)

            loop.call_soon_threadsafe(put)

        self._stream = sd.InputStream(
            device=dev["index"], channels=min(2, dev["channels"]), samplerate=rate,
            blocksize=int(rate * self.block_ms / 1000), dtype="float32", callback=cb,
        )
        self._stream.start()
        tee = WavTee(self.record_path, self.target_rate) if self.record_path else None
        watch = MicWatch(self.target_rate) if self.is_mic else None
        try:
            while True:
                data = await q.get()
                if tee:
                    tee.write(data)
                if watch:
                    msg = watch.feed(data)
                    if msg and self.on_warning:
                        self.on_warning(msg)
                yield data
        finally:
            self._stream.stop()
            self._stream.close()
            if tee:
                tee.close()


class WavReplay:
    """Feeds a WAV file in real time — for testing the full pipeline without a meeting."""

    def __init__(self, path: str, block_ms: int = 50, speed: float = 1.0, tail_silence_s: float = 2.0):
        self.path, self.block_ms, self.speed, self.tail = path, block_ms, speed, tail_silence_s
        self.paused = False
        self.level = 0.0
        self.t0: float | None = None  # monotonic time the first sample was released (for latency probes)

    async def chunks(self) -> AsyncIterator[bytes]:
        with wave.open(self.path, "rb") as w:
            rate, ch, sw = w.getframerate(), w.getnchannels(), w.getsampwidth()
            raw = w.readframes(w.getnframes())
        if sw != 2:
            raise RuntimeError("WAV must be 16-bit PCM")
        x = np.frombuffer(raw, dtype=np.int16).reshape(-1, ch).astype(np.float32) / 32768
        pcm = resample_to_16k_mono(x, rate)
        pcm = np.concatenate([pcm, np.zeros(int(16000 * self.tail), dtype=np.int16)])
        step = int(16000 * self.block_ms / 1000)
        t0 = self.t0 = time.monotonic()
        for i in range(0, len(pcm), step):
            target = t0 + (i / 16000) / self.speed
            delay = target - time.monotonic()
            if delay > 0:
                await asyncio.sleep(delay)
            yield pcm[i:i + step].tobytes()
