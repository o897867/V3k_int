from .audio import AudioCapture, WavReplay, resample_to_16k_mono, list_input_devices, find_device  # noqa: F401


def open_capture(device: str, block_ms: int = 50, target_rate: int = 16000, record_path=None, on_warning=None):
    """The right capture for this OS and device name.
    Windows: 'loopback' (or an output-device name) → WASAPI loopback of the speakers; a microphone name / 'mic'
    / an input device such as a VB-Cable 'CABLE Output' → the normal input path. macOS: always the input path
    (BlackHole or a microphone)."""
    from .. import oscompat
    if oscompat.IS_WIN:
        from .audio import MIC_ALIASES
        from .wasapi import LoopbackCapture, is_loopback_name
        name = (device or "").strip()
        if is_loopback_name(name) or (name.lower() not in MIC_ALIASES and not _is_input_device(name)):
            return LoopbackCapture(name or "loopback", block_ms, target_rate, record_path, on_warning)
    return AudioCapture(device, block_ms, target_rate, record_path=record_path, on_warning=on_warning)


def describe_device(device: str) -> str:
    """'[index] name (rate Hz)' of what open_capture would use — for the health check. Raises if not found."""
    from .. import oscompat
    if oscompat.IS_WIN:
        from .audio import MIC_ALIASES
        from .wasapi import _pa, find_loopback, is_loopback_name
        if is_loopback_name(device) or (device.strip().lower() not in MIC_ALIASES and not _is_input_device(device)):
            p = _pa().PyAudio()
            try:
                d = find_loopback(p, device)
                return f"[{d['index']}] {d['name']} ({int(d['defaultSampleRate'])} Hz) — Windows loopback"
            finally:
                p.terminate()
    d = find_device(device)
    return f"[{d['index']}] {d['name']} ({d['rate']} Hz)"


def _is_input_device(name: str) -> bool:
    try:
        return any(name.lower() in d["name"].lower() for d in list_input_devices()) if name else False
    except Exception:
        return False
