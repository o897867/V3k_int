"""Evaluate speech recognition + question handling on realistic audio, with a ground-truth script.

Four ways to get test audio — all end in the same scored report:

  0. record   → YOU read the questions into your microphone, one at a time (timed → latency is scored too)
                python -m copilot.evaluate record --name mine

  1. script   → a numbered script for a FRIEND to read on a real Google Meet / Teams call
                python -m copilot.evaluate script --name friend
                (then run the copilot with --record during that call; audio lands in sessions/*.wav)
  2. synth    → synthetic interviewers on this Mac: several accents (macOS voices), filler words,
                mid-sentence pauses, background noise, phone-band + AAC compression like a meeting
                python -m copilot.evaluate synth --name accents
  3. any WAV  → a recording of a mock-interview video, a past test call, …  plus a text file of
                what was said (one question per line)

  score:
    python -m copilot.evaluate run --set eval/accents --asr local,deepgram
    python -m copilot.evaluate run --wav sessions/session-X.wav --script eval/friend/script.txt --asr local

What the report measures (per recogniser, per condition):
  WER                  word error rate against the script (lower is better)
  key terms            tools / names from your JD + resume heard correctly (Power BI, Snowflake, …)
  questions detected   a question card appeared for each scripted question
  prepared locked      questions you have a prepared answer for, whose answer locked instantly
  final-text latency   speech end → final transcript (synthetic sets only: exact timings known)
  worst lines          the reference vs what was heard — use them to add keyterms / ALT phrasings
"""
from __future__ import annotations

import argparse
import asyncio
import copy
import json
import random
import re
import shutil
import statistics
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

import numpy as np

# unprepared questions a data/BI interviewer commonly asks (mixed with your prepared ones)
GENERIC_QUESTIONS = [
    "Tell me about a time you had to explain a complex analysis to a non-technical stakeholder.",
    "How would you find the second highest salary in each department using SQL?",
    "What's the difference between a left join and an inner join, and when would you use each?",
    "How would you design a dashboard to monitor daily trading volumes and flag anomalies?",
    "Tell me about a mistake you made at work and what you learned.",
    "How do you handle missing or inconsistent data?",
    "How would you explain a p-value to someone without a statistics background?",
    "Where do you see yourself in three years?",
    "Do you have any questions for us?",
]
FILLERS_BEFORE = ["", "", "So, ", "Okay, great. ", "Right, and ", "So, um, ", "Alright. Next one. "]
FILLERS_AFTER = ["", "", "", " If that makes sense.", " Take your time."]
EN_VOICE_PREF = ["Karen", "Daniel", "Samantha", "Rishi", "Moira", "Tessa", "Alex", "Fred", "Lee", "Serena"]


# ============================================================================ scoring (pure functions)

def norm_words(text: str) -> list[str]:
    t = text.lower().replace("’", "'")
    t = re.sub(r"[^a-z0-9' ]+", " ", t)
    return [w.strip("'") for w in t.split() if w.strip("'")]


def align(ref: list[str], hyp: list[str]) -> list[tuple[int | None, int | None]]:
    """Levenshtein alignment → list of (ref_index|None, hyp_index|None) pairs (match/sub/del/ins)."""
    n, m = len(ref), len(hyp)
    d = np.zeros((n + 1, m + 1), dtype=np.int32)
    d[:, 0] = np.arange(n + 1)
    d[0, :] = np.arange(m + 1)
    for i in range(1, n + 1):
        ri = ref[i - 1]
        for j in range(1, m + 1):
            d[i, j] = min(d[i - 1, j] + 1, d[i, j - 1] + 1, d[i - 1, j - 1] + (ri != hyp[j - 1]))
    i, j, path = n, m, []
    while i > 0 or j > 0:
        if i > 0 and j > 0 and d[i, j] == d[i - 1, j - 1] + (ref[i - 1] != hyp[j - 1]):
            path.append((i - 1, j - 1))
            i, j = i - 1, j - 1
        elif i > 0 and d[i, j] == d[i - 1, j] + 1:
            path.append((i - 1, None))
            i -= 1
        else:
            path.append((None, j - 1))
            j -= 1
    return path[::-1]


def wer_counts(ref: list[str], hyp: list[str]) -> dict:
    s = dl = ins = 0
    for r, h in align(ref, hyp):
        if r is None:
            ins += 1
        elif h is None:
            dl += 1
        elif ref[r] != hyp[h]:
            s += 1
    return {"sub": s, "del": dl, "ins": ins, "n": len(ref),
            "wer": (s + dl + ins) / len(ref) if ref else 0.0}


def split_by_reference(refs: list[str], hyp_text: str) -> list[str]:
    """Assign the recognised words to scripted lines via one global alignment (works without timings)."""
    ref_words, owner = [], []
    for qi, r in enumerate(refs):
        w = norm_words(r)
        ref_words += w
        owner += [qi] * len(w)
    hyp = norm_words(hyp_text)
    out: list[list[str]] = [[] for _ in refs]
    cur = 0
    for r, h in align(ref_words, hyp):
        if r is not None:
            cur = owner[r]
        if h is not None:
            out[cur].append(hyp[h])
    return [" ".join(x) for x in out]


def term_in(term: str, text: str) -> bool:
    t = " ".join(norm_words(term))
    return bool(t) and f" {t} " in f" {' '.join(norm_words(text))} "


def keyterm_stats(terms: list[str], refs: list[str], hyps: list[str]) -> dict:
    total, hits, misses = 0, 0, []
    for r, h in zip(refs, hyps):
        for t in terms:
            if term_in(t, r):
                total += 1
                if term_in(t, h):
                    hits += 1
                else:
                    misses.append(t)
    return {"total": total, "hits": hits, "misses": sorted(set(misses))}


def word_recall(ref: str, hyp: str) -> float:
    r, h = norm_words(ref), set(norm_words(hyp))
    return sum(1 for w in r if w in h) / len(r) if r else 0.0


def match_cards(refs: list[str], cards: list[str], min_recall: float = 0.5) -> list[int | None]:
    """For each scripted question, the index of the question card that covers it (or None)."""
    out = []
    for r in refs:
        best, bi = 0.0, None
        for i, c in enumerate(cards):
            s = word_recall(r, c)
            if s > best:
                best, bi = s, i
        out.append(bi if best >= min_recall else None)
    return out


# ============================================================================ test-set files

@dataclass
class Line:
    text: str
    start: float | None = None        # seconds in audio.wav (synthetic sets only)
    end: float | None = None
    condition: str = ""               # e.g. "Karen · noise 15 dB · meeting codec"
    prepared: str | None = None       # prepared question this line should lock onto (from your qa bank)


@dataclass
class TestSet:
    name: str
    lines: list[Line] = field(default_factory=list)
    wav: str | None = None
    notes: str = ""

    def save(self, folder: Path) -> Path:
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "script.json").write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")
        (folder / "script.txt").write_text("\n".join(ln.text for ln in self.lines) + "\n", encoding="utf-8")
        return folder

    @staticmethod
    def load(folder: Path) -> "TestSet":
        d = json.loads((folder / "script.json").read_text(encoding="utf-8"))
        return TestSet(d["name"], [Line(**x) for x in d["lines"]], d.get("wav"), d.get("notes", ""))

    @staticmethod
    def from_text(path: Path, wav: Path) -> "TestSet":
        lines = [ln.strip() for ln in path.read_text(encoding="utf-8").splitlines()]
        lines = [re.sub(r"^\s*\d+[.)]\s*", "", ln) for ln in lines if ln and not ln.startswith("#")]
        return TestSet(path.stem, [Line(t) for t in lines], str(wav))


def tag_prepared(ts: TestSet, kb, threshold: float) -> None:
    for ln in ts.lines:
        m = kb.qa.match(ln.text)
        ln.prepared = m[0].question if m and m[1] >= threshold else None


def make_script(kb, n: int, seed: int = 7) -> list[str]:
    """Mix: your prepared questions phrased the way interviewers ramble (ALT phrasings + fillers),
    plus unprepared ones. Order shuffled so it isn't predictable."""
    rnd = random.Random(seed)
    prepared = []
    for e in kb.qa.entries:
        phr = rnd.choice(e.alts) if e.alts else e.question
        prepared.append(phr.rstrip("?.") + "?")
    rnd.shuffle(prepared)
    k = min(len(prepared), max(1, (n * 3) // 5))
    lines = prepared[:k] + rnd.sample(GENERIC_QUESTIONS, min(len(GENERIC_QUESTIONS), n - k))
    rnd.shuffle(lines)
    out = []
    for ln in lines[:n]:
        pre = rnd.choice(FILLERS_BEFORE)
        body = ln if not pre or ln[:2] == "I " else ln[0].lower() + ln[1:]
        out.append(pre + body + rnd.choice(FILLERS_AFTER))
    return out


def reader_sheet(lines: list[str]) -> str:
    out = ["# Script for your mock interviewer",
           "",
           "Read each line naturally, the way an interviewer would — don't rush, don't read robotically.",
           "Wait about **5 seconds** after each question (the candidate would be answering).",
           "Where you see **…(pause)…**, stop for about one second mid-sentence, then continue.",
           "Mistakes are fine — keep going; we score against this text.",
           ""]
    rnd = random.Random(3)
    for i, ln in enumerate(lines, 1):
        shown = ln
        words = ln.split()
        if len(words) >= 8 and rnd.random() < 0.4:   # a thinking pause in the middle of the question
            k = len(words) // 2
            shown = " ".join(words[:k]) + " **…(pause)…** " + " ".join(words[k:])
        out.append(f"{i}. {shown}")
    return "\n".join(out) + "\n"


# ============================================================================ synthetic audio (macOS)

def list_voices() -> list[tuple[str, str]]:
    """Installed English `say` voices as (name, locale)."""
    try:
        out = subprocess.run(["say", "-v", "?"], capture_output=True, text=True, timeout=20).stdout
    except Exception:
        return []
    voices = []
    for line in out.splitlines():
        m = re.match(r"^(.+?)\s+(en[_-][A-Z]{2})\s+#", line)
        if m and "(" not in m.group(1):
            voices.append((m.group(1).strip(), m.group(2)))
    return voices


def pick_voices(available: list[tuple[str, str]], k: int = 4) -> list[str]:
    names = [n for n, _ in available]
    chosen = [v for v in EN_VOICE_PREF if v in names]
    seen_loc = set()
    out = []
    for v in chosen + names:  # prefer distinct accents
        loc = dict(available).get(v)
        if v not in out and loc not in seen_loc:
            out.append(v)
            seen_loc.add(loc)
        if len(out) >= k:
            break
    return out or names[:k]


def say_tts(text: str, voice: str, rate: int, work: Path) -> np.ndarray:
    aiff, wav = work / "t.aiff", work / "t.wav"
    subprocess.run(["say", "-v", voice, "-r", str(rate), "-o", str(aiff), text], check=True)
    subprocess.run(["afconvert", "-f", "WAVE", "-d", "LEI16@16000", "-c", "1", str(aiff), str(wav)], check=True)
    from .asr_probe import _read_wav16
    return _read_wav16(wav)


def speech_power(pcm: np.ndarray) -> float:
    x = pcm.astype(np.float32)
    speech = x[np.abs(x) > 300]
    return float(np.mean(speech ** 2)) if len(speech) else float(np.mean(x ** 2)) + 1e-9


def add_noise(pcm: np.ndarray, snr_db: float, seed: int = 0, ref_power: float | None = None) -> np.ndarray:
    x = pcm.astype(np.float32)
    p_sig = ref_power if ref_power is not None else speech_power(pcm)
    rng = np.random.default_rng(seed)
    white = rng.standard_normal(len(x)).astype(np.float32)
    # a bit of low-frequency hum/room tone rather than pure hiss
    brown = np.cumsum(rng.standard_normal(len(x)).astype(np.float32))
    brown -= np.convolve(brown, np.ones(801) / 801, mode="same")
    noise = white + 0.5 * brown / (np.std(brown) + 1e-9)
    noise *= np.sqrt(p_sig / (10 ** (snr_db / 10)) / (np.mean(noise ** 2) + 1e-9))
    return np.clip(x + noise, -32768, 32767).astype(np.int16)


def band_limit(pcm: np.ndarray, lo: float = 300.0, hi: float = 3400.0, rate: int = 16000) -> np.ndarray:
    spec = np.fft.rfft(pcm.astype(np.float32))
    f = np.fft.rfftfreq(len(pcm), 1 / rate)
    spec[(f < lo) | (f > hi)] = 0
    return np.clip(np.fft.irfft(spec, n=len(pcm)), -32768, 32767).astype(np.int16)


def codec_roundtrip(pcm: np.ndarray, work: Path, kbps: int = 24) -> np.ndarray:
    """AAC at low bitrate and back — approximates meeting-app compression. macOS afconvert only."""
    if not shutil.which("afconvert"):
        return pcm
    import wave
    src, enc, back = work / "c.wav", work / "c.m4a", work / "c2.wav"
    with wave.open(str(src), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes(pcm.tobytes())
    subprocess.run(["afconvert", "-f", "m4af", "-d", "aac", "-b", str(kbps * 1000), str(src), str(enc)], check=True)
    subprocess.run(["afconvert", "-f", "WAVE", "-d", "LEI16@16000", "-c", "1", str(enc), str(back)], check=True)
    from .asr_probe import _read_wav16
    y = _read_wav16(back)
    return y[:len(pcm)] if len(y) >= len(pcm) else np.pad(y, (0, len(pcm) - len(y)))


def build_synthetic(lines: list[str], out_dir: Path, voices: list[str], noise_levels: list[float | None],
                    codec: bool, band: bool, tts: Callable[[str, str, int, Path], np.ndarray] = say_tts,
                    seed: int = 11, gap_s: float = 4.5, lead_s: float = 1.5) -> TestSet:
    """Round-robin over voices × noise so every condition appears; mid-sentence pauses on some lines."""
    import wave
    rnd = random.Random(seed)
    conds = [(v, nz) for nz in noise_levels for v in voices]
    rate16 = 16000
    parts = [np.zeros(int(lead_s * rate16), dtype=np.int16)]
    t = lead_s
    ts = TestSet(out_dir.name, notes=f"voices={voices} noise={noise_levels} codec={codec} band={band}")
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        for i, text in enumerate(lines):
            voice, nz = conds[i % len(conds)]
            rate = rnd.choice([165, 180, 195])
            pieces = text.split(",", 1) if ("," in text and rnd.random() < 0.35) else [text]
            clip = []
            for k, piece in enumerate(pieces):
                if k:
                    clip.append(np.zeros(int(rate16 * rnd.uniform(0.8, 1.3)), dtype=np.int16))  # thinking pause
                clip.append(tts(piece.strip(), voice, rate, work))
            clip = np.concatenate(clip)
            from .asr_probe import speech_bounds
            s, e = speech_bounds(clip)
            label = [voice]
            if band:
                clip = band_limit(clip)
                label.append("phone band")
            p_ref = speech_power(clip)
            if nz is not None:
                clip = add_noise(clip, nz, seed=i)
                label.append(f"noise {nz:g} dB")
            if codec:
                clip = codec_roundtrip(clip, work)
                label.append("meeting codec")
            ts.lines.append(Line(text, start=t + s, end=t + e, condition=" · ".join(label)))
            gap = np.zeros(int(gap_s * rate16), dtype=np.int16)
            if nz is not None:  # room noise continues in the gaps, like a real call (harder for the VAD)
                gap = add_noise(gap, nz, seed=1000 + i, ref_power=p_ref)
            parts += [clip, gap]
            t += len(clip) / rate16 + gap_s
    wav = out_dir / "audio.wav"
    out_dir.mkdir(parents=True, exist_ok=True)
    with wave.open(str(wav), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate16)
        w.writeframes(np.concatenate(parts).tobytes())
    ts.wav = "audio.wav"
    return ts


# ============================================================================ running a recogniser

@dataclass
class RunResult:
    provider: str
    hyp_text: str
    per_line: list[str]
    events: list[tuple[float, str, str]]
    cards: list[str]
    locked: list[str | None]           # per card: prepared question it locked to
    seconds: float
    error: str = ""


async def run_provider(cfg, kb, provider: str, wav: Path, speed: float = 1.0) -> RunResult:
    from .asr import build_asr
    from .capture import WavReplay
    from .engine.pipeline import Pipeline
    from .events import RecordingSink
    from .llm.mock_llm import MockLLM

    c = copy.deepcopy(cfg)
    c.asr.provider = provider
    c.engine.merge_window_s /= max(1.0, speed)   # time-compressed replay must not merge separate questions
    terms = kb.keyterms() if c.asr.deepgram.auto_keyterms_from_jd else []
    asr = build_asr(c, terms)
    sink = RecordingSink()
    pipe = Pipeline(c, MockLLM(ttft=0.01, tok_per_s=20000), kb, sink)
    replay = WavReplay(str(wav), tail_silence_s=3.0, speed=speed)
    events: list[tuple[float, str, str]] = []
    t_start = time.monotonic()

    async def on_event(ev):
        if ev.kind in ("interim", "final", "endpoint") and replay.t0 is not None:
            events.append((time.monotonic() - replay.t0, ev.kind, ev.text))
        await pipe.handle(ev)

    err = ""
    try:
        await asr.run(replay.chunks(), on_event)
        await pipe.wait_idle()
    except Exception as e:  # report and keep going with the next provider
        err = f"{e.__class__.__name__}: {e}"
    finals = " ".join(t for _, k, t in events if k == "final")
    qs = [e[2] for e in sink.events if e[1] == "question"]
    # merged follow-ups replace their predecessor: keep the latest card of each chain
    replaced = {q.merged_from for q in qs if q.merged_from}
    cards = [q for q in qs if q.id not in replaced]
    lock_by_id = {pm["id"]: pm["prepared"] for pm in pipe.prepared_metrics}
    return RunResult(provider, finals, [], events, [q.text for q in cards],
                     [lock_by_id.get(q.id) for q in cards], time.monotonic() - t_start, err)


def score(ts: TestSet, res: RunResult, terms: list[str]) -> dict:
    refs = [ln.text for ln in ts.lines]
    res.per_line = split_by_reference(refs, res.hyp_text)
    tot = wer_counts(norm_words(" ".join(refs)), norm_words(res.hyp_text))
    card_of = match_cards(refs, res.cards)
    should = [i for i, ln in enumerate(ts.lines) if ln.prepared]
    locked_ok = [i for i in should if card_of[i] is not None and res.locked[card_of[i]] == ts.lines[i].prepared]
    lat = []
    if all(ln.start is not None for ln in ts.lines):
        from .asr_probe import Segment, score_probe
        pr = score_probe([Segment(ln.start, ln.end, ln.text) for ln in ts.lines], res.events)
        lat = [p.latency for p in pr if p.latency is not None]
    by_cond: dict[str, list] = {}
    for ln, h in zip(ts.lines, res.per_line):
        by_cond.setdefault(ln.condition or "all", []).append(wer_counts(norm_words(ln.text), norm_words(h)))
    cond = {k: sum(x["sub"] + x["del"] + x["ins"] for x in v) / max(1, sum(x["n"] for x in v))
            for k, v in by_cond.items()}
    per = [(wer_counts(norm_words(r), norm_words(h))["wer"], r, h, ln.condition)
           for r, h, ln in zip(refs, res.per_line, ts.lines)]
    return {
        "provider": res.provider, "error": res.error, "wer": tot["wer"], "words": tot["n"],
        "keyterms": keyterm_stats(terms, refs, res.per_line),
        "detected": sum(1 for x in card_of if x is not None), "questions": len(refs),
        "extra_cards": max(0, len(res.cards) - len({x for x in card_of if x is not None})),
        "prepared_should": len(should), "prepared_locked": len(locked_ok),
        "prepared_missed": [ts.lines[i].text for i in should if i not in locked_ok],
        "latency_median": statistics.median(lat) if lat else None, "latency_max": max(lat) if lat else None,
        "by_condition": cond, "worst": sorted(per, key=lambda x: -x[0])[:5], "seconds": res.seconds,
    }


def render_report(ts: TestSet, scores: list[dict]) -> str:
    L = [f"# Recognition evaluation — {ts.name}", "",
         f"{datetime.now():%Y-%m-%d %H:%M} · {len(ts.lines)} scripted questions · {ts.notes}", "",
         "| recogniser | WER ↓ | key terms | questions detected | prepared locked | extra cards | final text p50 / max |",
         "|---|---|---|---|---|---|---|"]
    for s in scores:
        if s["error"] and not s["words"]:
            L.append(f"| {s['provider']} | ❌ {s['error'][:60]} | | | | | |")
            continue
        kt = s["keyterms"]
        lat = (f"{s['latency_median']:.2f}s / {s['latency_max']:.2f}s" if s["latency_median"] is not None else "—")
        L.append(f"| {s['provider']} | {s['wer']:.1%} | {kt['hits']}/{kt['total']} | {s['detected']}/{s['questions']}"
                 f" | {s['prepared_locked']}/{s['prepared_should']} | {s['extra_cards']} | {lat} |")
    L += ["", "WER: 0–5 % excellent · 5–10 % fine for answering · >15 % the model will misread questions. "
              "Prepared locked is the number that decides the 1.5 s promise.", ""]
    for s in scores:
        L += [f"## {s['provider']}", ""]
        if s["error"]:
            L += [f"⚠ {s['error']}", ""]
        if len(s["by_condition"]) > 1:
            L += ["| condition | WER |", "|---|---|"]
            L += [f"| {k} | {v:.1%} |" for k, v in sorted(s["by_condition"].items(), key=lambda kv: -kv[1])]
            L.append("")
        if s["keyterms"]["misses"]:
            L += [f"**Key terms misheard:** {', '.join(s['keyterms']['misses'])} → add them to "
                  "`asr.deepgram.keyterms` in config.yaml (all recognisers use that list as a hint).", ""]
        if s["prepared_missed"]:
            L += ["**Prepared answers that did NOT lock** (add these phrasings as `ALT:` lines in qa.md / "
                  "qa.generated.md):"] + [f"- {t}" for t in s["prepared_missed"]] + [""]
        L += ["**Worst lines**", ""]
        for w, r, h, cnd in s["worst"]:
            if w <= 0:
                break
            L += [f"- {w:.0%} {('· ' + cnd) if cnd else ''}", f"  - said: {r}", f"  - heard: {h or '(nothing)'}"]
        L.append("")
    return "\n".join(L)


# ============================================================================ CLI

def _cfg_kb(config: str | None):
    from .config import load_config
    from .knowledge import load_knowledge
    cfg = load_config(config)
    return cfg, load_knowledge(cfg)


def cmd_script(a) -> int:
    cfg, kb = _cfg_kb(a.config)
    out = Path(a.out) / a.name
    lines = make_script(kb, a.n)
    ts = TestSet(a.name, [Line(t) for t in lines])
    tag_prepared(ts, kb, cfg.engine.instant_lock_threshold)
    ts.save(out)
    (out / "reader.md").write_text(reader_sheet(lines), encoding="utf-8")
    print(f"✅ {len(lines)} lines ({sum(1 for ln in ts.lines if ln.prepared)} should hit your prepared answers)\n"
          f"   give {out / 'reader.md'} to your mock interviewer\n"
          f"   during the call run:  python run.py --record   (audio → sessions/<session>.wav)\n"
          f"   afterwards:           python -m copilot.evaluate run --wav sessions/<session>.wav "
          f"--script {out / 'script.txt'} --asr local,deepgram")
    return 0


def cmd_synth(a) -> int:
    if sys.platform != "darwin" or not shutil.which("say"):
        print("synth needs macOS (`say` + `afconvert`). Use `script` + a real call instead.")
        return 2
    cfg, kb = _cfg_kb(a.config)
    out = Path(a.out) / a.name
    src = Path(a.script) if a.script else None
    lines = ([ln for ln in src.read_text(encoding="utf-8").splitlines() if ln.strip()] if src else make_script(kb, a.n))
    avail = list_voices()
    voices = [v.strip() for v in a.voices.split(",")] if a.voices != "auto" else pick_voices(avail, a.k)
    missing = [v for v in voices if v not in {n for n, _ in avail}]
    if missing:
        print(f"voices not installed: {missing} — System Settings → Accessibility → Spoken Content → "
              f"System voice → Manage Voices… (English). Using the rest.")
        voices = [v for v in voices if v not in missing]
    if not voices:
        print("no English voices available")
        return 2
    noise = [None if x.strip() in ("", "none", "0") else float(x) for x in a.noise.split(",")]
    print(f"building {len(lines)} lines · voices {voices} · noise {a.noise} · codec {not a.no_codec} · "
          f"phone band {a.band} …")
    ts = build_synthetic(lines, out, voices, noise, codec=not a.no_codec, band=a.band)
    tag_prepared(ts, kb, cfg.engine.instant_lock_threshold)
    ts.save(out)
    dur = ts.lines[-1].end + 3 if ts.lines else 0
    print(f"✅ {out / 'audio.wav'} ({dur / 60:.1f} min) + script.json\n"
          f"   next: python -m copilot.evaluate run --set {out} --asr local,deepgram")
    return 0


async def _record_mic(cfg, lines: list[str], wav: Path, device: str,
                      ask: Callable[[str], str] = input) -> list[tuple[float, float]]:
    """Show one line at a time; Enter → start, Enter → done. Returns (start, end) seconds per line, where
    the ends are refined to where speech really starts/stops inside that window."""
    from .asr_probe import speech_bounds
    from .capture import AudioCapture

    cap = AudioCapture(device, cfg.audio.block_ms, 16000, record_path=wav,
                       on_warning=lambda m: print("\n⚠ " + m, flush=True))
    buf: list[np.ndarray] = []
    stop = asyncio.Event()

    async def pump():
        agen = cap.chunks()
        try:
            async for data in agen:
                buf.append(np.frombuffer(data, dtype=np.int16))
                if stop.is_set():
                    break
        finally:
            await agen.aclose()

    task = asyncio.create_task(pump())
    loop = asyncio.get_running_loop()
    n_now = lambda: sum(len(b) for b in buf) / 16000  # noqa: E731
    await asyncio.sleep(0.8)
    marks = []
    try:
        for i, text in enumerate(lines, 1):
            await loop.run_in_executor(None, ask, f"\n[{i}/{len(lines)}] press Enter, then read aloud:\n    {text}\n")
            t0 = n_now()
            await loop.run_in_executor(None, ask, "   … press Enter when you've finished the sentence ")
            marks.append((t0, n_now()))
        await asyncio.sleep(2.0)   # tail so the last sentence is complete
    finally:
        stop.set()
        await asyncio.wait_for(task, timeout=5)
    pcm = np.concatenate(buf) if buf else np.zeros(0, dtype=np.int16)
    out = []
    for s0, e0 in marks:
        seg = pcm[int(s0 * 16000):int(e0 * 16000) + 8000]
        thr = max(500, int(np.percentile(np.abs(seg), 50) * 4)) if len(seg) else 500
        a, b = speech_bounds(seg, thresh=thr)
        out.append((s0 + a, s0 + b))
    return out


def cmd_record(a) -> int:
    cfg, kb = _cfg_kb(a.config)
    out = Path(a.out) / a.name
    if a.script:
        lines = [re.sub(r"^\s*\d+[.)]\s*", "", ln).strip() for ln in Path(a.script).read_text(encoding="utf-8").splitlines()]
        lines = [ln for ln in lines if ln and not ln.startswith("#")]
    else:
        lines = make_script(kb, a.n)
    out.mkdir(parents=True, exist_ok=True)
    wav = out / "audio.wav"
    print(f"🎤 Recording from your microphone ({a.device}). {len(lines)} lines.\n"
          "Read each one naturally, as an interviewer would — pauses and 'um's are fine, keep going if you "
          "stumble.\nCtrl+C stops early (what you read so far is kept).")
    try:
        marks = asyncio.run(_record_mic(cfg, lines, wav, a.device))
    except KeyboardInterrupt:
        print("\nstopped")
        return 1
    ts = TestSet(a.name, [Line(t, s, e, condition=f"mic · {a.device}") for t, (s, e) in zip(lines, marks)],
                 "audio.wav", notes=f"read aloud into {a.device}")
    tag_prepared(ts, kb, cfg.engine.instant_lock_threshold)
    ts.save(out)
    print(f"\n✅ {wav}\n   next: python -m copilot.evaluate run --set {out} --asr local,deepgram")
    return 0


def cmd_run(a) -> int:
    cfg, kb = _cfg_kb(a.config)
    if a.set:
        folder = Path(a.set)
        ts = TestSet.load(folder)
        wav = folder / (ts.wav or "audio.wav")
    else:
        if not (a.wav and a.script):
            print("give --set FOLDER, or --wav FILE --script FILE")
            return 2
        wav, folder = Path(a.wav), Path(a.script).parent
        ts = TestSet.from_text(Path(a.script), wav)
        tag_prepared(ts, kb, cfg.engine.instant_lock_threshold)
    terms = list(dict.fromkeys([*cfg.asr.deepgram.keyterms, *kb.keyterms()]))
    scores = []
    for prov in [p.strip() for p in a.asr.split(",") if p.strip()]:
        print(f"── {prov}: replaying {wav.name} in {'real time' if a.speed == 1 else f'{a.speed}× speed'} …",
              flush=True)
        res = asyncio.run(run_provider(cfg, kb, prov, wav, a.speed))
        s = score(ts, res, terms)
        scores.append(s)
        if s["error"]:
            print(f"   ⚠ {s['error']}")
        print(f"   WER {s['wer']:.1%} · questions {s['detected']}/{s['questions']} · prepared "
              f"{s['prepared_locked']}/{s['prepared_should']} · key terms {s['keyterms']['hits']}/"
              f"{s['keyterms']['total']}")
    rep = render_report(ts, scores)
    path = folder / f"report-{datetime.now():%Y%m%d-%H%M%S}.md"
    path.write_text(rep, encoding="utf-8")
    print(f"\n📄 {path}")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m copilot.evaluate", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="config.yaml" if Path("config.yaml").exists() else None)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("script", help="make a script for a friend to read on a real call")
    p.add_argument("--name", default="friend")
    p.add_argument("--n", type=int, default=15)
    p.add_argument("--out", default="eval")
    p = sub.add_parser("synth", help="synthetic accents / noise / meeting codec (macOS)")
    p.add_argument("--name", default="accents")
    p.add_argument("--n", type=int, default=16)
    p.add_argument("--script", help="use these lines (one per line) instead of generating")
    p.add_argument("--voices", default="auto", help="comma list of `say` voices, or auto")
    p.add_argument("--k", type=int, default=4, help="how many voices when auto")
    p.add_argument("--noise", default="none,15", help="SNR dB list, e.g. none,20,10")
    p.add_argument("--band", action="store_true", help="also phone-band filter (300–3400 Hz)")
    p.add_argument("--no-codec", action="store_true", help="skip the AAC 24 kbps meeting-codec round trip")
    p.add_argument("--out", default="eval")
    p = sub.add_parser("record", help="read the questions into your MICROPHONE (timed) → a scoreable set")
    p.add_argument("--name", default="mine")
    p.add_argument("--n", type=int, default=12)
    p.add_argument("--script", help="read these lines (one per line) instead of generating")
    p.add_argument("--device", default="default", help="microphone name part, or default")
    p.add_argument("--out", default="eval")
    p = sub.add_parser("run", help="replay audio through recognisers and score")
    p.add_argument("--set", help="folder made by `synth` or `script`")
    p.add_argument("--wav")
    p.add_argument("--script")
    p.add_argument("--asr", default="local")
    p.add_argument("--speed", type=float, default=1.0, help="replay speed (latency is only meaningful at 1.0)")
    for sp in sub.choices.values():
        sp.add_argument("--config", default=argparse.SUPPRESS)
    a = ap.parse_args(argv)
    return {"script": cmd_script, "synth": cmd_synth, "record": cmd_record, "run": cmd_run}[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
