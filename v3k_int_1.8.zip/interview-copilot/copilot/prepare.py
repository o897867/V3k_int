"""Pre-interview: generate a bank of likely questions + grounded answers (the instant tier),
and a one-screen cheat sheet of facts you might blank on.

    python -m copilot.prepare --n 30

Writes knowledge/qa.generated.md — review and edit it; anything you change is what appears
on screen with ~0 latency during the interview. Your hand-written qa.md always takes priority.
Also writes knowledge/cheatsheet.md (⌘⇧K during the interview) unless --no-cheatsheet.
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

from .config import load_config
from .knowledge import load_knowledge
from .knowledge.prompt import build_system_blocks

TASK = """Before the interview: predict the {n} questions this interviewer is most likely to ask {name}
for THIS job, and write the best answer to each, grounded strictly in the knowledge base.

Mix: ~25% standard openers/closers (tell me about yourself, why this role/company, strengths/weakness,
salary/notice if relevant, questions for us), ~35% behavioural (STAR) mapped to the JD's key requirements,
~40% technical/role-specific (tools, SQL/Python/BI, domain) from the JD. Include questions that probe
gaps between the JD and the resume — those are the ones the candidate most needs help with.

The ALT line matters: it is what the live matcher uses. Write 3-5 genuinely different ways an interviewer
would phrase the same question, including casual/rambling forms ("so, um, maybe walk me through …").

Output ONLY this Markdown, one block per question, no intro:

## Q: <question as an interviewer would say it>
ALT: <3-5 other phrasings separated by semicolons>
KEY: <≤14 words — the first sentence to say>
FLOW:
> <中文：第一步说什么（≤16字）> | <2–6 English words for this step>
> <第二步> | <English words>
> <3–4 steps in total, in speaking order, matching SAY>
- <talking point with concrete evidence>
- <talking point>
- <talking point — for answers about work {name} did: "Impact: <what it changed for the whole system>">
SAY: <70-110 word spoken answer — about work: problem → what I did, with what → what it changed downstream;, first person — plain, conversational English: short sentences, everyday words,
     contractions, no buzzwords; easy to say aloud under pressure>
"""

CHEATSHEET_TASK = """Build a one-screen CHEAT SHEET for {name} to glance at mid-interview when their mind goes blank.
Only facts that appear in the knowledge base — never invent. Prefer numbers, dates, names, figures.

Plain text, one fact per line, ≤ 12 words per line, max 28 lines total. No markdown headings or bullets;
use these UPPERCASE labels on their own line:
TIMELINE — employers, titles, start/end dates
NUMBERS — every metric/result worth quoting (with the project it belongs to)
PROJECTS — 3–5 named projects, one line each: what + tool + outcome
STACK — tools grouped as the JD groups them
PRACTICAL — notice period, work rights, salary line, availability (only if in the profile)
ASK THEM — the 2–3 questions {name} plans to ask
GAPS → PIVOT — each JD requirement missing from the resume, with a one-line honest pivot"""


async def generate_text(cfg, kb, task: str, max_tokens: int, echo: bool = True) -> str:
    system = build_system_blocks(cfg, kb)
    if cfg.llm.provider == "openai":
        from openai import AsyncOpenAI
        client = AsyncOpenAI(base_url=cfg.llm.openai.base_url or None)
        r = await client.chat.completions.create(
            model=cfg.llm.openai.model, max_tokens=max_tokens,
            messages=[{"role": "system", "content": "\n\n".join(b["text"] for b in system)},
                      {"role": "user", "content": task}])
        return r.choices[0].message.content
    import anthropic
    client = anthropic.AsyncAnthropic()
    out = []
    async with client.messages.stream(model=cfg.llm.prepare_model, max_tokens=max_tokens, system=system,
                                      messages=[{"role": "user", "content": task}]) as s:
        async for t in s.text_stream:
            out.append(t)
            if echo:
                sys.stdout.write(t)
                sys.stdout.flush()
    return "".join(out)


async def generate(cfg, kb, n: int) -> str:
    return await generate_text(cfg, kb, TASK.format(n=n, name=cfg.candidate.name), 16000)


async def generate_cheatsheet(cfg, kb) -> str:
    return await generate_text(cfg, kb, CHEATSHEET_TASK.format(name=cfg.candidate.name), 2000)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml" if Path("config.yaml").exists() else None)
    ap.add_argument("--n", type=int, default=30)
    ap.add_argument("--out", default="qa.generated.md")
    ap.add_argument("--no-cheatsheet", action="store_true")
    ap.add_argument("--cheatsheet-only", action="store_true")
    ap.add_argument("--allow-example", action="store_true", help="(testing only) run on the fictional example data")
    a = ap.parse_args(argv)
    cfg = load_config(a.config)
    kb = load_knowledge(cfg)
    print(f"knowledge: {kb.summary()}  ({kb.directory})\n")
    if kb.is_example and not a.allow_example:
        print("REFUSING: knowledge.dir points at the FICTIONAL example candidate "
              f"({', '.join(kb.example_files) or kb.directory}).\n"
              "Everything generated from it would describe someone who isn't you.\n"
              "→ Put your resume / JD / cover letter / analysis in ./knowledge and set `knowledge.dir: ./knowledge` "
              "in config.yaml.")
        return 2
    if kb.missing_core():
        print(f"REFUSING: no {' / '.join(kb.missing_core())} found in {kb.directory}. "
              "Prepared answers must be grounded in your own resume and the job description.")
        return 2
    kdir = cfg.path(cfg.knowledge.dir)
    if cfg.llm.provider == "anthropic" and not os.environ.get("ANTHROPIC_API_KEY"):
        print("ANTHROPIC_API_KEY not set (.env)")
        return 1
    if not a.cheatsheet_only:
        text = asyncio.run(generate(cfg, kb, a.n))
        out = kdir / a.out
        out.write_text("# Auto-generated prepared answers — review & edit before the interview\n\n"
                       + text.strip() + "\n", encoding="utf-8")
        print(f"\n\nSaved {text.count('## Q:')} prepared answers → {out}")
    if not a.no_cheatsheet:
        print("\nGenerating cheat sheet…\n")
        cs = asyncio.run(generate_cheatsheet(cfg, kb))
        out = kdir / "cheatsheet.md"
        out.write_text(cs.strip() + "\n", encoding="utf-8")
        print(f"\n\nSaved cheat sheet → {out}  (⌘⇧K during the interview)")
    print("\nNext: python run.py --preflight")
    return 0


if __name__ == "__main__":
    sys.exit(main())
