"""The few places where macOS and Windows differ, in one file.

                 macOS                                  Windows
meeting audio    BlackHole virtual device (input)       WASAPI loopback of the speakers — nothing to install
local speech     mlx-whisper (Apple Silicon)            cloud by default (Deepgram / OpenAI); faster-whisper optional
hotkeys          ⌘⇧ + key                               Ctrl+Alt + key (Win+Shift+S is the screenshot tool, and
                                                        Ctrl+Shift+R/T reload / reopen tabs in a browser Teams)
start            Interview Copilot.command               Interview Copilot.bat (install.bat once)

Functions take an optional `win` flag so tests can exercise both sides on any machine.
"""
from __future__ import annotations

import sys

IS_MAC = sys.platform == "darwin"
IS_WIN = sys.platform == "win32"


def _win(win: bool | None) -> bool:
    return IS_WIN if win is None else win


# ---------------------------------------------------------------- hotkeys

def adapt_hotkey(combo: str, win: bool | None = None) -> str:
    """Config hotkeys are written in macOS terms. On Windows ⌘⇧X becomes Ctrl+Alt+X (⌘X alone → Ctrl+X)."""
    if not combo or not _win(win):
        return combo
    combo = combo.replace("<cmd>+<shift>+", "<ctrl>+<alt>+").replace("<shift>+<cmd>+", "<ctrl>+<alt>+")
    return combo.replace("<cmd>", "<ctrl>")


def pretty_hotkey(combo: str, win: bool | None = None) -> str:
    """'<cmd>+<shift>+r' → '⌘⇧R' on a Mac, '<ctrl>+<alt>+r' → 'Ctrl+Alt+R' on Windows."""
    if not combo:
        return ""
    parts = combo.split("+")
    if _win(win):
        names = {"<ctrl>": "Ctrl", "<alt>": "Alt", "<shift>": "Shift", "<cmd>": "Ctrl", "<space>": "Space",
                 "<left>": "←", "<right>": "→", "<up>": "↑", "<down>": "↓", "<enter>": "Enter"}
        return "+".join(names.get(p, p.upper()) for p in parts)
    sym = {"<cmd>": "⌘", "<shift>": "⇧", "<alt>": "⌥", "<ctrl>": "⌃", "<space>": "Space",
           "<left>": "←", "<right>": "→", "<up>": "↑", "<down>": "↓", "<enter>": "↩"}
    return "".join(sym.get(p, p.upper()) for p in parts)


def pynput_to_qt(combo: str, win: bool | None = None) -> str:
    """pynput combo → Qt key sequence. Qt maps 'Ctrl' to ⌘ on macOS and 'Meta' to the Control key."""
    if _win(win):
        names = {"<cmd>": "Ctrl", "<ctrl>": "Ctrl", "<shift>": "Shift", "<alt>": "Alt"}
    else:
        names = {"<cmd>": "Ctrl", "<ctrl>": "Meta", "<shift>": "Shift", "<alt>": "Alt"}
    names.update({"<space>": "Space", "<left>": "Left", "<right>": "Right", "<up>": "Up", "<down>": "Down",
                  "<enter>": "Return"})
    return "+".join(names.get(p, p.upper()) for p in combo.split("+"))


def zoom_keys(win: bool | None = None) -> str:
    return "Ctrl = / Ctrl - / Ctrl 0" if _win(win) else "⌘= / ⌘- / ⌘0"


# ---------------------------------------------------------------- audio

MEETING_DEVICE_DEFAULT = {"mac": "BlackHole", "win": "loopback"}


def meeting_audio_hint(win: bool | None = None) -> str:
    if _win(win):
        return ("Hears whatever plays on your speakers / headset (Windows loopback) — nothing to install. "
                "Needs your resume and JD.")
    return "The real thing: listens to the meeting through BlackHole. Needs your resume and JD."


def adapt_audio_device(device: str, win: bool | None = None) -> str:
    """A config written on a Mac says 'BlackHole'; on Windows that means 'the speakers' loopback'."""
    if _win(win) and (not device or device.strip().lower() in ("blackhole", "blackhole 2ch")):
        return "loopback"
    return device


def adapt_config(cfg, win: bool | None = None) -> None:
    """Apply the platform differences to a loaded Config in place."""
    if not _win(win):
        return
    hk = cfg.hotkeys
    for name in list(vars(hk)):
        v = getattr(hk, name)
        if isinstance(v, str) and v.startswith("<"):
            setattr(hk, name, adapt_hotkey(v, True))
    cfg.audio.device = adapt_audio_device(cfg.audio.device, True)
    if cfg.asr.provider == "local" and not local_asr_installed():
        cfg.asr.provider = "deepgram"


def local_asr_installed() -> bool:
    import importlib.util
    return bool(importlib.util.find_spec("mlx_whisper") or importlib.util.find_spec("faster_whisper"))
