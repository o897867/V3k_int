"""Measure the ASR layer on THIS Mac, with THIS config — the number the 1.5 s budget depends on.

macOS ships a TTS engine (`say`) and an audio converter (`afconvert`), so we can synthesise a few
interview questions, play them through the configured recogniser in real time, and time
'speech ended → final transcript ready'. Used by `python run.py --preflight`, and standalone:

    python -m copilot.asr_probe --asr local
    python -m copilot.asr_probe --asr deepgram

Caveat: TTS audio is clean studio speech. Real meeting audio (compression, accents, crosstalk) is
harder — treat accuracy here as an upper bound, and latency as representative.
"""
from __future__ import annotations

import argparse
import asyncio
import re
import shutil
import statistics
import subprocess
import sys
import tempfile
import time
import wave
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import numpy as np

PHRASES = [
    "Could you walk me through your background and what you're doing at the moment?",
    "Tell me about a time you had to explain a complex analysis to a non-technical stakeholder.",
    "How would you use a window function in SQL to find duplicate transactions?",
]
LEAD_S, GAP_S = 2.0, 3.0


@dataclass
class Segment:
    start: float
    end: float
    text: str


@dataclass
class ProbeResult:
    latency: float | None        # speech end → endpoint with final text
    first_words: float | None    # speech start → first real interim text (None = no live subtitles)
    accuracy: float              # fraction of spoken words recovered
    heard: str


def available() -> bool:
    return sys.platform == "darwin" and shutil.which("say") is not None and shutil.which("afconvert") is not None


def _read_wav16(path: Path) -> np.ndarray:
    with wave.open(str(path), "rb") as w:
        raw = w.readframes(w.getnframes())
        ch = w.getnchannels()
    x = np.frombuffer(raw, dtype=np.int16)
    return x.reshape(-1, ch).mean(axis=1).astype(np.int16) if ch > 1 else x


def speech_bounds(pcm: np.ndarray, rate: int = 16000, thresh: int = 500) -> tuple[float, float]:
    idx = np.flatnonzero(np.abs(pcm) > thresh)
    if len(idx) == 0:
        return 0.0, len(pcm) / rate
    return idx[0] / rate, idx[-1] / rate


def build_probe_wav(clips: list[np.ndarray], texts: list[str], out: Path) -> list[Segment]:
    """Concatenate 16 kHz int16 clips with silences; return where speech really starts/ends in each."""
    rate = 16000
    parts, segs, t = [np.zeros(int(LEAD_S * rate), dtype=np.int16)], [], LEAD_S
    for clip, text in zip(clips, texts):
        s, e = speech_bounds(clip)
        segs.append(Segment(t + s, t + e, text))
        parts += [clip, np.zeros(int(GAP_S * rate), dtype=np.int16)]
        t += len(clip) / rate + GAP_S
    with wave.open(str(out), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(np.concatenate(parts).tobytes())
    return segs


def synthesize(phrases: list[str], workdir: Path) -> tuple[Path, list[Segment]]:
    clips = []
    for i, text in enumerate(phrases):
        aiff, wav = workdir / f"q{i}.aiff", workdir / f"q{i}.wav"
        subprocess.run(["say", "-r", "175", "-o", str(aiff), text], check=True)
        subprocess.run(["afconvert", "-f", "WAVE", "-d", "LEI16@16000", "-c", "1", str(aiff), str(wav)], check=True)
        clips.append(_read_wav16(wav))
    out = workdir / "probe.wav"
    return out, build_probe_wav(clips, phrases, out)


def _words(s: str) -> list[str]:
    return re.findall(r"[a-z0-9']+", s.lower())


def word_recall(said: str, heard: str) -> float:
    a, b = Counter(_words(said)), Counter(_words(heard))
    return sum((a & b).values()) / max(1, sum(a.values()))


def score_probe(segments: list[Segment], events: list[tuple[float, str, str]]) -> list[ProbeResult]:
    """events: (t relative to audio start, kind, text). Pure function — unit-tested."""
    out = []
    for i, seg in enumerate(segments):
        lo = seg.start - 0.3
        hi = segments[i + 1].start - 0.3 if i + 1 < len(segments) else float("inf")
        win = [e for e in events if lo <= e[0] < hi]
        finals = [e for e in win if e[1] == "final"]
        heard = " ".join(e[2] for e in finals)
        ends = [e[0] for e in win if e[1] == "endpoint" and any(f[0] <= e[0] for f in finals)]
        interims = [e[0] for e in win if e[1] == "interim" and e[2].strip() not in ("", "…")]
        out.append(ProbeResult(
            latency=(ends[-1] - seg.end) if ends else None,
            first_words=(interims[0] - seg.start) if interims else None,
            accuracy=word_recall(seg.text, heard),
            heard=heard,
        ))
    return out


async def run_probe_on_wav(asr, wav: Path, segments: list[Segment], timeout: float = 90) -> list[ProbeResult]:
    from .capture import WavReplay

    replay = WavReplay(str(wav), tail_silence_s=2.0)
    events: list[tuple[float, str, str]] = []

    async def on_event(ev):
        if replay.t0 is not None and ev.kind in ("interim", "final", "endpoint"):
            events.append((time.monotonic() - replay.t0, ev.kind, ev.text))

    await asyncio.wait_for(asr.run(replay.chunks(), on_event), timeout=timeout)
    return score_probe(segments, events)


def summarize(results: list[ProbeResult]) -> dict:
    lat = [r.latency for r in results if r.latency is not None]
    fw = [r.first_words for r in results if r.first_words is not None]
    return {
        "n": len(results), "detected": len(lat),
        "latency_median": statistics.median(lat) if lat else None,
        "latency_max": max(lat) if lat else None,
        "first_words_median": statistics.median(fw) if fw else None,
        "accuracy": statistics.mean(r.accuracy for r in results) if results else 0.0,
    }


async def probe(cfg, keyterms: list[str]) -> tuple[dict, list[ProbeResult]]:
    from .asr import build_asr

    with tempfile.TemporaryDirectory() as d:
        wav, segs = synthesize(PHRASES, Path(d))
        asr = build_asr(cfg, keyterms)
        results = await run_probe_on_wav(asr, wav, segs)
    return summarize(results), results


def main(argv=None) -> int:
    from .config import load_config
    from .knowledge import load_knowledge

    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml" if Path("config.yaml").exists() else None)
    ap.add_argument("--asr", help="override asr.provider")
    a = ap.parse_args(argv)
    if not available():
        print("Needs macOS (`say` + `afconvert`).")
        return 1
    cfg = load_config(a.config)
    if a.asr:
        cfg.asr.provider = a.asr
    kb = load_knowledge(cfg)
    s, results = asyncio.run(probe(cfg, kb.keyterms()))
    for r, p in zip(results, PHRASES):
        lat = f"{r.latency:.2f}s" if r.latency is not None else "  —  "
        fw = f"{r.first_words:.2f}s" if r.first_words is not None else "none"
        print(f"final {lat}  first words {fw}  words {r.accuracy:.0%}  | {r.heard[:70]}")
    print(f"\n{cfg.asr.provider}: speech end → final text median "
          f"{s['latency_median'] if s['latency_median'] is None else round(s['latency_median'], 2)} s · "
          f"live subtitles {'yes' if s['first_words_median'] is not None else 'no'} · word recall {s['accuracy']:.0%}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
