"""Wiring: builds every layer, runs the engine on its own asyncio thread and the overlay on the Qt thread."""
from __future__ import annotations

import argparse
import asyncio
import logging
import signal
import sys
import threading
from pathlib import Path

from .config import load_config
from .engine.pipeline import Pipeline
from .knowledge import load_knowledge
from .knowledge.prompt import build_system_blocks
from .llm import build_llm
from .session_log import SessionLogger, latency_table

log = logging.getLogger("copilot")
_QT_APP = None


class EngineThread:
    """Owns the asyncio loop: warm-up → capture → ASR → pipeline. Thread-safe controls for the UI."""

    def __init__(self, pipeline: Pipeline, source, asr, llm, sink, warmup: bool):
        self.pipeline, self.source, self.asr, self.llm, self.sink = pipeline, source, asr, llm, sink
        self.warmup = warmup
        deep = getattr(pipeline, "deep_llm", None)
        self.model_name = getattr(llm, "name", "llm") + (f" + {deep.name}" if deep is not None else "")
        self.loop = asyncio.new_event_loop()
        self._main_task = None
        self.thread = threading.Thread(target=self._run, name="engine", daemon=True)

    def start(self):
        self.thread.start()

    def _run(self):
        asyncio.set_event_loop(self.loop)

        def on_loop_error(loop, context):  # nothing may fail silently on the engine thread
            exc = context.get("exception")
            msg = context.get("message", "engine error")
            log.error("engine: %s", msg, exc_info=exc)
            self.sink.on_error(f"Engine error: {exc.__class__.__name__}: {exc}" if exc else f"Engine error: {msg}")
        self.loop.set_exception_handler(on_loop_error)
        self._main_task = self.loop.create_task(self._main())
        try:
            self.loop.run_until_complete(self._main_task)
        except asyncio.CancelledError:
            pass
        except Exception as e:  # the engine thread must never die silently
            log.exception("engine thread crashed")
            self.sink.on_error(f"Engine crashed: {e.__class__.__name__}: {e} — see terminal")
        finally:
            self.loop.close()

    async def _main(self):
        if self.warmup:
            self.sink.on_status("warming up model + prompt cache…")
            llms = [x for x in (self.llm, self.pipeline.deep_llm) if x is not None]
            results = await asyncio.gather(*(x.warmup() for x in llms), return_exceptions=True)
            errs = [f"{x.name}: {r}" for x, r in zip(llms, results) if isinstance(r, Exception)]
            if errs:
                self.sink.on_error("LLM warm-up failed: " + "; ".join(errs))
            else:
                self.sink.on_status("model ready")
            self._keep_warm = [asyncio.create_task(x.keep_warm()) for x in llms]
        if self.asr is None:  # demo mode: typed input only
            log.info("engine ready (demo mode) — type in the overlay box or in this terminal, then Enter")
            self.sink.on_status("demo mode — type questions below")
            await asyncio.Event().wait()
            return
        try:
            await self.asr.run(self.source.chunks(), self.pipeline.handle)
            self.sink.on_status("audio source ended")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.exception("audio/ASR failed")
            self.sink.on_error(f"Audio/ASR error: {e}")
        await asyncio.Event().wait()  # keep the loop alive for typed/forced answers

    # --- called from the Qt thread ---
    def _submit(self, coro, what: str = "task"):
        """Run a coroutine on the engine loop. Any exception is logged with a traceback AND shown in the
        overlay — previously a failure here was swallowed and the UI just stayed on 'Waiting…'."""
        if not self.thread.is_alive():
            coro.close()
            log.error("engine thread is not running — cannot %s", what)
            self.sink.on_error(f"Engine not running — cannot {what}. See terminal for the traceback.")
            return None
        fut = asyncio.run_coroutine_threadsafe(coro, self.loop)

        def done(f):
            if f.cancelled():
                return
            exc = f.exception()
            if exc is not None:
                log.error("engine failed during %s", what, exc_info=exc)
                self.sink.on_error(f"{what} failed: {exc.__class__.__name__}: {exc}")
        fut.add_done_callback(done)
        return fut

    def force_answer(self):
        self._submit(self.pipeline.force_answer(), "force answer")

    def inject_text(self, text: str):
        log.info("demo input → engine: %r", text)
        self._submit(self.pipeline.inject_text(text), "demo question")

    def clarify(self):
        self.loop.call_soon_threadsafe(self.pipeline.clarify)

    def set_paused(self, paused: bool):
        self.pipeline.paused = paused
        if self.source is not None:
            self.source.paused = paused

    def stop(self):
        if self._main_task and not self.loop.is_closed():
            self.loop.call_soon_threadsafe(self._main_task.cancel)
        self.thread.join(timeout=3)


def start_terminal_input(engine: EngineThread) -> None:
    """Demo fallback: questions typed in the terminal go straight to the engine (no Qt text input, no IME)."""
    def reader():
        for line in sys.stdin:
            text = line.strip()
            if text:
                engine.inject_text(text)
    if sys.stdin and sys.stdin.isatty():
        threading.Thread(target=reader, name="stdin", daemon=True).start()


def parse_args(argv=None):
    ap = argparse.ArgumentParser(prog="interview-copilot", description="Real-time layered interview copilot")
    ap.add_argument("--config", default=None, help="config.yaml (default: ./config.yaml if present)")
    ap.add_argument("--demo", action="store_true", help="no audio; type the interviewer's words")
    ap.add_argument("--replay", metavar="WAV", help="feed a WAV file through ASR instead of live audio")
    ap.add_argument("--mock-llm", action="store_true", help="fake LLM (no API key needed)")
    ap.add_argument("--example", action="store_true", help="use the bundled FICTIONAL example knowledge (demo only)")
    ap.add_argument("--asr", choices=["deepgram", "openai_realtime", "llm_segment", "local"], help="override asr.provider")
    ap.add_argument("--model", help="override llm.model")
    ap.add_argument("--deep-model", help="hybrid mode: also stream this stronger model (e.g. claude-sonnet-5-5)")
    ap.add_argument("--no-hotkeys", action="store_true")
    ap.add_argument("--list-devices", action="store_true")
    ap.add_argument("--preflight", action="store_true", help="check audio, keys, knowledge, hotkeys and the "
                                                              "1.5 s prepared-answer budget; then exit")
    ap.add_argument("--offline", action="store_true", help="with --preflight: skip the network checks")
    ap.add_argument("--no-launcher", action="store_true", help="skip the launcher window (use config + flags)")
    ap.add_argument("--mic", nargs="?", const="default", metavar="NAME",
                    help="listen to your MICROPHONE instead of the meeting (say the questions yourself to test). "
                         "Optional NAME = part of the device name, e.g. --mic AirPods")
    ap.add_argument("--record", action="store_true", help="save the meeting audio to sessions/<session>.wav for "
                                                          "`python -m copilot.evaluate` (test calls only)")
    ap.add_argument("-v", "--verbose", action="store_true")
    return ap.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg_path = args.config or ("config.yaml" if Path("config.yaml").exists() else None)
    cfg = load_config(cfg_path)
    if args.list_devices:
        from .capture import list_input_devices
        from .oscompat import IS_WIN
        print("Inputs (microphones, virtual cables):")
        for d in list_input_devices():
            print(f"  [{d['index']}] {d['name']}  ({d['channels']} ch, {d['rate']} Hz)")
        if IS_WIN:
            from .capture.wasapi import list_loopback_devices
            print("Speaker loopbacks (meeting audio — audio.device: loopback uses the default one):")
            for d in list_loopback_devices():
                print(f"  [{d['index']}] {d['name']}  ({d['channels']} ch, {d['rate']} Hz)")
        return 0
    if args.mock_llm:
        cfg.llm.provider = "mock"
    if args.mic:
        cfg.audio.device = cfg.audio.mic_device if args.mic == "default" else args.mic
    if args.preflight:
        from .preflight import run_preflight
        if args.asr:
            cfg.asr.provider = args.asr
        if args.model:
            cfg.llm.model = args.model
        return run_preflight(cfg, skip_network=args.offline)
    if args.asr:
        cfg.asr.provider = args.asr
    if args.model:
        cfg.llm.model = args.model
        cfg.llm.openai.model = args.model
    if args.deep_model is not None:
        cfg.llm.deep_model = args.deep_model
    if args.no_hotkeys:
        cfg.hotkeys.enabled = False
    if args.example:
        from .config import EXAMPLE_DIR
        cfg.knowledge.dir = str(EXAMPLE_DIR)

    # plain `python run.py` (or double-clicking "Interview Copilot.command") opens the launcher;
    # any mode flag means "I know what I want" and goes straight to the overlay
    flags_given = any([args.demo, args.replay, args.mock_llm, args.example, args.asr, args.model,
                       args.deep_model is not None, args.mic])
    if not args.no_launcher and not flags_given:
        from PyQt6.QtWidgets import QApplication

        from .ui.launcher import apply_choice, run_launcher
        global _QT_APP
        _QT_APP = QApplication.instance() or QApplication(sys.argv[:1])
        _QT_APP.setQuitOnLastWindowClosed(False)
        choice = run_launcher(cfg, cfg_path, Path(cfg.base_dir) / ".state" / "launcher.json")
        if choice is None:
            return 0
        cfg, args.demo, mock = apply_choice(cfg, choice)
        args.mic = "default" if choice.mode == "mic" else args.mic
        log.info("launcher: mode=%s speech=%s answers=%s", choice.mode, choice.asr, choice.answers)

    kb = load_knowledge(cfg)
    log.info("knowledge: %s  (%s)", kb.summary(), kb.directory)
    warning = kb.data_warning()
    if kb.is_example and not args.demo and not args.mic:
        log.error("REFUSING to start a real session: %s", warning)
        print("\nThe loaded knowledge is the FICTIONAL example candidate, not you. Put your own files in "
              "./knowledge and set `knowledge.dir: ./knowledge` in config.yaml (or use --demo --example to try the UI).")
        return 2
    if warning:
        log.warning(warning)
    llm = build_llm(cfg, build_system_blocks(cfg, kb))
    deep_llm = None
    if cfg.llm.deep_model:
        deep_llm = build_llm(cfg, build_system_blocks(cfg, kb, say_words=cfg.llm.deep_say_words), deep=True)
        log.info("hybrid mode: fast=%s deep=%s", llm.name, deep_llm.name)

    from PyQt6.QtCore import QTimer
    from PyQt6.QtWidgets import QApplication

    from .ui.bridge import QtSink
    from .ui.hotkeys import start_global_hotkeys
    from .ui.mac_window import float_over_everything
    from .ui.overlay import Overlay

    app = QApplication.instance() or QApplication(sys.argv[:1])
    globals()["_QT_APP"] = app  # keep one QApplication alive for the process (Qt can't recreate it)
    from .ui.launcher import set_app_icon
    set_app_icon()
    app.setQuitOnLastWindowClosed(True)
    sink = QtSink()
    logger = SessionLogger(cfg.path(cfg.logging.dir))
    from .ui.state import JsonState
    flow_cache = JsonState(Path(cfg.base_dir) / ".state" / "flow_cache.json", {})
    pipeline = Pipeline(cfg, llm, kb, sink, logger, deep_llm=deep_llm, flow_cache=flow_cache)

    source = asr = None
    if not args.demo:
        from .asr import build_asr
        from .capture import WavReplay, open_capture
        rec = logger.jsonl.with_suffix(".wav") if (args.record or cfg.audio.record) else None
        source = (WavReplay(args.replay, cfg.audio.block_ms) if args.replay
                  else open_capture(cfg.audio.device, cfg.audio.block_ms, cfg.audio.target_rate, record_path=rec,
                                    on_warning=lambda m: (log.warning(m), sink.on_warning(m))))
        if args.mic and not args.replay:
            log.info("🎤 microphone mode — input device '%s'. Say the interviewer's questions yourself.",
                     cfg.audio.device)
        if rec and not args.replay:
            log.info("recording %s audio → %s", "microphone" if args.mic else "meeting", rec)
        terms = kb.keyterms() if cfg.asr.deepgram.auto_keyterms_from_jd else []
        asr = build_asr(cfg, terms)

    engine = EngineThread(pipeline, source, asr, llm, sink, warmup=cfg.llm.warmup and cfg.llm.provider != "mock")
    facts = kb.get("cheatsheet") or kb.get("profile")
    overlay = Overlay(cfg, sink, engine, engine.model_name,
                      level_fn=(lambda: source.level) if source is not None else None, demo=args.demo,
                      facts_text=facts, data_warning=warning,
                      state_path=Path(cfg.base_dir) / ".state" / "ui.json",
                      waiting_text=("🎤 Microphone test — ask a question out loud, e.g. “Walk me through your "
                                    "background.”" if args.mic and not args.replay else
                                    "Waiting for the interviewer's first question…"))
    overlay.show()
    float_over_everything(overlay)
    start_global_hotkeys(cfg.hotkeys, lambda a: sink.hotkey.emit(a))
    engine.start()
    if args.demo:
        start_terminal_input(engine)

    signal.signal(signal.SIGINT, lambda *_: app.quit())
    tick = QTimer(interval=250, timeout=lambda: None)  # lets Python see Ctrl+C while Qt runs
    tick.start()
    code = app.exec()

    engine.stop()
    report = logger.close()
    if pipeline.metrics:
        print("\n" + latency_table(pipeline.metrics))
    print(f"\nSession review saved to {report}")
    return code
