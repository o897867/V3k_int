"""LLM-based streaming ASR: OpenAI Realtime API transcription session (gpt-live-transcribe).

Why use it: the recogniser is a language model that takes a context prompt + keywords
(company, tools from your JD), so it tends to do better on jargon and accented speech.
Cost: slower than Deepgram — first partial ≈0.7 s at delay=minimal (vs ≈0.25 s), and a
turn only finalises after the client commits it.

How turns work here (the transcription session has no server VAD):
  every chunk → resample 16k→24k → input_audio_buffer.append
  our EnergyVAD sees `silence_ms` of silence → input_audio_buffer.commit
  ...transcription.delta events   → interim text (live subtitles)
  ...transcription.completed      → final + endpoint (question can trigger)
  if `completed` is slower than `final_wait_ms` after the commit, we finalise with the
  streamed delta text instead, so a slow final never blocks the answer.
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import time
from typing import AsyncIterator

import numpy as np

from ..events import TranscriptEvent
from .base import ASR, ASRAuthError, EventCallback, is_auth_error
from .vad import EnergyVAD

log = logging.getLogger(__name__)
_END = object()


def upsample_16k_to_24k(pcm16: np.ndarray) -> np.ndarray:
    if len(pcm16) == 0:
        return pcm16
    n_out = len(pcm16) * 3 // 2
    x = np.interp(np.linspace(0, len(pcm16) - 1, n_out), np.arange(len(pcm16)), pcm16.astype(np.float32))
    return np.clip(x, -32768, 32767).astype(np.int16)


def session_update(cfg, keyterms: list[str]) -> dict:
    tr: dict = {"model": cfg.model}
    if cfg.prompt:
        tr["prompt"] = cfg.prompt
    if keyterms:
        tr["keywords"] = keyterms[:50]
    if cfg.language:
        tr["languages"] = [cfg.language]
    if cfg.delay:
        tr["delay"] = cfg.delay
    return {"type": "session.update", "session": {"type": "transcription", "audio": {"input": {
        "format": {"type": "audio/pcm", "rate": 24000},
        "transcription": tr,
        "turn_detection": None,
    }}}}


class TurnAssembler:
    """Turns Realtime events into TranscriptEvents. Pure logic, unit-tested."""

    def __init__(self):
        self.text: dict[str, str] = {}
        self.order: list[str] = []
        self.emitted: set[str] = set()

    def on_delta(self, item_id: str, delta: str) -> list[TranscriptEvent]:
        if item_id in self.emitted:
            return []
        if item_id not in self.text:
            self.text[item_id] = ""
            self.order.append(item_id)
        self.text[item_id] += delta
        t = self.text[item_id].strip()
        return [TranscriptEvent("interim", t)] if t else []

    def on_completed(self, item_id: str, transcript: str, audio_end: float | None) -> list[TranscriptEvent]:
        if item_id in self.emitted:
            return []
        self.emitted.add(item_id)
        t = (transcript or self.text.get(item_id, "")).strip()
        return self._finalise(t, audio_end)

    def pending_item(self) -> str | None:
        """Oldest turn that has streamed text but is not finalised yet (= the committed one)."""
        for i in self.order:
            if i not in self.emitted and self.text.get(i, "").strip():
                return i
        return None

    def on_timeout(self, item_id: str, audio_end: float | None) -> list[TranscriptEvent]:
        if item_id is None or item_id in self.emitted:
            return []
        self.emitted.add(item_id)
        return self._finalise(self.text.get(item_id, "").strip(), audio_end)

    @staticmethod
    def _finalise(text: str, audio_end):
        evs = [TranscriptEvent("final", text, audio_end=audio_end)] if text else []
        return evs + [TranscriptEvent("endpoint", "", audio_end=audio_end)]


class OpenAIRealtimeASR(ASR):
    def __init__(self, cfg, keyterms: list[str] | None = None):
        self.cfg = cfg
        self.keyterms = keyterms or []
        self.api_key = os.environ.get(cfg.api_key_env, "")

    async def run(self, chunks: AsyncIterator[bytes], on_event: EventCallback) -> None:
        if not self.api_key:
            raise RuntimeError(f"{self.cfg.api_key_env} is not set (put it in .env)")
        buf: asyncio.Queue = asyncio.Queue(maxsize=600)

        async def pump():
            async for c in chunks:
                if buf.full():
                    buf.get_nowait()
                buf.put_nowait(c)
            await buf.put(_END)

        pump_task = asyncio.create_task(pump())
        backoff = 0.5
        try:
            while True:
                try:
                    if await self._session(buf, on_event):
                        return
                    backoff = 0.5
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    if is_auth_error(e):
                        raise ASRAuthError(f"OpenAI rejected the API key ({str(e)[:120]}). Check OPENAI_API_KEY with "
                                           "`python scripts/check_keys.py`") from e
                    log.warning("Realtime ASR error: %s — reconnecting in %.1fs", e, backoff)
                    await on_event(TranscriptEvent("status", f"ASR reconnecting ({e.__class__.__name__})"))
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, 8)
        finally:
            pump_task.cancel()

    async def _connect(self):
        """OpenAI's docs don't spell out the transcription-session URL, so try the configured one, then the
        fallbacks, and remember whichever works."""
        import websockets

        headers = {"Authorization": f"Bearer {self.api_key}"}
        urls = [self.cfg.url, *[u for u in getattr(self.cfg, "fallback_urls", []) if u != self.cfg.url]]
        last: Exception | None = None
        for url in urls:
            try:
                try:
                    ws = await websockets.connect(url, additional_headers=headers, max_size=2**22)
                except TypeError:  # websockets < 14
                    ws = await websockets.connect(url, extra_headers=headers, max_size=2**22)
                if url != self.cfg.url:
                    log.warning("Realtime ASR: %s failed, connected via %s (set asr.openai_realtime.url)", self.cfg.url, url)
                    self.cfg.url = url
                return ws
            except Exception as e:  # 4xx handshake → try the next candidate
                last = e
                log.info("Realtime ASR connect failed for %s: %s", url, e)
        raise last or ConnectionError("no Realtime URL could be reached")

    async def _session(self, buf: asyncio.Queue, on_event: EventCallback) -> bool:
        ws = await self._connect()
        await ws.send(json.dumps(session_update(self.cfg, self.keyterms)))
        await on_event(TranscriptEvent("status", f"ASR connected ({self.cfg.model})"))
        turns = TurnAssembler()
        vad = EnergyVAD(silence_ms=self.cfg.silence_ms)
        finished = {"v": False}
        timers: set[asyncio.Task] = set()

        async def finalise_later(audio_end):
            await asyncio.sleep(self.cfg.final_wait_ms / 1000)
            for ev in turns.on_timeout(turns.pending_item(), audio_end):
                await on_event(ev)

        async def sender():
            while True:
                item = await buf.get()
                if item is _END:
                    finished["v"] = True
                    await ws.send(json.dumps({"type": "input_audio_buffer.commit"}))
                    await asyncio.sleep(self.cfg.final_wait_ms / 1000 + 0.2)
                    for ev in turns.on_timeout(turns.pending_item(), time.monotonic()):
                        await on_event(ev)
                    return
                pcm = np.frombuffer(item, dtype=np.int16)
                audio = base64.b64encode(upsample_16k_to_24k(pcm).tobytes()).decode()
                await ws.send(json.dumps({"type": "input_audio_buffer.append", "audio": audio}))
                if vad.push(pcm):  # a speech segment just ended → close the turn
                    await ws.send(json.dumps({"type": "input_audio_buffer.commit"}))
                    end = time.monotonic() - self.cfg.silence_ms / 1000
                    t = asyncio.create_task(finalise_later(end))
                    timers.add(t)
                    t.add_done_callback(timers.discard)

        async def receiver():
            async for raw in ws:
                if isinstance(raw, bytes):
                    continue
                msg = json.loads(raw)
                typ = msg.get("type", "")
                evs: list[TranscriptEvent] = []
                if typ.endswith("input_audio_transcription.delta"):
                    evs = turns.on_delta(msg.get("item_id", "?"), msg.get("delta", ""))
                elif typ.endswith("input_audio_transcription.completed"):
                    evs = turns.on_completed(msg.get("item_id", "?"), msg.get("transcript", ""),
                                             time.monotonic() - self.cfg.silence_ms / 1000)
                elif typ == "error":
                    err = msg.get("error", {})
                    log.warning("Realtime ASR server error: %s", err)
                    evs = [TranscriptEvent("status", f"ASR error: {err.get('message', err)}"[:120])]
                for ev in evs:
                    await on_event(ev)

        s, r = asyncio.create_task(sender()), asyncio.create_task(receiver())
        try:
            done, _ = await asyncio.wait({s, r}, return_when=asyncio.FIRST_COMPLETED)
            for t in done:
                if t.exception():
                    raise t.exception()
            if s in done:
                return finished["v"]
            raise ConnectionError("server closed the transcription session")
        finally:
            for t in (s, r, *timers):
                t.cancel()
            await ws.close()
