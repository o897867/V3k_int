"""Tiny adaptive energy VAD (no native deps). Segments speech for the local Whisper path."""
from __future__ import annotations

import numpy as np


class EnergyVAD:
    def __init__(self, rate: int = 16000, frame_ms: int = 30, silence_ms: int = 600,
                 min_speech_ms: int = 250, margin_db: float = 10.0, max_segment_s: float = 25.0):
        self.rate = rate
        self.frame = int(rate * frame_ms / 1000)
        self.silence_frames = max(1, silence_ms // frame_ms)
        self.min_speech_frames = max(1, min_speech_ms // frame_ms)
        self.max_frames = int(max_segment_s * 1000 / frame_ms)
        self.margin_db = margin_db
        self.noise_db = -60.0
        self._pending = np.zeros(0, dtype=np.int16)
        self._seg: list[np.ndarray] = []
        self._speech_frames = 0
        self._silent_run = 0
        self.in_speech = False

    @staticmethod
    def _db(frame: np.ndarray) -> float:
        rms = np.sqrt(np.mean((frame.astype(np.float32) / 32768.0) ** 2) + 1e-12)
        return 20 * np.log10(rms)

    def push(self, pcm: np.ndarray) -> list[np.ndarray]:
        """Feed int16 samples; returns completed speech segments (int16 arrays)."""
        out = []
        self._pending = np.concatenate([self._pending, pcm])
        while len(self._pending) >= self.frame:
            f, self._pending = self._pending[:self.frame], self._pending[self.frame:]
            db = self._db(f)
            is_speech = db > self.noise_db + self.margin_db and db > -50
            if not is_speech:  # track the noise floor only on non-speech
                self.noise_db = 0.95 * self.noise_db + 0.05 * db
            if self.in_speech:
                self._seg.append(f)
                if is_speech:
                    self._speech_frames += 1
                    self._silent_run = 0
                else:
                    self._silent_run += 1
                if self._silent_run >= self.silence_frames or len(self._seg) >= self.max_frames:
                    if self._speech_frames >= self.min_speech_frames:
                        out.append(np.concatenate(self._seg))
                    self._reset()
            elif is_speech:
                self.in_speech = True
                self._seg = [f]
                self._speech_frames = 1
                self._silent_run = 0
        return out

    def current_audio(self) -> np.ndarray:
        """Audio of the utterance in progress (empty when not in speech) — used for interim transcripts."""
        return np.concatenate(self._seg) if self._seg else np.zeros(0, dtype=np.int16)

    @property
    def speaking_now(self) -> bool:
        """In an utterance AND the latest frame was speech (not in the trailing silence)."""
        return self.in_speech and self._silent_run == 0

    def _reset(self):
        self._seg, self._speech_frames, self._silent_run, self.in_speech = [], 0, 0, False
