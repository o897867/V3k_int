from __future__ import annotations

from typing import AsyncIterator, Awaitable, Callable

from ..events import TranscriptEvent

EventCallback = Callable[[TranscriptEvent], Awaitable[None]]


class ASR:
    """Streaming speech recogniser. Consumes 16 kHz mono int16 chunks."""

    async def run(self, chunks: AsyncIterator[bytes], on_event: EventCallback) -> None:
        raise NotImplementedError


class ASRAuthError(RuntimeError):
    """The speech service rejected the API key — retrying can't fix it, so we stop and tell the user."""


_AUTH_MARKERS = ("invalid_api_key", "invalid api key", "incorrect api key", "unauthorized", "authentication",
                 "http 401", "http 403", "status 401", "status 403", "forbidden", "invalid credentials")


def is_auth_error(e: BaseException) -> bool:
    status = getattr(getattr(e, "response", None), "status_code", None) or getattr(e, "status_code", None)
    if status in (401, 403):
        return True
    rcvd = getattr(e, "rcvd", None)  # websockets ConnectionClosed: close frame from the server
    text = f"{e.__class__.__name__} {e} {getattr(rcvd, 'reason', '')}".lower()
    return any(m in text for m in _AUTH_MARKERS)
