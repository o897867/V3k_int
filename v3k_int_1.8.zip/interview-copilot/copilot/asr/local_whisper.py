"""Offline ASR: energy VAD segmentation + Whisper on Apple Silicon (mlx-whisper),
falling back to faster-whisper. No API key, no audio leaves the Mac.

Final text: VAD sees `silence_ms` of silence → the whole utterance is transcribed once.
Live subtitles (interim): while the interviewer is speaking, the utterance-so-far is re-transcribed
every `interim_every_ms`. Whisper always encodes a 30 s window, so each pass costs roughly the same
regardless of length — on a fast chip (M1 Max/Ultra and up) that is well under a second; on slower
chips the self-throttle switches interim off rather than delaying the final.

All inference is serialised by one lock (mlx/Metal and faster-whisper are not safe to call
concurrently); interim passes only start while speech is ongoing, so one is rarely in flight when
the final starts.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import AsyncIterator

import numpy as np

from ..events import TranscriptEvent
from .base import ASR, EventCallback
from .vad import EnergyVAD

log = logging.getLogger(__name__)


class LocalWhisperASR(ASR):
    def __init__(self, cfg, keyterms: list[str] | None = None):
        self.cfg = cfg
        self.prompt = ("Job interview. " + ", ".join(keyterms[:40])) if keyterms else "Job interview."
        self._impl = None
        self.backend = ""
        self.last_infer_s = 0.0      # most recent inference time (any kind)
        self.interim_enabled = bool(getattr(cfg, "interim", False))

    def _load(self):
        try:
            import mlx_whisper  # noqa: F401

            def run(audio):
                import mlx_whisper
                r = mlx_whisper.transcribe(audio, path_or_hf_repo=self.cfg.model, language="en",
                                           initial_prompt=self.prompt, condition_on_previous_text=False)
                return r.get("text", "")
            self._impl = run
            return "mlx-whisper"
        except ImportError:
            pass
        from faster_whisper import WhisperModel

        name = self.cfg.model.split("/")[-1].replace("whisper-", "")
        model = WhisperModel(name if name else "small.en", device="auto", compute_type="int8")

        def run(audio):
            segs, _ = model.transcribe(audio, language="en", beam_size=1, initial_prompt=self.prompt,
                                       condition_on_previous_text=False)
            return " ".join(s.text for s in segs)
        self._impl = run
        return "faster-whisper"

    async def _infer(self, lock: asyncio.Lock, pcm16: np.ndarray) -> tuple[str, float]:
        loop = asyncio.get_running_loop()
        async with lock:
            t = time.monotonic()
            text = await loop.run_in_executor(None, self._impl, pcm16.astype(np.float32) / 32768.0)
            dt = time.monotonic() - t
        self.last_infer_s = dt
        return (text or "").strip(), dt

    async def run(self, chunks: AsyncIterator[bytes], on_event: EventCallback) -> None:
        loop = asyncio.get_running_loop()
        if self._impl is None:
            self.backend = await loop.run_in_executor(None, self._load)
        lock = asyncio.Lock()
        # warm-up with speech-length audio so Metal kernels are compiled before the first real question
        warm = (np.random.randn(16000 * 3) * 300).astype(np.int16)
        _, dt = await self._infer(lock, warm)
        _, dt = await self._infer(lock, warm)
        cfg = self.cfg
        if self.interim_enabled and dt > cfg.interim_max_infer_s:
            self.interim_enabled = False
            log.info("local ASR: inference %.2fs > %.2fs — live subtitles off", dt, cfg.interim_max_infer_s)
        await on_event(TranscriptEvent("status", f"ASR ready (local {self.backend or 'custom'}, "
                                                 f"{dt * 1000:.0f} ms/pass, live {'on' if self.interim_enabled else 'off'})"))

        vad = EnergyVAD(silence_ms=cfg.silence_ms, max_segment_s=cfg.max_segment_s)
        utt = 0                 # utterance counter — stale interim results are dropped
        interim_task: asyncio.Task | None = None
        last_interim_t = 0.0
        was_speaking = False

        async def do_interim(audio: np.ndarray, utt_id: int):
            text, took = await self._infer(lock, audio)
            if took > cfg.interim_max_infer_s:
                self.interim_enabled = False
                log.info("local ASR: interim took %.2fs — live subtitles off for this session", took)
            if utt_id == utt and text and not _is_hallucination(text):
                await on_event(TranscriptEvent("interim", text))

        try:
            async for c in chunks:
                segs = vad.push(np.frombuffer(c, dtype=np.int16))
                if vad.in_speech and not was_speaking and not self.interim_enabled:
                    await on_event(TranscriptEvent("interim", "…"))
                was_speaking = vad.in_speech
                now = time.monotonic()
                if (self.interim_enabled and vad.speaking_now
                        and len(vad.current_audio()) >= cfg.interim_min_s * 16000
                        and now - last_interim_t >= cfg.interim_every_ms / 1000
                        and (interim_task is None or interim_task.done())):
                    last_interim_t = now
                    interim_task = asyncio.create_task(do_interim(vad.current_audio(), utt))
                for seg in segs:
                    utt += 1  # any interim still in flight belongs to a finished utterance
                    end = time.monotonic() - cfg.silence_ms / 1000
                    text, _ = await self._infer(lock, seg)
                    if text and not _is_hallucination(text):
                        await on_event(TranscriptEvent("final", text, audio_end=end))
                    await on_event(TranscriptEvent("endpoint", "", audio_end=end))
        finally:
            if interim_task and not interim_task.done():
                interim_task.cancel()


_HALLUCINATIONS = {"thank you.", "thanks for watching!", "you", "bye.", "thank you for watching.", "…", "."}


def _is_hallucination(text: str) -> bool:
    return text.lower().strip() in _HALLUCINATIONS
