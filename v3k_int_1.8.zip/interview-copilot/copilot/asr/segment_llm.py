"""LLM-based ASR per speech segment via any OpenAI-compatible /audio/transcriptions endpoint.

Works with OpenAI gpt-transcribe, Groq whisper-large-v3-turbo, or a local server that speaks
the same API. Simplest and most portable LLM option; no live subtitles (text appears once
the interviewer pauses: silence_ms + upload + transcription time).
"""
from __future__ import annotations

import asyncio
import io
import logging
import os
import time
import wave
from typing import AsyncIterator

import numpy as np

from ..events import TranscriptEvent
from .base import ASR, EventCallback
from .vad import EnergyVAD

log = logging.getLogger(__name__)


def to_wav(pcm16: np.ndarray, rate: int = 16000) -> bytes:
    bio = io.BytesIO()
    with wave.open(bio, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm16.astype(np.int16).tobytes())
    return bio.getvalue()


class SegmentLLMASR(ASR):
    def __init__(self, cfg, keyterms: list[str] | None = None):
        self.cfg = cfg
        self.api_key = os.environ.get(cfg.api_key_env, "")
        terms = ", ".join((keyterms or [])[:40])
        self.prompt = (cfg.prompt + (f" Terms that may occur: {terms}." if terms else "")).strip()
        self._client = None

    def _http(self):
        if self._client is None:
            import httpx
            self._client = httpx.AsyncClient(timeout=httpx.Timeout(20.0, connect=5.0),
                                             limits=httpx.Limits(keepalive_expiry=600))
        return self._client

    async def transcribe(self, pcm16: np.ndarray) -> str:
        r = await self._http().post(
            self.cfg.base_url.rstrip("/") + "/audio/transcriptions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            data={"model": self.cfg.model, "language": self.cfg.language, "prompt": self.prompt,
                  "response_format": "json"},
            files={"file": ("speech.wav", to_wav(pcm16), "audio/wav")},
        )
        r.raise_for_status()
        return (r.json().get("text") or "").strip()

    async def run(self, chunks: AsyncIterator[bytes], on_event: EventCallback) -> None:
        if not self.api_key:
            raise RuntimeError(f"{self.cfg.api_key_env} is not set (put it in .env)")
        await on_event(TranscriptEvent("status", f"ASR ready ({self.cfg.model}, per segment)"))
        vad = EnergyVAD(silence_ms=self.cfg.silence_ms, max_segment_s=self.cfg.max_segment_s)
        queue: asyncio.Queue = asyncio.Queue()

        async def worker():  # transcribe segments in order without stalling audio intake
            while True:
                seg, end = await queue.get()
                try:
                    text = await self.transcribe(seg)
                except Exception as e:
                    log.warning("segment transcription failed: %s", e)
                    await on_event(TranscriptEvent("status", f"ASR error: {e.__class__.__name__}"))
                    text = ""
                if text:
                    await on_event(TranscriptEvent("final", text, audio_end=end))
                await on_event(TranscriptEvent("endpoint", "", audio_end=end))

        w = asyncio.create_task(worker())
        speaking = False
        try:
            async for c in chunks:
                segs = vad.push(np.frombuffer(c, dtype=np.int16))
                if vad.in_speech and not speaking:
                    await on_event(TranscriptEvent("interim", "…"))
                speaking = vad.in_speech
                for seg in segs:
                    queue.put_nowait((seg, time.monotonic() - self.cfg.silence_ms / 1000))
            while not queue.empty():
                await asyncio.sleep(0.05)
            await asyncio.sleep(0.05)
        finally:
            w.cancel()
