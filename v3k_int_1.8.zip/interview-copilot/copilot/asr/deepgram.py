"""Deepgram streaming ASR over a raw websocket (no SDK → no SDK-version churn).

Typical latency: interim words ~250 ms after spoken, endpoint `endpointing_ms`
after the speaker stops. Auto-reconnects so a dropped socket mid-interview
costs ~1 s, not the session.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import AsyncIterator
from urllib.parse import urlencode

from ..events import TranscriptEvent
from .base import ASR, ASRAuthError, EventCallback, is_auth_error

log = logging.getLogger(__name__)
_END = object()


def build_url(cfg, keyterms: list[str]) -> str:
    params = [
        ("model", cfg.model), ("language", cfg.language),
        ("encoding", "linear16"), ("sample_rate", "16000"), ("channels", "1"),
        ("interim_results", "true"), ("smart_format", "true"), ("punctuate", "true"),
        ("endpointing", str(cfg.endpointing_ms)), ("utterance_end_ms", str(cfg.utterance_end_ms)),
        ("vad_events", "true"),
    ]
    terms = list(dict.fromkeys([*cfg.keyterms, *keyterms]))[:50]
    for t in terms:
        if str(cfg.model).startswith("nova-3"):
            params.append(("keyterm", t))
        else:
            params.append(("keywords", f"{t}:2"))
    return "wss://api.deepgram.com/v1/listen?" + urlencode(params)


def parse_message(msg: dict, t0: float) -> list[TranscriptEvent]:
    """Deepgram JSON message → 0..n TranscriptEvents. Pure function (unit-tested)."""
    typ = msg.get("type")
    if typ == "Results":
        alts = (msg.get("channel") or {}).get("alternatives") or [{}]
        text = (alts[0].get("transcript") or "").strip()
        end = t0 + float(msg.get("start", 0)) + float(msg.get("duration", 0))
        evs = []
        if msg.get("is_final"):
            if text:
                evs.append(TranscriptEvent("final", text, audio_end=end))
            if msg.get("speech_final"):
                evs.append(TranscriptEvent("endpoint", "", audio_end=end))
        elif text:
            evs.append(TranscriptEvent("interim", text, audio_end=end))
        return evs
    if typ == "UtteranceEnd":
        end = t0 + float(msg.get("last_word_end", 0) or 0)
        return [TranscriptEvent("endpoint", "", audio_end=end)]
    return []


class DeepgramASR(ASR):
    def __init__(self, cfg, extra_keyterms: list[str] | None = None):
        self.cfg = cfg
        self.keyterms = extra_keyterms or []
        self.api_key = os.environ.get("DEEPGRAM_API_KEY", "")

    async def run(self, chunks: AsyncIterator[bytes], on_event: EventCallback) -> None:
        if not self.api_key:
            raise RuntimeError("DEEPGRAM_API_KEY is not set (put it in .env)")
        buf: asyncio.Queue = asyncio.Queue(maxsize=600)

        async def pump():  # single long-lived reader so reconnects never lose the source
            async for c in chunks:
                if buf.full():
                    buf.get_nowait()
                buf.put_nowait(c)
            await buf.put(_END)

        pump_task = asyncio.create_task(pump())
        backoff = 0.5
        try:
            while True:
                try:
                    finished = await self._session(buf, on_event)
                    if finished:
                        return
                    backoff = 0.5
                except asyncio.CancelledError:
                    raise
                except Exception as e:  # network blip → reconnect
                    if is_auth_error(e):
                        raise ASRAuthError(f"Deepgram rejected the API key ({str(e)[:120]}). Check DEEPGRAM_API_KEY with "
                                           "`python scripts/check_keys.py`") from e
                    log.warning("Deepgram session error: %s — reconnecting in %.1fs", e, backoff)
                    await on_event(TranscriptEvent("status", f"ASR reconnecting ({e.__class__.__name__})"))
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, 8)
        finally:
            pump_task.cancel()

    async def _connect(self, url: str):
        import websockets

        headers = {"Authorization": f"Token {self.api_key}"}
        try:
            return await websockets.connect(url, additional_headers=headers, max_size=2**22)
        except TypeError:  # websockets < 14
            return await websockets.connect(url, extra_headers=headers, max_size=2**22)

    async def _session(self, buf: asyncio.Queue, on_event: EventCallback) -> bool:
        ws = await self._connect(build_url(self.cfg, self.keyterms))
        await on_event(TranscriptEvent("status", "ASR connected (Deepgram)"))
        t0 = {"v": None}
        finished = {"v": False}

        async def sender():
            while True:
                try:
                    item = await asyncio.wait_for(buf.get(), timeout=4.0)
                except asyncio.TimeoutError:
                    await ws.send(json.dumps({"type": "KeepAlive"}))
                    continue
                if item is _END:
                    finished["v"] = True
                    await ws.send(json.dumps({"type": "CloseStream"}))
                    return
                if t0["v"] is None:
                    t0["v"] = time.monotonic()
                await ws.send(item)

        async def receiver():
            async for raw in ws:
                if isinstance(raw, bytes):
                    continue
                for ev in parse_message(json.loads(raw), t0["v"] or time.monotonic()):
                    await on_event(ev)

        s, r = asyncio.create_task(sender()), asyncio.create_task(receiver())
        try:
            done, _ = await asyncio.wait({s, r}, return_when=asyncio.FIRST_EXCEPTION)
            for t in done:
                if t.exception():
                    raise t.exception()
            if s in done and not r.done():  # stream closed by us: wait for final results
                await asyncio.wait_for(r, timeout=5)
            return finished["v"]
        finally:
            for t in (s, r):
                t.cancel()
            await ws.close()
