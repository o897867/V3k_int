from .base import ASR  # noqa: F401

PROVIDERS = ("deepgram", "openai_realtime", "llm_segment", "local")


def build_asr(cfg, keyterms: list[str] | None = None):
    p = cfg.asr.provider
    if p == "deepgram":
        from .deepgram import DeepgramASR
        return DeepgramASR(cfg.asr.deepgram, extra_keyterms=keyterms or [])
    if p == "openai_realtime":
        from .openai_realtime import OpenAIRealtimeASR
        return OpenAIRealtimeASR(cfg.asr.openai_realtime, keyterms=keyterms or [])
    if p == "llm_segment":
        from .segment_llm import SegmentLLMASR
        return SegmentLLMASR(cfg.asr.llm_segment, keyterms=keyterms or [])
    if p == "local":
        from .local_whisper import LocalWhisperASR
        return LocalWhisperASR(cfg.asr.local, keyterms=keyterms or [])
    raise ValueError(f"unknown asr provider {p} (choose from {PROVIDERS})")
