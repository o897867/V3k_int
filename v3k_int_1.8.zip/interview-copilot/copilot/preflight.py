"""Pre-interview health check — run it 10 minutes before the call.

    python run.py --preflight

Checks everything that can silently break mid-interview, and measures the one number this tool
promises: a prepared answer on screen within `engine.prepared_budget_s` (1.5 s) of the interviewer
stopping. Exit code 0 = all good, 1 = something to fix (details printed).
"""
from __future__ import annotations

from .oscompat import pretty_hotkey

import asyncio
import os
import statistics
import time
from pathlib import Path

from .config import Config
from .engine.pipeline import Pipeline
from .events import RecordingSink, TranscriptEvent
from .knowledge import load_knowledge
from .knowledge.prompt import build_system_blocks

OK, WARN, FAIL = "✅", "⚠️ ", "❌"

# typical 'interviewer stops → text final' delay per ASR provider, used to project the end-to-end budget
# typical values, used only when the live probe can't run (non-macOS or --offline with a cloud ASR)
ASR_ENDPOINT_S = {"deepgram": 0.45, "openai_realtime": 0.9, "llm_segment": 1.4, "local": 1.2}


class Report:
    def __init__(self):
        self.rows: list[tuple[str, str, str]] = []
        self.failed = False

    def add(self, status, name, detail=""):
        self.rows.append((status, name, detail))
        if status == FAIL:
            self.failed = True

    def render(self) -> str:
        w = max(len(n) for _, n, _ in self.rows) if self.rows else 10
        return "\n".join(f"{s} {n.ljust(w)}  {d}" for s, n, d in self.rows)


async def _check_llm(cfg: Config, kb, rep: Report):
    if cfg.llm.provider == "mock":
        rep.add(WARN, "LLM", "mock provider — no real answers")
        return None
    key = "ANTHROPIC_API_KEY" if cfg.llm.provider == "anthropic" else "OPENAI_API_KEY"
    if not os.environ.get(key):
        rep.add(FAIL, "LLM key", f"{key} not set in .env")
        return None
    from .llm import build_llm
    try:
        llm = build_llm(cfg, build_system_blocks(cfg, kb))
        t = time.monotonic()
        await asyncio.wait_for(llm.warmup(), timeout=25)
        dt = time.monotonic() - t
        rep.add(OK if dt < 6 else WARN, "LLM warm-up", f"{llm.name} · {dt:.1f}s (connection + prompt cache)")
        note = ""
        if cfg.llm.model.startswith(("claude-sonnet-5", "claude-opus-5")) and cfg.llm.thinking != "disabled":
            note = " · thinking is ON for a live model — expect several seconds before the first word"
            rep.add(WARN, "LLM thinking", f"llm.thinking={cfg.llm.thinking}{note}")
        if cfg.llm.deep_model:
            deep = build_llm(cfg, build_system_blocks(cfg, kb, say_words=cfg.llm.deep_say_words), deep=True)
            t = time.monotonic()
            await asyncio.wait_for(deep.warmup(), timeout=25)
            rep.add(OK, "Deep model", f"{deep.name} · warm-up {time.monotonic() - t:.1f}s")
        return llm
    except Exception as e:
        rep.add(FAIL, "LLM", f"{e.__class__.__name__}: {str(e)[:140]}")
        return None


async def _check_llm_answer(cfg: Config, kb, llm, rep: Report):
    """One real question through the pipeline to measure model latency."""
    if llm is None:
        return
    sink = RecordingSink()
    p = Pipeline(cfg, llm, kb, sink)
    t = time.monotonic()
    await p.handle(TranscriptEvent("final", "How would you explain a complex analysis to a non-technical stakeholder?",
                                   audio_end=t))
    await p.handle(TranscriptEvent("endpoint", "", audio_end=t))
    await asyncio.wait_for(p.wait_idle(), timeout=40)
    if sink.of("error") or not p.metrics:
        rep.add(FAIL, "Model answer", (sink.of("error") or [(0, 0, "no answer")])[0][2])
        return
    m = p.metrics[-1]
    asr = ASR_ENDPOINT_S.get(cfg.asr.provider, 0.5)
    key, full = m["speech_end_to_key"] + asr, m["speech_end_to_done"] + asr
    st = OK if full <= 5 else WARN
    rep.add(st, "Model answer", f"KEY ≈ {key:.1f}s · full ≈ {full:.1f}s after they stop "
                                f"(incl. ~{asr:.1f}s {cfg.asr.provider} endpointing; target ≤ 5s)")


def _check_knowledge(cfg: Config, rep: Report):
    kb = load_knowledge(cfg)
    kdir = cfg.path(cfg.knowledge.dir)
    if not kdir.exists():
        rep.add(FAIL, "Knowledge dir", f"{kdir} does not exist — create it and put your files in")
        return kb
    if kb.is_example:
        rep.add(FAIL, "Knowledge data", "FICTIONAL EXAMPLE candidate loaded ("
                + (", ".join(kb.example_files) or str(kdir)) + ") — set knowledge.dir to your own ./knowledge")
    else:
        rep.add(OK, "Knowledge data", f"{kdir}")
    for name in ("job_description", "resume"):
        rep.add(OK if kb.get(name) else FAIL, f"  {name}", f"{len(kb.get(name).split())} words" if kb.get(name)
                else f"missing ({cfg.knowledge.files.get(name)})")
    for name in ("cover_letter", "my_analysis", "profile", "cheatsheet"):
        rep.add(OK if kb.get(name) else WARN, f"  {name}", f"{len(kb.get(name).split())} words" if kb.get(name)
                else "missing — optional, but " + {"my_analysis": "your gap analysis makes answers much better",
                                                   "profile": "salary/notice/visa answers come from here",
                                                   "cheatsheet": "⌘⇧K facts panel will fall back to profile.md",
                                                   "cover_letter": "fine to skip"}[name])
    n = len(kb.qa.entries)
    if n == 0:
        rep.add(FAIL, "Prepared answers", "0 — run `python -m copilot.prepare` and review qa.generated.md")
    elif n < 15:
        rep.add(WARN, "Prepared answers", f"{n} — run `python -m copilot.prepare --n 30` for better coverage")
    else:
        rep.add(OK, "Prepared answers", f"{n} (instant tier)")
    return kb


def _check_asr_live(cfg: Config, kb, rep: Report, skip_network: bool) -> float | None:
    """Real measurement on this Mac: synthesised questions → configured ASR → time to final text."""
    from . import asr_probe
    if not asr_probe.available():
        rep.add(WARN, "ASR live probe", "skipped (needs macOS `say`/`afconvert`) — using typical values")
        return None
    if skip_network and cfg.asr.provider != "local":
        rep.add(WARN, "ASR live probe", "skipped (--offline) — using typical values")
        return None
    try:
        s, _ = asyncio.run(asr_probe.probe(cfg, kb.keyterms()))
    except Exception as e:
        rep.add(FAIL, "ASR live probe", f"{e.__class__.__name__}: {str(e)[:140]}")
        return None
    if s["latency_median"] is None:
        rep.add(FAIL, "ASR live probe", "no final transcript for the synthesised questions — check model / key")
        return None
    live = "yes" if s["first_words_median"] is not None else "NO (no card before they finish)"
    st = OK if s["latency_max"] <= cfg.engine.prepared_budget_s - 0.1 and s["accuracy"] >= 0.85 else WARN
    rep.add(st, "ASR live probe", f"{cfg.asr.provider}: final text {s['latency_median']:.2f}s median / "
                                  f"{s['latency_max']:.2f}s max after speech ends · live subtitles {live} · "
                                  f"word recall {s['accuracy']:.0%} ({s['detected']}/{s['n']} detected, TTS voice)")
    return s["latency_max"]


def _check_prepared_latency(cfg: Config, kb, rep: Report, measured_asr: float | None = None):
    """The 1.5 s promise: prepared answer on screen after the interviewer stops."""
    if not kb.qa.entries:
        return
    from .llm.mock_llm import MockLLM
    sink = RecordingSink()
    p = Pipeline(cfg, MockLLM(ttft=9, tok_per_s=1), kb, sink)  # model deliberately slow: we time the prepared path

    async def go():
        engine_t = []
        for e in kb.qa.entries[:25]:
            phr = (e.alts[0] if e.alts else e.question)
            t0 = time.monotonic()
            await p.handle(TranscriptEvent("final", phr, audio_end=t0))
            await p.handle(TranscriptEvent("endpoint", "", audio_end=t0))
            engine_t.append(time.monotonic() - t0)
            p._last_q = None  # avoid merge-window effects between samples
        for job in (p._job, p._deep_job):
            if job:
                job.cancel()
        return engine_t
    engine_t = asyncio.run(go())
    locked = [m for m in p.prepared_metrics]
    n = len(engine_t)
    hit = len(locked)
    asr = measured_asr if measured_asr is not None else ASR_ENDPOINT_S.get(cfg.asr.provider, 0.5)
    src = "measured" if measured_asr is not None else "typical"
    e2e = asr + (statistics.median(engine_t) if engine_t else 0) + 0.02  # + render
    budget = cfg.engine.prepared_budget_s
    rep.add(OK if hit == n else WARN, "Prepared self-match",
            f"{hit}/{n} of your own ALT phrasings lock (score ≥ {cfg.engine.instant_lock_threshold}); "
            + ("" if hit == n else "add ALT: phrasings to the misses"))
    rep.add(OK if e2e <= budget else FAIL, "Prepared latency",
            f"engine {statistics.median(engine_t) * 1000:.0f} ms + {cfg.asr.provider} ({src}, worst case) {asr:.2f}s "
            f"= ~{e2e:.2f}s after they stop (budget {budget}s)"
            + ("" if e2e <= budget else " — use asr.provider: deepgram or lower silence_ms"))


def _check_asr(cfg: Config, rep: Report):
    prov = cfg.asr.provider
    keys = {"deepgram": "DEEPGRAM_API_KEY", "openai_realtime": cfg.asr.openai_realtime.api_key_env,
            "llm_segment": cfg.asr.llm_segment.api_key_env}
    if prov in keys:
        rep.add(OK if os.environ.get(keys[prov]) else FAIL, "ASR key", f"{prov}: {keys[prov]}"
                + ("" if os.environ.get(keys[prov]) else " not set in .env"))
    else:
        try:
            import mlx_whisper  # noqa: F401
            rep.add(OK, "ASR", "local mlx-whisper installed")
        except ImportError:
            try:
                import faster_whisper  # noqa: F401
                rep.add(OK, "ASR", "local faster-whisper installed")
            except ImportError:
                rep.add(FAIL, "ASR", "asr.provider=local but neither mlx-whisper nor faster-whisper is installed")
    if prov == "deepgram":
        rep.add(OK, "ASR endpointing", f"{cfg.asr.deepgram.endpointing_ms} ms")


def _check_audio(cfg: Config, rep: Report):
    try:
        from .capture import describe_device
        rep.add(OK, "Audio device", describe_device(cfg.audio.device))
        rep.add(WARN, "Audio signal", "run `python scripts/check_audio.py` with a video playing to confirm level")
    except Exception as e:
        rep.add(FAIL, "Audio device", str(e)[:160])
    if cfg.audio.device != cfg.audio.mic_device:
        try:
            from .capture import find_device
            m = find_device(cfg.audio.mic_device)
            rep.add(OK, "Microphone (mic test)", f"[{m['index']}] {m['name']} — use --mic or launcher “Mic test”")
        except Exception as e:
            rep.add(WARN, "Microphone (mic test)", str(e)[:160])


def _check_hotkeys(cfg: Config, rep: Report):
    if not cfg.hotkeys.enabled:
        rep.add(WARN, "Hotkeys", "disabled in config — only work while the overlay has focus")
        return
    import sys
    if sys.platform == "darwin":
        # pynput 'starts' fine without permission but then never receives a key — ask macOS directly
        try:
            from HIServices import AXIsProcessTrusted
        except ImportError:
            try:
                from ApplicationServices import AXIsProcessTrusted
            except ImportError:
                AXIsProcessTrusted = None
        if AXIsProcessTrusted is not None and not AXIsProcessTrusted():
            rep.add(FAIL, "Hotkeys", "Accessibility permission missing for this terminal — System Settings → "
                                     "Privacy & Security → Accessibility (and Input Monitoring), then restart it")
            return
    try:
        from pynput import keyboard
        listener = keyboard.GlobalHotKeys({cfg.hotkeys.force_answer: lambda: None})
        listener.start()
        time.sleep(0.3)
        alive = listener.running
        listener.stop()
        from .oscompat import IS_WIN
        key = pretty_hotkey(cfg.hotkeys.force_answer)
        if alive:
            msg = f"global listener started — press {key} once in the demo to confirm" + (
                "" if IS_WIN else " Input Monitoring")
        else:
            msg = ("listener died — another app may own these keys; change hotkeys: in config.yaml" if IS_WIN
                   else "listener died — grant Accessibility + Input Monitoring to your terminal")
        rep.add(OK if alive else FAIL, "Hotkeys", msg)
    except Exception as e:
        rep.add(FAIL, "Hotkeys", f"{e.__class__.__name__}: {str(e)[:120]} — grant Accessibility + Input Monitoring")


def run_preflight(cfg: Config, skip_network: bool = False) -> int:
    rep = Report()
    rep.add(OK, "Config", f"{cfg.base_dir}  asr={cfg.asr.provider}  llm={cfg.llm.provider}/{cfg.llm.model}"
                          + (f" + {cfg.llm.deep_model}" if cfg.llm.deep_model else ""))
    kb = _check_knowledge(cfg, rep)
    _check_asr(cfg, rep)
    measured = _check_asr_live(cfg, kb, rep, skip_network)
    _check_prepared_latency(cfg, kb, rep, measured)
    _check_audio(cfg, rep)
    _check_hotkeys(cfg, rep)
    if not skip_network:
        async def net():
            llm = await _check_llm(cfg, kb, rep)
            await _check_llm_answer(cfg, kb, llm, rep)
        asyncio.run(net())
    Path(cfg.path(cfg.logging.dir)).mkdir(parents=True, exist_ok=True)
    print("\nPRE-FLIGHT\n" + rep.render())
    print("\n" + ("Fix the ❌ items before the interview." if rep.failed else
                  "Ready. Start with `python run.py`, then say something in a test call and check the meter moves."))
    return 1 if rep.failed else 0
