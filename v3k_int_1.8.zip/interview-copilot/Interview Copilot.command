#!/bin/bash
# Double-click in Finder to open the Interview Copilot launcher.
# First time only: macOS may say it can't verify the file — right-click it → Open → Open.
cd "$(dirname "$0")" || exit 1
if [ -x ".venv/bin/python" ]; then
  PY=".venv/bin/python"
else
  PY="python3"
  echo "No .venv found here — using $(command -v python3). See README §2.2 to create one."
fi
"$PY" run.py "$@"
status=$?
if [ $status -ne 0 ]; then
  echo
  echo "Interview Copilot exited with code $status. Scroll up for the error, then press Enter to close."
  read -r _
fi
