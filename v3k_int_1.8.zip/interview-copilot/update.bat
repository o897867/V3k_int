@echo off
rem Drag the NEW interview-copilot zip onto this file. Keeps .venv, .env, config.yaml, knowledge, sessions.
rem Everything runs inside one parenthesised block, so replacing this .bat during the update is safe.
(
  cd /d "%~dp0"
  set PYTHONUTF8=1
  if "%~1"=="" (
    echo Drag the new interview-copilot zip file onto update.bat.
    pause
    exit /b 1
  )
  if not exist ".venv\Scripts\python.exe" (
    echo Run install.bat first.
    pause
    exit /b 1
  )
  ".venv\Scripts\python.exe" update.py "%~1"
  pause
  exit /b
)
