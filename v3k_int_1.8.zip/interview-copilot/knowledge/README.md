# Put YOUR files here

The copilot reads these (md / txt / pdf / docx — same name with another extension also works):

| file | what |
|---|---|
| `jd.md` (or `jd.pdf`) | the job description — **required** |
| `resume.pdf` | your resume — **required** |
| `cover_letter.pdf` | your cover letter |
| `analysis.md` | your own analysis: why you fit, gaps + how you'll handle them, STAR stories to reuse |
| `profile.md` | salary line, notice period, work rights, availability, questions to ask them |
| `qa.md` | answers you've written yourself (format: see `../knowledge.example/qa.md`) |
| `qa.bank.md` | made for you from a question bank + reference answers document pair (drop both into the launcher, or `python -m copilot.bank build …`); sources kept in `bank/` |

Then: `python -m copilot.prepare` → review `qa.generated.md` and `cheatsheet.md` → `python run.py --preflight`.

Nothing in `../knowledge.example/` is about you — it's a fictional candidate for trying the UI only.
