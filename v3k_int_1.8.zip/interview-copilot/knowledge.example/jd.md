# ⚠️ FICTIONAL EXAMPLE — not a real job. Do not use for a real interview. (EXAMPLE)

# Data Analyst — Sample Markets Co. (fictional)

Sample Markets Co. is a fictional online trading platform. We are hiring a Data Analyst to join our
Business Intelligence team (8 people), reporting to the Head of Data.

## What you'll do
- Build and maintain Power BI dashboards for trading, risk and client-growth KPIs
- Write efficient SQL (PostgreSQL, Snowflake) to answer ad-hoc questions from product, risk and compliance
- Automate recurring reporting with Python (pandas) and Airflow
- Support regulatory reporting and AML monitoring with the compliance team
- Run A/B test analysis for onboarding and funnel experiments
- Present findings to non-technical stakeholders and senior leadership

## About you
- 2+ years in a data analyst / BI role
- Strong SQL (window functions, CTEs, performance tuning) and Python
- Power BI (DAX, data modelling); dbt is a plus
- Clear communicator who can turn ambiguous questions into analysis
