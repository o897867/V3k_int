# ⚠️ FICTIONAL EXAMPLE CANDIDATE — not you. Replace with your own resume in ./knowledge (EXAMPLE)

# Alex Sample (fictional) — Data Analyst

## Experience
**Data Analyst — Example Brokerage Ltd (fictional)** · 2023–present
- Built 12 Power BI dashboards (client funnel, trading volume, AML alerts) used daily by 40+ staff
- Rewrote month-end regulatory reporting in SQL + Python; cut preparation from 3 days to 4 hours
- Designed AML transaction-monitoring rules with compliance; reduced false-positive alerts by 35%
- Analysed onboarding A/B test (2 variants, 18k users); winning flow lifted KYC completion 9%

**Junior Analyst — Placeholder Retail Group (fictional)** · 2021–2023
- Weekly sales reporting in Excel and SQL Server

## Education
Master of Data Science — Sample University (fictional)

## Skills
SQL (PostgreSQL, SQL Server, Snowflake), Python (pandas, numpy), Power BI (DAX), Excel, Git, Airflow (basic)
