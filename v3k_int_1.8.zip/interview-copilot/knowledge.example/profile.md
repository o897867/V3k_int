# ⚠️ FICTIONAL EXAMPLE — practical details (EXAMPLE)
- Notice period: 4 weeks
- Work rights: full working rights
- Salary expectation: prefer to understand the full package first; give a range only if pressed
- Questions I want to ask:
  1. What does success look like in the first 90 days?
  2. How is the BI team's work prioritised between product, risk and compliance?
  3. Where is the data platform heading over the next year (dbt, Snowflake, self-serve)?
