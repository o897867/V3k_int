# ⚠️ FICTIONAL EXAMPLE prepared answers (EXAMPLE) — yours go in ./knowledge/qa.md

## Q: Tell me about yourself
ALT: Walk me through your background; Introduce yourself; Give me a quick overview of your experience
KEY: [EXAMPLE] Analyst bridging compliance, operations and data at a trading platform
- Example Brokerage: Power BI dashboards used daily by 40+ staff
- Automated reg reporting: 3 days → 4 hours
- Master of Data Science (Sample University)
SAY: [FICTIONAL EXAMPLE — replace with your own.] I'm a data analyst at Example Brokerage. My role sits between compliance, operations and data — I build the Power BI dashboards the business runs on, I automated our month-end regulatory reporting from three days down to four hours, and I work with compliance on AML monitoring. I'm looking for a role where analytics drives product decisions.

## Q: Why do you want to work here?
ALT: Why this role; What attracts you to this company; Why are you interested in this position
KEY: [EXAMPLE] Same industry, bigger analytics mandate, data-driven product decisions
- Regulated trading background: no domain ramp-up
- Wants A/B testing and product analytics, not just reporting
- BI team of 8 → learn from peers
SAY: [FICTIONAL EXAMPLE.] Two reasons. First, I know this industry well — regulated trading, reporting, AML — so I can contribute from week one. Second, you use data to drive product decisions, not just to report on them.

## Q: What's your biggest weakness?
ALT: What would your manager say you need to improve; An area for development
KEY: [EXAMPLE] I used to over-polish analysis before sharing; now I share early drafts
- Early dashboard: built for weeks, low adoption
- Now: share rough version within 2 days, iterate with users
SAY: [FICTIONAL EXAMPLE.] I used to over-polish my work before showing anyone. My first dashboard took weeks and then nobody used it. Now I share a rough version within a couple of days and iterate.
