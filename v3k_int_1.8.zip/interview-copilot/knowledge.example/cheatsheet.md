⚠️ FICTIONAL EXAMPLE (EXAMPLE) — generate yours with `python -m copilot.prepare`
TIMELINE
Example Brokerage Ltd (fictional) — Data Analyst — 2023–present
Placeholder Retail Group (fictional) — Junior Analyst — 2021–2023
NUMBERS
12 Power BI dashboards, used daily by 40+ staff
Reg reporting: 3 days → 4 hours
AML false positives −35%
Onboarding A/B test: 18k users, KYC completion +9%
PRACTICAL
Notice 4 weeks · full work rights
ASK THEM
What does success look like in the first 90 days?
GAPS → PIVOT
dbt: not in prod → strong SQL modelling habits + course
