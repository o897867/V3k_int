⚠️ FICTIONAL EXAMPLE (EXAMPLE)

Dear Hiring Manager,

I'm applying for the Data Analyst role at Sample Markets Co. At Example Brokerage I build the Power BI dashboards
the business runs on, automate regulatory reporting in SQL and Python, and work with compliance on AML
monitoring. Sample Markets' focus on data-driven product decisions is exactly where that mix adds value.

Kind regards, Alex Sample (fictional)
