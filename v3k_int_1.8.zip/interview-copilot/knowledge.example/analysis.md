# ⚠️ FICTIONAL EXAMPLE — my analysis of the role (EXAMPLE)

## Why I fit
- Same industry (online trading, regulated) → no ramp-up on domain, AML, regulatory reporting
- Power BI + SQL + Python daily — matches the core stack exactly
- A/B testing experience from the onboarding experiment

## Gaps & how to handle them
- dbt: not used in production. Frame: strong SQL modelling habits (CTEs, tests in Python); did a dbt course
- Airflow: basic only — scheduled 3 DAGs; mostly cron + Python before that
- Snowflake: used for 6 months via a vendor data share; comfortable, not an admin

## Stories to reuse (STAR)
1. Reg reporting automation: 3 days → 4 hours, zero late submissions since
2. AML rule redesign: false positives −35%, disagreement with compliance lead on thresholds → resolved with backtest
3. Dashboard adoption: first version ignored; interviewed 6 users, rebuilt around 3 KPIs → daily use by 40+
