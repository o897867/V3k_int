#!/usr/bin/env python3
"""Start the interview copilot.

    python run.py                 # live: BlackHole audio → Deepgram → Claude → overlay
    python run.py --demo          # type questions, no audio
    python run.py --demo --mock-llm   # no API keys at all (UI check)
    python run.py --asr local     # on-device Whisper instead of Deepgram
    python run.py --replay q.wav  # replay a recording through the full pipeline
"""
import sys

from copilot.app import main

if __name__ == "__main__":
    sys.exit(main())
