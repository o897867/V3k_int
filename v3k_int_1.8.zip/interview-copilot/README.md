# Interview Copilot（macOS · Windows）

> **Windows 用户请看 [WINDOWS.md](WINDOWS.md)**：双击 `install.bat` 安装，双击 `Interview Copilot.bat` 启动；会议声音直接录扬声器（不用装虚拟声卡），语音识别默认走云端（Deepgram / OpenAI），快捷键是 Ctrl+Alt+键。下文以 macOS 为主。

英文面试实时辅助工具：抓取 Google Meet / Teams / Zoom 的**系统音频** → 流式语音识别 → 判断「面试官是否在提问」→ 结合你的 JD / 简历 / Cover Letter / 个人分析，在一个**分层悬浮窗**里给出答案。目标是面试官说完后 **1–2 秒出现要点，3–5 秒出现完整口述稿**。

```
┌─ capture/ ─┐   ┌── asr/ ──┐   ┌─ engine/ ─┐   ┌─ knowledge/ ─┐   ┌── llm/ ──┐   ┌── ui/ ──┐
│ BlackHole  │ → │ Deepgram │ → │ 问题检测  │ → │ Tier-1 预备  │ → │ Claude   │ → │ 分层     │
│ 系统音频   │   │ 流式/本地│   │ 合并/取消 │   │ 答案 <5ms    │   │ 流式输出 │   │ 悬浮窗   │
│ 16k mono   │   │ Whisper  │   │ 强制触发  │   │ 全量知识缓存 │   │ 分层解析 │   │ 全局热键 │
└────────────┘   └──────────┘   └───────────┘   └──────────────┘   └──────────┘   └──────────┘
```

## 0. 已经装过旧版本？一条命令升级（保留一切）

`.venv`、`.env`、`config.yaml`、`knowledge/`、`sessions/`、`.state/` 原地不动，不用重建环境、不用重装依赖、不用搬文件。

**这一次（旧版本里还没有 `update.py`）：** 把新 zip 解压到任意位置，例如 `~/Downloads/new/`，然后：
```bash
cd ~/Downloads/interview-copilot                         # 你现在在用的那个项目文件夹
.venv/bin/python ~/Downloads/new/interview-copilot/update.py
```
**以后每次：**
```bash
cd ~/Downloads/interview-copilot
.venv/bin/python update.py ~/Downloads/interview-copilot.zip     # 直接用下载的 zip
```
它会：先把当前代码备份到 `.state/backups/`；替换程序代码并删掉新版本里已不存在的旧模块；只有 `requirements.txt` 变了才在你原来的 `.venv` 里补装依赖；列出新版本新增的配置项（不改你的 `config.yaml`，新项自动用默认值）；最后自检一遍能否正常启动。出问题：`.venv/bin/python update.py --rollback`。

## 1. 分层设计

**代码分层**：每个目录是一层，只通过 `events.py` 里的事件对象向下一层传数据。任何一层都能单独替换，比如 Deepgram 换成本地 Whisper、Claude 换成 OpenAI，其他层不用改。

**悬浮窗分层**：每一层有数据就先显示，不等整段答案生成完。

| 层 | 内容 | 出现时间（面试官停顿后） |
|---|---|---|
| L0 | 面试官实时字幕（灰色斜体是还没稳定的识别结果） | 边说边出 |
| L1 | 识别出的问题 + **一句中文要点**（面试官在问什么、考察什么） | ≈0.4 s |
| B | **🗣 say now**：一句可以立刻开口的过渡句（按问题类型选），答案还没出来时先说这句 | 0 ms |
| L2 | **KEY**：开口第一句该说什么（≤14 词，大号黄色） | 预备命中：**≤0.5 s** · 模型：≈1.2–2 s |
| L3 | 3 条要点，每条带简历里的具体证据 | 预备命中：≤0.5 s · 模型：≈2–3 s |
| L4 | **SAY**：70–120 词完整口述稿（⌘⇧S 可折叠） | 预备命中：≤0.5 s · 模型：≈3–4.5 s |
| ALT | **MODEL VERSION**：预备答案占据主层时，模型的版本放在这里，**绝不覆盖你正在读的文字** | ≈3–4.5 s |
| DEEP | 仅混合模式：Sonnet 的另一版回答，紫色 | ≈6–7 s |

**预备答案命中 = 你自己写的 KEY + 要点 + SAY 全部立刻上屏**，通常面试官话还没说完（灰字标 "listening — likely this question"）就已经在了；停顿后最迟 ≤0.5 s（Deepgram）。模型的版本随后出现在下方 ALT 块。

## 2. 一次性安装（约 10 分钟）

### 2.1 把会议声音接进来（BlackHole）
```bash
brew install blackhole-2ch
```
1. 打开 **音频 MIDI 设置**（Audio MIDI Setup），点左下角 **+** → **创建多输出设备**，勾选 **你的耳机/扬声器** 和 **BlackHole 2ch**。
   - 主设备（Primary / Clock Source）选你的耳机，并给 BlackHole 勾上 **漂移校正**（Drift Correction）。用 AirPods 时这一步尤其重要。
2. 系统设置 → 声音 → 输出，选 **多输出设备**。也可以只在 Meet / Teams 的扬声器设置里选它。
3. 验证：`python scripts/check_audio.py`，随便播一段 YouTube，电平条会动。
4. 第一次运行时 macOS 会请求 **麦克风** 权限（读取 BlackHole 需要这个权限），给终端授权即可。

> 这里只抓系统输出，也就是远端面试官的声音。你自己的麦克风不会被识别，所以不会把你自己的回答当成问题。

### 2.2 Python 环境
```bash
cd interview-copilot
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install mlx-whisper        # 可选：离线识别（Apple Silicon；首次运行会下载约 1.6 GB 模型）
cp config.example.yaml config.yaml
cp .env.example .env           # 填 ANTHROPIC_API_KEY、DEEPGRAM_API_KEY
```
全局热键需要到 系统设置 → 隐私与安全性 → **辅助功能** 和 **输入监控**，给你的终端（Terminal / iTerm / VS Code）授权。没授权的话，热键只在悬浮窗获得焦点时生效。

### 2.3 放入你的知识库
**最简单：把文件直接拖进启动窗口**（见 §3）——简历、JD、Cover Letter、分析、`qa.generated.md`、cheatsheet，或者一整个文件夹、一个 zip 都行。工具按文件名和内容自动识别类型，放到 `knowledge/` 里它会读的名字下；同类旧文件（不管什么扩展名）先移到 `knowledge/.backup/时间/`。认不出来的会弹窗问你；虚构示例文件会被拒绝。

不用界面也可以：`python -m copilot.importer ~/Downloads/resume.pdf ~/Downloads/jd.docx 旧文件夹/knowledge`

`config.yaml` 里的 `knowledge.dir` 默认就是 `./knowledge`。支持 md、txt、pdf、docx 四种格式：

| 文件 | 作用 |
|---|---|
| `jd.md` | 职位描述 |
| `resume.pdf` | 简历（直接放 PDF 就行，同名不同后缀也能识别） |
| `cover_letter.md` | Cover Letter |
| `analysis.md` | **你自己对岗位的分析**：匹配点、短板和应对方式、准备复用的故事、想强调的主题（模板：`templates/analysis.template.md`） |
| `profile.md` | 薪资预期、notice period、签证/工作权利、想反问的问题 |
| `qa.md` | 手写的预备答案（模板：`templates/qa.template.md`） |
| `qa.bank.md` | **你的题库 + 参考答案**转换出来的（见下面 2.3b，不用手写） |

`knowledge.example/` 是一套**虚构**示例（候选人 Alex Sample、公司 Example Brokerage），只用来看格式和试界面（`python run.py --demo --mock-llm --example`）。工具会拒绝用它生成预备答案或开正式面试，并在 demo 里显示红色横幅。

### 2.3a 推荐格式：两个模板

启动窗口「Templates」按钮会打开 `templates/`。复制到 `knowledge/`，分别改名为 `analysis.md` 和 `qa.md`，把 `[方括号]` 换成你的内容。模板里的说明写在 `<!-- 注释 -->` 中，不会进入模型，也不会显示在悬浮窗里；没填的方括号不会被说出口。

- **`analysis.md`：临场答案的原料库。** 共 8 节：一句话定位、JD 要求对应的证据（表格：要求 / 故事 / 影响）、**故事库**、短板与转圜、公司与团队、要用的词、不要说的话、反问。故事库里每个故事的字段固定：问题 → 我的部分 → 技术（为什么选）→ 做了什么 → **对系统的影响（之前 → 之后，下游谁受益）** → 数字来源 → 难点 → 能回答哪些题。
- **`qa.md`：每题一块，字段顺序固定。** 依次是 `## Q:` 原话 · `ALT:` 3–5 种问法（实时匹配靠它）· `ID:` · `TAGS:` · `ZH:` 考点 · `KEY:` 先说的一句 · `FLOW:` 思路 · `-` 要点（经历题要有一条 `Impact:`）· `SAY:` 70–120 词口述稿 · `追问:` 追问 → 简短回答 · `NOTE:` 只给自己看的提醒。其中 `ID / TAGS / 追问 / NOTE` 只给模型当上下文，不会显示成答案。
- 旧的「题库 + 参考答案」两份文件（按编号对应）照样能用，见下一节。新写的题建议直接用 `qa.md` 格式。

**回答的思路：技术 → 做了什么 → 对整个系统的影响（1.8 起默认）。** 讲经历的题分三拍：问题（一句）→ 我做了什么、用了什么 → 对整个系统带来了什么（下游团队、报表、决策、风险、成本、速度；最好是之前 → 之后）。KEY 用影响开头，要点里有一条 `Impact:`，思路按「问题 → 做法 → 影响 → 联系岗位」。数字只用文件里有的；文件里没有数字，就说具体的变化，不会编。关掉：`config.yaml` → `llm.impact: false`。
`python -m copilot.bank check` 会列出「讲了做什么、没讲影响」的答案，以及还有 `[方括号]` 没填的答案。「Improve matching」（`python -m copilot.bank enrich`）会在题库答案里按同样的思路重写 KEY、要点和思路（只用你原文里的事实）；没写影响的题会加一条 💡 提醒你补。

### 2.3b 导入你自己的题库和参考答案

如果你已经有「题库」和「参考答案」两份文档（每题有编号，如 `- **O1 ★★★** Tell us…` 和 `**O1 · Tell us about yourself.**`），**直接把两份一起拖进启动窗口**，或者：
```bash
python -m copilot.bank build 面试题库.md 参考答案.md
```
- 两份按题号对上：题库里的完整问法作为问题，参考答案里的短问法、题里的每个分句作为同义问法（ALT）；「听什么」变成中文提示行（ZH），代码块变成 ⌨ 要点，`*要点：…*` 变成 💡 提示；输出到 `knowledge/qa.bank.md`。
- 答案里还没填的 `[方括号]` 会被找出来：启动窗口标黄、每题卡片顶部显示 ⚠ 待填，模型也被要求永远不说出方括号里的内容。**面试前把它们在原文档里填好，再拖一次就行**（旧版本自动备份，只拖其中一份也会和之前那份配对）。
- 不需要“提前传给模型”，也没有训练：命中的题**本地**匹配、直接上屏（不经过模型）；没命中的题，整份题库和答案会随每次请求作为**缓存的提示词**发给模型，所以追问和变体问法的回答会和你的答案口径一致。
- 同一道题你的答案和 AI 生成的（`qa.generated.md`）都有时，只用你的。
- **提高命中率（推荐，约 US$0.3）**：启动窗口点「Improve matching」或 `python -m copilot.bank enrich`——给每道题加 4 种面试官口语问法，以及 ≤14 词的 KEY 和 3 条要点（只从你的答案里取，不编新事实）。以后改了答案只重做改过的题。
- 检查：`python -m copilot.bank check` 列出哪些问法能立即锁定、哪些会锁错题；真实效果用 §4e+ 的麦克风/念稿测试（`evaluate script` 出的题会自动用你题库里的问法）。

### 2.4 面试前一晚：生成预备答案库
```bash
python -m copilot.prepare --n 30
```
这一步用 Sonnet 根据 JD 和简历预测 30 道最可能被问的题，**重点覆盖 JD 和简历之间的缺口**，并写好答案，保存到 `knowledge/qa.generated.md`。请逐条审读、改成你自己的话。面试时一旦命中，答案会在 5 ms 内出现，完全不依赖网络和模型速度。

## 2.5 面试前 10 分钟：一键体检
```bash
python run.py --preflight
```
逐项检查并给出 ✅/⚠️/❌：知识库文件是否齐、预备答案数量、**预备答案能否在 1.5 s 预算内上屏**（用你自己的 ALT 问法实测）、ASR Key、音频设备、热键权限、模型预热时间和一道题的真实延迟。有 ❌ 就不要开始面试。

## 3. 使用

**双击 `Interview Copilot.command`**（或 `python run.py`）打开启动窗口。第一次双击时 macOS 可能提示无法验证开发者：右键 → 打开 → 打开，之后就能直接双击。

启动窗口里一屏看完：
1. **你的文件**：每类文件是否已加载、多少字、预备答案几条；拖入文件、打开文件夹、一键「生成预备答案 + 速查表」
2. **API Keys**：从 `.env` 即时检查格式（放错行、多了字符、不可见字符都会标红）；「Test keys online」调用各家免费接口实测
3. **运行方式**：识别（本地 Whisper / Deepgram / OpenAI 实时）、回答（Haiku / Haiku+Sonnet / Sonnet）、模式（正式面试 / **麦克风测试：自己出声提问** / 打字练习 / 无 Key 界面测试），以及「保存音频用于打分」
4. 「Health check」跑完整体检，结果直接显示在窗口里；条件不满足时「▶ Start」是灰的，旁边写明原因

选择会记在 `.state/launcher.json`，下次打开自动选好；`config.yaml` 不会被改写。

命令行用法照旧（带任何模式参数就跳过启动窗口，`--no-launcher` 强制跳过）：
```bash
python run.py --no-launcher        # 按 config.yaml 直接开始
python run.py --demo --mock-llm    # 不需要任何 Key，打字模拟面试官，检查界面
python run.py --demo               # 打字提问、真实模型：练习用
python run.py --asr local          # 离线识别，音频不出本机
python run.py --asr openai_realtime   # 大模型流式识别（gpt-live-transcribe）
python run.py --model claude-sonnet-5-5 # 全程用 Sonnet 5.5（用它最低的思考档）
python run.py --deep-model claude-sonnet-5-5   # 混合模式：Haiku 先答，Sonnet 5.5 在下方补一版
python run.py --mic                # 用麦克风：你自己出声念问题，效果和真实面试一样
python run.py --mic AirPods --record   # 指定麦克风，并把音频存到 sessions/*.wav 以便打分
python run.py --replay mock.wav    # 用录音跑完整链路
python scripts/bench_latency.py    # 用你的知识库和模型实测延迟
```

| 热键 | 作用 |
|---|---|
| **⌘⇧Space** | **立刻回答**：没识别成问题、或者等不及断句时按 |
| **⌘⇧R** | **没听清 / 识别错了**：屏幕给出一句 "Sorry, could you say that again?"，并丢弃听了一半的内容重新听 |
| **⌘⇧F** | **专注模式**：只留 KEY 和 SAY，字体放大 1.35 倍，照着念 |
| **⌘⇧K** | **速查**：cheatsheet.md（时间线、数字、项目名、薪资/notice、想反问的问题） |
| ⌘⇧Y | 显示/隐藏 **思路**（中文思路 + 每步的英文词） |
| ⌘⇧S | 折叠/展开 SAY 口述稿（只看思路、用自己的话说时收起） |
| ⌘⇧← / → | 翻看之前的问题 |
| ⌘⇧P | 暂停/恢复监听（闲聊时用） |
| ⌘⇧H | 隐藏/显示窗口 |
| ⌘⇧T | 鼠标穿透（点击会穿过窗口落到下面的会议） |

界面（v1.7）——一页排好版的纸：
- **页边**：所有标记都悬在正文左侧 26 px 的页边里——问题前的「“」、KEY 前的一笔墨痕、思路的「一 二 三」、要点的「–」、命中你答案时的朱印「備」。眼睛顺着页边往下走，就知道自己读到哪里。
- **字的分工**：要说出口的（KEY、思路、SAY）用 Iowan Old Style / 宋体；中文提示用楷体，像老师在页边的批注；需要扫一眼的（问题、要点、状态）用苹方 / SF。
- **圆相**：左上角的圆相随麦克风「呼吸」；写答案时一笔一笔把自己画出来；暂停时变成空心。还没有问题时，页面中央有一个大圆相按「吸 4 秒、呼 6 秒」缓缓起伏——给面试开始前最紧张的那一分钟。
- **朱印**：只在两处出现——你自己准备的答案命中时「盖」下（先略大略淡，260 ms 落定），以及启动窗口的「Start」。能点的时候才是朱红，不能点时只是虚线轮廓。
- **动效**：新出现的内容像墨渗进纸一样淡入（220 ms），流式更新的文字不做动画，窗口本身淡入；启动窗口点 Start 后淡出，悬浮窗接上。
- **纸与墨**：和紙有楮树纤维、斑驳和四周微暗的晕影；墨版像砚台，带一点顶光和极少的云母光点。启动窗口题头是程序生成的山水，右重左轻，给标题留白。
- 应用图标（Dock / 任务栏）是一个圆相加朱印「面」，每个尺寸单独绘制：16–48 px 时笔画更粗、印章变成实心朱色方块。
- Windows 上保持同一套设计：英文用 Sitka（有 Small / Text / Subheading / Heading 四个光学尺寸，按字号自动切换），中文思路用楷体，界面文字用 Segoe UI Variable / 微软雅黑；启动窗口的标题栏会染成和纸 / 墨色；桌面快捷方式带图标；125% / 150% 缩放和多显示器都会重新绘制。详见 WINDOWS.md。

界面风格（v1.4）：侘寂——一张纸或一块墨，只在有含义的地方用颜色。
- **墨 Sumi**（深色，默认跟随 macOS）适合压在视频会议上；**和紙 Washi**（浅色）适合明亮环境。启动窗口右上角「Auto / 墨 / 紙」或悬浮窗的 **◐** 切换，两边共用、会记住。
- 衬线字（Iowan Old Style / 冬青明朝 Hiragino Mincho）= **要说出口的**：KEY 和 SAY；无衬线 = **扫一眼的**：问题、要点、状态。
- 左边一笔墨痕只标一件事：**先说这句（KEY）**。黄土色 = KEY，苔绿 = 你自己准备的答案，藍 = 中文提示，柿色 = 现在就说（过渡句 / 请重复），弁柄红 = 出问题了。
- 左上角的**圆相 ◯** 是状态：随麦克风音量轻微"呼吸"，写答案时缓慢转动，暂停时变成空心。
- 标题栏的控件平时很淡，鼠标移上去才清楚；有多道题时出现 **‹ 2 / 5 ›** 可以直接点着翻。
- 所有文字颜色在两种主题下都经过对比度测试（正文 ≥ 4.5:1）。

**思路（v1.5）——不用照着念，用自己的话说：**
- KEY 下面紧接着是**中文思路**：按说话顺序排的 3–4 步（一 二 三 四），每步后面跟着这一步要用到的**几个英文词**（术语、名字、数字）。看一眼中文知道先说什么、后说什么，英文词防止关键时刻卡词。
- 点「▾ 思路」标题或 **⌘⇧Y** 显示 / 隐藏；**想完全自由表达：保留思路，按 ⌘⇧S 把 SAY 收起来**（会记住）。专注模式（⌘⇧F）里思路也保留并放大。
- 模型的回答：思路紧跟 KEY 流式出来（多约 0.3 秒，其余不变）。
- 你的预备答案：`qa.generated.md` 和题库「Improve matching」生成时一并写好思路（**已经跑过的题库再点一次**，只补缺思路的题）。手写的 `qa.md` 或还没补的题，第一次命中时模型花约 1 秒按你的答案顺序写一份，存到 `.state/flow_cache.json`，之后命中即刻显示。
- 回答更口语、更简单（`llm.spoken: plain`，默认）：短句、日常词、缩写（I'm / I'd）、不用 leverage / spearhead 这类词，技术词只在需要时出现并用一句白话解释。想要以前偏书面的风格：`spoken: polished`。你自己的预备答案不会被改写。
- 不要思路：`llm.flow: false`。

悬浮窗：
- 标题栏 **− / +**（或 ⌘- / ⌘= / ⌘0）调字号；**◎** 专注模式；**◐** 深 / 浅；**?** 显示全部快捷键
- 点 **▸ SAY / ▸ MODEL VERSION / ▸ DEEP** 标题折叠或展开。命中预备答案时，模型版本默认折叠，只看你自己的答案
- 位置、大小、字号、折叠状态、专注模式都会记住（`.state/ui.json`），下次原样打开；外接屏拔掉了会自动回到主屏

窗口可以拖动，右下角可以缩放。建议放在**摄像头正下方**，看答案时视线偏离最小。

面试结束后按 Ctrl+C，`sessions/` 下会生成：
- `session-*.md`：复盘表，包括每道题、给出的答案、各阶段延迟的 p50/p90、5 秒内完成的比例
- `session-*.jsonl`：完整事件日志

## 4. 速度是怎么做到的

| 手段 | 省下的时间 |
|---|---|
| Deepgram 流式识别（nova-3），`endpointing=400ms`，边说边出字 | 不用等整句录完再转写 |
| JD 中的工具名、缩写自动加入 **keyterm** 提升识别率 | 减少 "Power BI" 被识别成 "power bee" 这类错误 |
| 问题检测用规则，不调用模型 | 约 0 ms（调模型要 ~500 ms） |
| **Tier-1 预备答案本地匹配**，对未说完的字幕也实时匹配 | 命中时 0 延迟 |
| 知识库很小，**全量放进 system prompt 并开启 prompt cache**，不做 RAG 检索 | 省去检索这一步，首 token 更快 |
| 启动时预热连接和缓存；空闲时用免费的 `count_tokens` 保活，每 4 分钟刷新一次缓存 | 每题省 ~300 ms TLS 握手（墨尔本到美国） |
| 默认用 Haiku 4.5，按 KEY → 要点 → 口述稿的顺序流式输出、分层渲染 | 1–2 s 内就有可以开口的内容 |
| 面试官停顿后 3 s 内接着说 → 自动合并成同一个问题，取消旧答案重新生成 | 不会拿着半个问题的答案 |

**预期延迟**（面试官停止说话 → 屏幕出字，Deepgram + Haiku 4.5，家用宽带）：KEY 约 1.3 s，完整答案约 4.5 s。这是估算值，请用 `bench_latency.py` 和 `sessions/*.md` 里的真实数据核对。

## 4b. 选哪个回答模型（Haiku / Sonnet / 混合）

**1.8 起 Sonnet 默认是 Sonnet 5.5**（`claude-sonnet-5-5`，2026-09-28 发布，价格和 Sonnet 5 相同）。启动窗口的「Haiku + Sonnet」「Sonnet」、`prepare`、`enrich` 都改用它。旧的 `config.yaml` 里写着 `claude-sonnet-5` 的，启动时会自动换成 5.5；想保留 5，设 `llm.keep_models: true`。

下表是按公开基准估算的 **Sonnet 5** 数据，都没有实测。Artificial Analysis 测得 Haiku 4.5 首字 0.65 s、81 token/s；Sonnet 5 不开思考约 65 token/s，首字没有公开数据，按 ~1 s 估算。一次回答约 280 token；按第三方文章的说法，Sonnet 5 的新分词器同样内容多出约 30%，约 360 token。Sonnet 5.5 官方只标「Fast」，没有公开速度数据，可以用 `python scripts/bench_latency.py --model claude-sonnet-5-5` 在你的网络下实测。

| 方案 | KEY 出现 | 要点出现 | 完整 SAY | 适合 |
|---|---|---|---|---|
| **Haiku 4.5**（默认） | ≈1.3 s | ≈2.4 s | ≈4.5 s | 实时面试首选 |
| **Sonnet 5，关闭思考**（本工具默认的发送方式） | ≈1.8 s | ≈3.6 s | ≈6.9 s | 回答质量优先；把 `say_words` 调到 `"45-70"` 可压到 ≈5.5 s |
| Sonnet 5，自适应思考 + `effort: low` | ≈2.2 s | ≈4 s | ≈8 s | 不建议实时使用 |
| Sonnet 5 默认设置（思考开、effort=high） | ≥3.7 s | — | ≈9–10 s+ | 只适合面试前 `prepare` |
| **混合**：`deep_model: claude-sonnet-5-5` | Haiku ≈1.3 s | Haiku ≈2.4 s | Haiku ≈4.5 s，Sonnet ≈7 s | 先有能开口的答案，追问或展开时看 DEEP 层 |

要点：
- **Sonnet 默认开启思考**，首字要等好几秒。Sonnet 5 可以直接关：工具发送 `thinking: {"type": "disabled"}`。**Sonnet 5.5 不能关**（发 `disabled` 会报 400），它最低的一档是 `between_tools`：请求里没有工具时就完全不思考。所以对 5.5，工具改发 `between_tools`，并带上它必需的 `effort`（默认 `medium`；想更快可设 `llm.effort: low`）。两者都不接受 `temperature`，所以不会发送。如果将来的模型在报错里提示 `between_tools`，工具会自动改用这一档；其他情况退回模型默认值再试一次。
- 只看「3–5 s 内有可以开口的内容」，Sonnet 5 关闭思考能做到（KEY ≈1.8 s、要点 ≈3.6 s）；但完整口述稿要 6–7 s。所以默认仍用 Haiku，想要 Sonnet 的质量就用混合模式。
- 费用：两者都很低。Sonnet 5 和 5.5 都是每百万 token 输入 $2、输出 $10；因为有 prompt cache，一场 1 小时面试即使用混合模式，通常也只要几美元以内。

## 4c. 用大模型做语音识别（可选）

**Claude 不能做这一层**：Claude API 目前只接受文字、图片和文档，不接受音频。所以大模型识别这里用 OpenAI 的转写模型，也兼容任何提供 OpenAI 格式接口的服务。

| `asr.provider` | 原理 | 实时字幕 | 面试官停下 → 可以触发回答 | 优点 / 代价 |
|---|---|---|---|---|
| `deepgram`（默认） | 专用流式语音识别 | ≈0.3 s | ≈0.4 s | 最快 |
| `openai_realtime` | **gpt-live-transcribe**，Realtime WebSocket 流式 | 首段文字中位数 0.70 s（`delay: minimal`） | ≈0.5–1.1 s | 能用 JD 关键词和场景提示理解上下文，行话、口音识别可能更好；约 $0.017/分钟 |
| `llm_segment` | 每次停顿后，把这段音频发给 `/audio/transcriptions`（gpt-transcribe，或 Groq whisper-large-v3-turbo） | 无 | ≈停顿 0.5 s + 上传和转写时间（未实测） | 最通用，可以换任何兼容服务 |
| `local` | 本机 Whisper（mlx-whisper, large-v3-turbo） | 有（边说边重转，按本机推理速度自动开关；每次推理 >0.6 s 就关掉，保证不拖慢最终文本） | ≈停顿 0.5 s + 一次推理（M1 Max/Ultra 级别预计 <1 s，**以 `asr_probe` 实测为准**） | 免费，音频不出本机，不依赖网络 |

`openai_realtime` 的实现方式：Realtime 的转写会话没有服务器端断句，所以由本工具在本地检测到 0.5 s 静音后提交这一段；提交后如果最终文本 0.6 s 内还没回来，就直接用已经流式收到的文字触发回答，保证不会卡住。
换成大模型识别后，整条链路大约慢 0.3–0.7 s：配 Haiku 时 KEY 约 1.6–2 s、完整答案约 5 s，刚好在上限附近。

> 说明：OpenAI 官方页面没有写明 WebSocket 地址。这里默认用 `wss://api.openai.com/v1/realtime?intent=transcription`（DataCamp 教程中的写法），可以在 `asr.openai_realtime.url` 修改。

## 4d. 为「一紧张就空白」设计的机制

紧张时最常见的三种失败：想不起自己准备过的答案、面试官问完的头两秒卡壳、被追问打断后接不上。对应的机制：

| 失败场景 | 机制 | 延迟 |
|---|---|---|
| 准备过但想不起来 | 预备答案本地匹配，命中即**全文上屏**（KEY + 要点 + 你写的 SAY）；面试官说到一半就开始匹配，命中会先出一张 "likely" 预告卡 | 面试官停顿后 ≤0.5 s（Deepgram）；**预算上限 1.5 s**，`--preflight` 和 `bench_latency.py` 都会验证 |
| 问完了大脑一片空白 | **🗣 say now** 过渡句 0 ms 出现（行为题："Sure — let me think of a specific example."；技术题："Let me walk through how I'd approach that."）；说完这句，KEY 已经在了 | 0 ms |
| 没听清 / 字幕识别错 | ⌘⇧R 给一句礼貌的请重复，并清掉半截字幕 | 0 ms |
| 屏幕太乱看不进去 | ⌘⇧F 专注模式：只留 KEY + SAY，放大 | — |
| 记不住数字、日期、项目名 | ⌘⇧K 速查面板（`prepare` 会自动生成 cheatsheet.md） | — |
| 面试官补了半句，屏幕清空 | 追问合并时**每一层各自保留旧文字（变灰）**，只有这一层的新文字到了才替换；新 KEY 到了，旧 SAY 仍在，直到新 SAY 到来 | — |
| 正在读的文字被模型流式改掉 | 预备答案锁定主层后，模型输出只进 MODEL VERSION 块。即使预告卡是在面试官说话中途出现、说完后匹配变弱，预备答案也**不会被覆盖**，只加标注「prepared match unconfirmed — compare MODEL VERSION」 | — |
| 漏判提问（不是疑问句式） | 默认 ≥22 词的陈述也触发回答（漏答比多一张卡代价大），这类卡标注「statement — may not be a question」；⌘⇧Space 兜底 | — |

**1.5 s 承诺的适用条件**：整条链路里匹配 <1 ms、渲染 <20 ms，时间几乎全部是语音识别从「停顿」到「出最终文本」这一段。`deepgram`（典型 ≈0.45 s）和 `openai_realtime`（≈0.7–1.1 s）满足；`local` 取决于你的芯片，`llm_segment` 取决于网络和服务。**不要信估算，跑实测**：

```bash
python -m copilot.asr_probe --asr local       # 用 macOS 自带 say 合成 3 道面试题，实时播放给识别器，测延迟和准确率
python -m copilot.asr_probe --asr deepgram
python -m copilot.asr_probe --asr openai_realtime
```
`--preflight` 也会自动跑这一步，并用测到的**最坏值**去核对 1.5 s 预算。合成语音是干净的录音棚音质，真实会议更难，所以准确率是上限、延迟有代表性。

匹配的鲁棒性：词级 TF-IDF + 覆盖率 + 字符三元组三项混合，对识别错误（"your self"、"power bee"）和面试官的口头填充（"so, um, maybe walk me through…"）都能命中；同一道题写 3–5 条 `ALT:` 问法效果最好，`prepare` 生成时已经这样要求。

想一开始就只看 KEY + SAY：`ui.focus_default: true`。

## 4e. 第一轮测试清单

按顺序做，每步都有明确的通过标准：

1. **不接任何服务看界面**：`python run.py --demo --mock-llm`。输入 "walk me through your background" → 预备答案立刻完整上屏（绿色 PREPARED 条）；输入 "tell me about a time you failed" → 先出现 🗣 过渡句，随后出答案。依次按 ⌘⇧F / ⌘⇧K / ⌘⇧R / ⌘⇧S / ⌘⇧← 看反应。
2. **体检**：填好 `.env` 后 `python run.py --preflight`。全部 ✅ 或只有 ⚠️ 才继续。记下「Prepared latency」和「Model answer」两行的数字。
3. **音频链路**：`python scripts/check_audio.py`，播放任意视频，电平条要动。
4. **真实模型打字练习**：`python run.py --demo`，问 10 道题（一半在预备库里、一半不在），结束后看 `sessions/*.md`：预备命中应为 n/n 在 1.5 s 内；未预备的完整答案 ≤5 s。
5. **真实会议**：和朋友开一场 Google Meet，让对方念 10 道题，其中故意包括：带口头填充的问法（"so, um, maybe walk me through…"）、说到一半停顿再补半句、一段长陈述。检查预告卡、合并不清屏、陈述标注三个行为。
6. **把问题反馈给我**：附上 `sessions/` 里的 `.md` 和 `.jsonl`，以及 `--preflight` 的输出。

## 4e+. 模拟真实场景 & 测识别准确率

先说清楚测什么：真实面试里最容易出问题的不是“能不能识别”，而是 **口音、会议软件压缩、背景噪音、面试官说一半停顿、口头填充词（so, um）、你的专有名词（Power BI、公司名）**。所以测试要覆盖这些，并且和“原话”逐字对比打分。

### 四种测试音频（从最快到最真实）

| 方式 | 命令 | 适合 |
|---|---|---|
| **① 自己对麦克风说（看效果）** | 启动窗口选 **Mic test**，或 `python run.py --mic` | 马上看悬浮窗的真实反应：预告卡、锁定、过渡句 |
| **② 自己对麦克风念稿（打分）** | `python -m copilot.evaluate record --name mine` | 屏幕逐条显示问题，回车开始念、回车结束；自动计时 → 可以算延迟 |
| **③ 合成口音 + 会议音质** | `python -m copilot.evaluate synth --name accents --noise none,15,8` | 澳/英/印/美/爱尔兰/南非口音，加噪音、电话频带、AAC 24 kbps 压缩（仿 Meet/Teams） |
| **④ 朋友在 Google Meet 上念** | `python -m copilot.evaluate script --name friend` → 把 `eval/friend/reader.md` 发给朋友；开会时用 `python run.py --record`（或启动窗口勾选「保存音频」） | 最接近真实：真实口音 + 真实会议链路 |

题目会自动混合：你**预备库里的题**（故意用 ALT 同义问法 + 口头填充）和**没准备过的常见题**，顺序打乱。

### 打分

```bash
# ②③ 生成的题组
python -m copilot.evaluate run --set eval/accents --asr local,deepgram,openai_realtime
# ④ 或任何录音 + 一个“原话”文本（一行一题）
python -m copilot.evaluate run --wav sessions/session-XXXX.wav --script eval/friend/script.txt --asr local
```
报告写在题组文件夹里（`report-*.md`），每个识别引擎一行：

| 指标 | 含义 | 目标 |
|---|---|---|
| **WER** | 词错误率 | ≤ 10 % 可用；> 15 % 模型会误解题意 |
| **key terms** | 你 JD/简历里的专有名词听对几个 | 全对。漏掉的词报告会列出来 → 加到 `asr.deepgram.keyterms`（所有引擎都用这个列表作提示） |
| **questions detected** | 每道题都出了问题卡吗 | n/n |
| **prepared locked** | 预备库里的题是否立即锁定你的答案（1.5 s 承诺靠它） | n/n。没锁的题报告会列出原话 → 作为 `ALT:` 加进 qa.md |
| **extra cards** | 多出来的卡（一句话被切成两题等） | 0 |
| **final text p50/max** | 说完 → 识别出最终文本（②③ 有精确时间才算） | Deepgram ≈ 0.4 s，本地 ≈ 0.5–1 s |

另外按条件（哪个口音、多少噪音）分别列 WER，以及错得最多的 5 句“原话 vs 听到的”。

### 麦克风测试的注意事项
- 第一次用会弹出 macOS 麦克风授权；如果之前点了拒绝，悬浮窗会出现红条：**系统设置 → 隐私与安全性 → 麦克风 → 打开“终端”**（或你启动程序的应用），然后重启。
- 默认用系统当前的输入设备（自动跳过 BlackHole）；想换：`--mic AirPods` 或 `config.yaml` 里 `audio.mic_device`。
- 麦克风模式下程序把**你的声音当成面试官**。对着电脑念问题就行；如果同时外放视频，戴上耳机，免得视频声音也被识别。
- 自己念稿时口音、语速和面试官不同，所以 ② 适合调流程；准确率以 ③④ 为准。

## 4f. 排错：界面一直停在 "Waiting for the interviewer's first question…"

终端里每一步都有日志，按顺序看断在哪一步：

```
INFO copilot: engine ready (demo mode) — type in the overlay box or in this terminal, then Enter
INFO copilot: demo input → engine: 'walk me through your background'     ← 界面收到了输入
INFO copilot.engine.pipeline: engine received: '...'                       ← 引擎收到了
INFO copilot.engine.pipeline: question #1: '...'                           ← 生成了问题卡
```
- 第一行都没有：引擎没启动，终端会有 `engine thread crashed` 的完整报错。
- 只有第一行：界面没收到输入。多半是中文输入法吞了回车——输入框已关闭输入法，也可以点 **Ask** 按钮，或者**直接在终端里打字回车**（demo 模式下终端输入同样有效）。
- 到了 `engine received` 却没有 `question #1`：悬浮窗和终端都会显示红色的 `... failed: <错误>`，把那一行发给我。
- `This process is not trusted!` / `Global hotkeys OFF`：全局热键缺辅助功能权限，不影响回答，只影响窗口没焦点时按热键。授权后重启终端。
- `error messaging the mach port for IMKCFRunLoopWakeUpReliable`、`TSM AdjustCapsLockLED…`：macOS 输入法的提示信息，可以忽略。

## 5. 调参建议

- 面试官说话停顿多、问题常被切成两半：把 `endpointing_ms` 调到 500–600，或把 `merge_window_s` 调到 4
- 漏掉了没有明显疑问句式的提问（例如 "Your experience with dbt."）：按 ⌘⇧Space，或把 `statement_trigger_words` 设为 20–25
- PREPARED 误命中：把 `instant_lock_threshold` 调到 0.8；命中太少：在 qa.md 里多写几条 `ALT:` 同义问法，然后跑 `bench_latency.py --mock` 看哪几条没锁定
- 陈述句误触发太多：把 `statement_trigger_words` 调大到 30，或设 0 关闭
- 不想依赖云端识别：`asr.provider: local`（Whisper large-v3-turbo，没有实时字幕，停顿后 0.5–1 s 出字）

## 6. 测试
```bash
pip install pytest
QT_QPA_PLATFORM=offscreen python -m pytest -q
```
共 186 个测试，覆盖问题分类、流式分层解析、预备答案匹配、VAD、重采样、Deepgram 消息解析和 WebSocket 会话（本地模拟服务器）、Anthropic 流式调用（模拟 SSE，验证 prompt cache 参数）、合并/取消/强制触发/出错降级、Sonnet 5 请求参数（关闭思考、不发 temperature、被拒后自动回退）、混合模式、gpt-live-transcribe 会话（本地模拟服务器，包括最终文本迟到时的回退）、分段转写接口，预备答案锁定/预告卡/1.5 s 预算、过渡句、⌘⇧R/⌘⇧F/⌘⇧K、追问合并不清屏、Realtime URL 回退、本地 Whisper 实时字幕及慢机器自动降级、识别延迟探针的对齐与打分、**从 `run.py` 入口真实启动的端到端流程（打字 demo 路径和音频→识别→引擎→界面路径各一个）**，启动窗口（拖入导入、Key 状态、开始条件、选项记忆、后台任务日志、经启动窗口进入悬浮窗）、文件导入分类与备份、升级脚本（保留用户数据、清理旧模块、按需装依赖、回滚、首次从新文件夹运行）、Key 被拒时停止重连，悬浮窗端到端流程（含折叠、缩放、状态记忆），麦克风模式（自动选麦克风而不是 BlackHole、被系统拦截时红条提示、录音），题库导入（题号配对、占位符检测、代码块、分次拖入配对、AI 生成答案去重、增量 enrich），手工材质（笔触与圆相的确定性、朱印刻字、纸纹与山水、按钮行为、盖印与呼吸动画）、Windows 支持（快捷键映射、扬声器回环录音与静音补齐、按设备名路由、云端识别默认、启动脚本、全程 UTF-8）、思路（解析、流式、预备答案补写与缓存、显示与开关）、口语风格提示词、「问题 → 做法 → 对系统的影响」回答框架与影响检查、两个输入模板（解析、注释不进模型、自带示例能锁定）、Sonnet 5.5 请求参数（between_tools + effort、旧配置自动迁移）、两套主题的文字对比度、主题在启动窗口和悬浮窗之间共享并记住、翻页按钮与淡化控件，以及识别评测（WER 对齐、专有名词、问题检测、预备锁定、合成噪音 SNR、电话频带、念稿计时）。

## 7. 已知限制
- 需要 BlackHole 路由声音。macOS 14.4+ 的 Core Audio Tap 可以免装驱动，但需要 Swift 辅助程序，目前还没做。
- 问题检测是规则，不是模型，偶尔会漏判或误判，⌘⇧Space 用来兜底。
- 模型可能说错。答案要求以你的文档为依据，但 SAY 仍然只是提示，请用自己的话讲。
- 有些公司明确禁止面试时使用 AI 辅助，使用前请确认对方的规定。
